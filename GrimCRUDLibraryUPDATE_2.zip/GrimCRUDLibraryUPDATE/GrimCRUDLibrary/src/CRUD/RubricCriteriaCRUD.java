/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CRUD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Anthony
 */
public class RubricCriteriaCRUD {
    private final String d = "jdbc:postgresql://10.76.17.197/GrimGraderDataBase";
    private final String u = "grimGrader";
    private final String p = "Here Dies Grades";
    
    private final String insertSQL = "INSERT INTO public.rubriccriteria VALUES (?,?,?,?,?,?)";
    private final String deleteSQL = "delete from public.rubriccriteria where " + 
            "rubricname = ? and" +
            "criterianame = ?";
    private final String getSQL = "select criterianame from public.rubiccriteria where "+
            "rubricname = ? ";
    private final String getSQLpt2 = "from public.rubriccriteria " +
           "where " + 
           "rubricname = ? and " +
           "criterianame = ?";
    private final String updateSQL = "UPDATE public.rubriccriteria " + 
                "set " + 
                "totalpercentage = ?, " +
                "goodpercentage = ?, " +
                "moderatepercentage = ?, " +
                "badpercentage = ? " +
                "where " + 
                "rubricname = ? and " +
                "criterianame = ?";
    Connection con;
    
    public RubricCriteriaCRUD() throws SQLException{
        con = DriverManager.getConnection(d, u, p);
    }
    
    public Boolean create(String RubricName, String CriteriaName, Double TotalPercentage, Double GoodPercentage,
            Double ModeratePercentage, Double BadPercentage){
        try {
            PreparedStatement ps = con.prepareStatement(insertSQL);
            int rn = 1;
            int cn = 2;
            int total = 3;
            int good = 4;
            int mod = 5;
            int bad = 6;
            ps.setString(rn, RubricName);
            ps.setString(cn, CriteriaName);
            ps.setDouble(total, TotalPercentage);
            ps.setDouble(good, GoodPercentage);
            ps.setDouble(mod, ModeratePercentage);
            ps.setDouble(bad, BadPercentage);
            ps.executeUpdate();
            ps.close();
            return true;
        } catch (SQLException ex) {
            //Logger.getLogger(RubricCriteriaCRUD.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    public ArrayList<String> getCriteria(String RubricName){
        ArrayList<String> out = new ArrayList<String>();
        try {
            PreparedStatement ps = con.prepareStatement(getSQL);
            int rn = 1;
            ps.setString(rn, RubricName);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                out.add(rs.getString(1));
            }
        } catch (SQLException ex) {
            //Logger.getLogger(RubricCriteriaCRUD.class.getName()).log(Level.SEVERE, null, ex);
            out = null;
        }
        return out;
    }
    
    /**
     * retrieves a list of percentages from a specific entry if found
     * * returns ArrayList of percentages if successful; null if unsuccessful
     * @param CriteriaName
     * @return 
     */
    public ArrayList<Double> retrieveCriteriaList(String RubricName, String CriteriaName){
        ArrayList<Double> r = new ArrayList<>();
        String q = "Select * " + getSQLpt2;
        PreparedStatement ps;
        try {
            ps = con.prepareStatement(q);
            int rname = 1;
            int cname = 2;
            ps.setString(rname, RubricName);
            ps.setString(cname, CriteriaName);
            ResultSet rs = ps.executeQuery();
            r.add(rs.getDouble("totalpercentage"));
            r.add(rs.getDouble("goodpercentage"));
            r.add(rs.getDouble("moderatepercentage"));
            r.add(rs.getDouble("badpercentage"));
            return r;
        } catch (SQLException ex) {
            return null;
            //Logger.getLogger(StudentCRUD.class.getName()).log(Level.SEVERE, null, ex);
        }   
    }
    
    /**
     * Fills in entries that are not nulled
     * * returns true if successful
     * @param CriteriaName
     * @param TotalPercentage
     * @param GoodPercentage
     * @param ModeratePercentage
     * @param BadPercentage
     * @return 
     */
    public Boolean Update(String RubricName, String CriteriaName, Double TotalPercentage, Double GoodPercentage,
            Double ModeratePercentage, Double BadPercentage){
            int total = 1;
            int good = 2;
            int mod = 3;
            int bad = 4;
            int rname = 5;
            int cname = 6;
        try {
            PreparedStatement ps = con.prepareStatement(updateSQL);  
            ps.setDouble(total, TotalPercentage);
            ps.setDouble(good, GoodPercentage);
            ps.setDouble(mod, ModeratePercentage);
            ps.setDouble(bad, BadPercentage);
            ps.setString(rname, RubricName);
            ps.setString(cname, CriteriaName);
            ps.executeUpdate();
            ps.close();
            return true;
        }catch (SQLException ex) {
            return false;
               //Logger.getLogger(CriteriaCRUD.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
    public Boolean delete(String RubricName, String CriteriaName){
        try {
            PreparedStatement ps = con.prepareStatement(deleteSQL);
            int rn = 1;
            int cn = 2;
            ps.setString(rn, RubricName);
            ps.setString(cn, CriteriaName);
            ps.executeUpdate();
            ps.close();
            return true;
        } catch (SQLException ex) {
            //Logger.getLogger(RubricCRUD.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
}
