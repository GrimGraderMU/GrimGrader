/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testmagic;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author eaibrahim2019
 */
public class TestMagic {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        MagicTest MagicTester = new MagicTest();
        List<String> MagicList = new ArrayList<String>();
        String dir = "H:\\My Documents\\NetBeansProjects\\AlgorithmsProject3";
        FileWrite Fr = new FileWrite(dir + "\\Magics.txt");
        List<String> FileNames = MagicTester.getFileLocation(dir);
        for (String S : FileNames) {
            List<String> c = MagicTester.parseFile(S, dir);
            MagicList = combine(c, MagicList);
        }
        Fr.printToFile(MagicList);
    }
    
    public static List<String> combine(List<String> toBeCombined, List<String> master){
        int leng = toBeCombined.size();
        for(int i = 0; i < leng; i++){
            master.add(toBeCombined.get(i));
        }
        return master;
    }
}
