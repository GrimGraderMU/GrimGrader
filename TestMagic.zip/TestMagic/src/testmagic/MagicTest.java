/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testmagic;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;

/**
 *
 * @author eaibrahim2019
 */
public class MagicTest {

    private String C;
    private final int end = 0;
    private final List<String> MagicList = new ArrayList<>();
    private final String regex = "(.)*(\\d)(.)*";
    private final Pattern pattern = Pattern.compile(regex);
    private final String For = "for";
    private final String OpenPar = "(";
    private final String ClosPar = ")";
    private final String equals = "=";

    public List<String> parseFile(String fileName, String dir) throws FileNotFoundException {
        List<String> MagicOutputs = new ArrayList<>();
        File file = new File(fileName);
        Scanner scan = new Scanner(new File(fileName));
        int count = 0;

        while (scan.hasNextLine()) {
            count++;
            String line = scan.nextLine().trim();
            if ((((line.contains(OpenPar) && line.contains(ClosPar)) || (line.contains("[") || line.contains("]")))
                    && (!line.contains(For) && !line.contains("while") && !line.contains("if") && !line.startsWith("*"))) && (!line.contains("//"))&&(!line.contains("\""))) {
                C = line;

                while (pattern.matcher(C).matches()) {

                    System.out.println(line + "has a magic number or bad practice in line " + count + " in class " + file.getName()+"\n");
                    MagicOutputs.add(line + "has a magic number or bad practice in line " + count + " in class " + file.getName()+"\n");
                    break;

                }
            }
            if ((line.contains(For) && (line.contains(";") && line.contains("="))) && (!line.contains("//"))) {
                C = line.substring(line.indexOf(";") + 1);
                while (pattern.matcher(C).matches()) {

                    System.out.println(line + " has a magic number or bad practice in line " + count + " in class " + file.getName()+"\n");
                    MagicOutputs.add(line + "has a magic number or bad practice in line " + count + " in class " + file.getName()+"\n");
                    break;
                }
            }
            if (line.contains("while") && !line.startsWith("//")||(line.contains("if"))) {
                C = line;
                while (pattern.matcher(C).matches()) {

                    System.out.println(line + " has a magic number or bad practice in line " + count + " in class " + file.getName()+"\n");
                    MagicOutputs.add(line + "has a magic number or bad practice in line " + count + " in class " + file.getName()+"\n");
                    break;
                }
            }
            if (line.contains("//") && !line.startsWith("//") && ((line.contains(OpenPar) && line.contains(ClosPar)))) {
                C = line.substring(end, line.indexOf("//"));
                while (pattern.matcher(C).matches()) {

                    System.out.println(line + " has a magic number or bad practice in line " + count + " in class " + file.getName()+"\n");
                    MagicOutputs.add(line + "has a magic number or bad practice in line " + count + " in class " + file.getName()+"\n");
                    break;
                }
                if (line.contains("\"") && line.contains(OpenPar)) {
                    C = line;
                    String[] Splits = C.split("\"");
                    String FirstHalf = Splits[0];
                    String Unwanted = Splits[1];
                    String[] SecondSplit = Unwanted.split("\"");
                    String SecondHalf = SecondSplit[0];
                    String Final = FirstHalf.concat(SecondHalf);

                    while (pattern.matcher(Final).matches()) {

                        System.out.println(line + " has a magic number or bad practice in line " + count + " in class " + file.getName()+"\n");
                        MagicOutputs.add(line + "has a magic number or bad practice in line " + count + " in class " + file.getName()+"\n");
                        break;
                    }
                }
                
            }
            
        }
        return MagicOutputs;
    }

    public List getFileLocation(String dir) throws IOException {

        File file = new File(dir);
        System.out.println("Getting all files in " + file.getCanonicalPath() + " including those in subdirectories");
        List<File> files = (List<File>) FileUtils.listFiles(file, TrueFileFilter.INSTANCE, TrueFileFilter.INSTANCE);
        List<String> FilePathList = new ArrayList<>();
        for (File f : files) {
            if (f.getName().endsWith(".java")) {
                FilePathList.add(f.getAbsolutePath());
                //  System.out.println(f.getName());
            }

        }

        return FilePathList;
    }
    public void writeToFile(String s)
    {
        try {
            File file = new File("Magics.txt");
            FileWriter fileWriter = new FileWriter(file);
            fileWriter.write(s);
            fileWriter.flush();
            fileWriter.close();
        } catch (IOException e) {
                e.printStackTrace();
        }
    }

}
