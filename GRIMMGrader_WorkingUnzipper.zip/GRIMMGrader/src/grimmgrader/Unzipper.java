/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grimmgrader;

import java.io.File;
import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;

/**
 *
 * @author Anthony
 */
public class Unzipper {
 
    public void unzipAll(String zipPath, String outPath){
        String sou = "";
        String destin = zipPath;
        String dest = outPath;
//        File folder = new File(destin);
//        File[] listOfFiles = folder.listFiles();

//        int i = listOfFiles.length;
//        for(int r = 0; r < i; r++){
            try {
                //sou = listOfFiles[r].getPath();
            ZipFile zipFile = new ZipFile(destin);
            zipFile.extractAll(dest);
            } catch (ZipException e) {
                e.printStackTrace();
            }
//        }
    }
    
    
}
