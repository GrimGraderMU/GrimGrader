/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grimmgrader;

/**
 *
 * @author Anthony
 */
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Anthony
 */
public class FileWrite {
    private String FileName = "";
    private List<String> output = new ArrayList<>();
    public FileWrite(String FilePath) {
       FileName = FilePath;
    }
    
    public void addLine(String s){
        output.add(s);
    }
    
    public void printToFile() throws IOException{
        //output=out;
        Path filePath = Paths.get(FileName);
        Files.write(filePath, output, Charset.forName("UTF-8"));
    }
    
}
