/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grimmgrader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author Anthony
 */
public class ReadOutputs {
    
     private final FileReader reader = new FileReader("Outputs.txt");
     private final BufferedReader in = new BufferedReader(reader);
     private String read = "";
     
     public ReadOutputs()throws IOException{
         
     }
     
     public String readLine() throws IOException{
         read = in.readLine();
         return read;
     }
     
     

}
