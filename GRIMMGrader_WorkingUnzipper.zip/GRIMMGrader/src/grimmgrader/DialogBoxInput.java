/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grimmgrader;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceDialog;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author nsalemu2019
 */
public class DialogBoxInput extends Application {

    static String message="";

    public String StartBox(Stage primaryStage){
        start(primaryStage);
        return message;
    }

    @Override
    public void start(Stage primaryStage) {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Program requesting Input");
        dialog.setHeaderText("Program requesting Input");
        dialog.setContentText("Insert Content to send to program");

// Traditional way to get the response value.
        Optional<String> result = dialog.showAndWait();
     

// The Java 8 way to get the response value (with lambda expression).
        result.ifPresent(messageFromInput ->{  message=messageFromInput;});


    }

    public String getMessage() {
        return message;
    }

}
