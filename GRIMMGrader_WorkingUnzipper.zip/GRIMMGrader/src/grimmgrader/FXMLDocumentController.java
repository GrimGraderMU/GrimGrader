/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grimmgrader;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import java.util.ArrayList;
import javafx.scene.control.TextArea;

/**
 *
 * @author Frehiwot Gudeta
 */
public class FXMLDocumentController implements Initializable {

    private static ArrayList<String> errorsList = new ArrayList<>();
    private static ArrayList<String> inputsList = new ArrayList<>();
    private static ArrayList<String> outputsList = new ArrayList<>();

    @FXML
    private TextArea outputWindow;
    @FXML
    private TextField errorWindow;
    @FXML
    private TextField rubricWindow;
    @FXML
    private TextField inputWindow;
    @FXML
    private Button startGrading;
    @FXML
    private Button enterInputs;

    //ReadOutputs out = new ReadOutputs();
    //ReadErrors err = new ReadErrors();
    @FXML
    private void startGrading(ActionEvent event) {
        CommandExecutor cmdExec = new CommandExecutor(this);
        ArrayList<String> commands = new ArrayList<>();
        String runCommand = "java -jar ";
        String runParam = "H:\\Downloads\\TestComplexProject\\dist\\TestComplexProject.jar";
        commands.add(runCommand);
        commands.add(runParam);
        cmdExec.execute(commands);
    }

    @FXML
    private void enterInputs(ActionEvent event) {

    }

    @FXML
    private void outputWindow(ActionEvent event) {

    }

    @FXML
    private void inputWindow(ActionEvent event) {

    }

    @FXML
    private void rubricWindow(ActionEvent event) {

    }

    @FXML
    private void errorWindow(ActionEvent event) {

    }
    
    public void unzipFile()
    {
        Unzipper unzipper = new Unzipper();
        getZip getZipFile = new getZip();
        unzipper.unzipAll(getZipFile.obtainZip(), "C:\\Users\\Anthony\\Documents\\h");
    }

    public void Update() {
        String ErrorText = "";
        for (String errors : errorsList) {
            ErrorText += errors;
        }

        String OutputText = "";
        for (String Outputs : outputsList) {
            OutputText = OutputText.concat("\n").concat(Outputs);
            
        }

        String InputText = "";
        for (String Inputs : inputsList) {
            InputText += Inputs;
        }
        outputWindow.setText(OutputText);
        inputWindow.setText(InputText);
        errorWindow.setText(ErrorText);

    }

   

    public void setErrorsList(ArrayList<String> errorsList) {
        FXMLDocumentController.errorsList = errorsList;
    }

    public void setInputsList(ArrayList<String> inputsList) {
        FXMLDocumentController.inputsList = inputsList;
    }

    public void setOutputsList(ArrayList<String> outputsList) {
        FXMLDocumentController.outputsList = outputsList;
    }

    public ArrayList<String> getErrorsList() {
        return errorsList;
    }

    public ArrayList<String> getInputsList() {
        return inputsList;
    }

    public ArrayList<String> getOutputsList() {
        return outputsList;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        //errorWindow.setText(in.readLine());
    }

}
