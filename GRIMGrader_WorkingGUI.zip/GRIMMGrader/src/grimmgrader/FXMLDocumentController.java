/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grimmgrader;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.TextArea;


/**
 *
 * @author Frehiwot Gudeta
 */


public class FXMLDocumentController implements Initializable {
    
     
    
    @FXML private TextField outputWindow;
    @FXML private TextField errorWindow;
    @FXML private TextField rubricWindow;
    @FXML private TextField inputWindow;
    @FXML private Button startGrading;
    @FXML private Button enterInputs;
     
     
     ReadOutputs out;
     ReadErrors err;
     
    
    
    
    @FXML
    private void startGrading(ActionEvent event) throws IOException {
       outputWindow.setText(out.readLine());
       errorWindow.setText(err.readLine());
       
       
    }
    
    @FXML
    private void enterInputs(ActionEvent event) {
        
    }
    
    @FXML
    private void outputWindow(ActionEvent event) {
       
 
    }
    
    @FXML
    private void inputWindow(ActionEvent event) {
        
    }
    
    @FXML
    private void rubricWindow(ActionEvent event) {
        
    }
    
    @FXML
    private void errorWindow(ActionEvent event) {
        
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {  
        try {
            out = new ReadOutputs();
            err = new ReadErrors();
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }

              
    }    
    
}
