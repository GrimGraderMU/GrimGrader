/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grimmgrader;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author Frehiwot Gudeta
 */
public class ReadOutputs {
     
     private BufferedReader in; 


     private String read = "";
     
     public ReadOutputs()throws IOException{
         
     }
     
     public String readLine() throws IOException, FileNotFoundException{
         in  = new BufferedReader(new FileReader("Outputs.txt"));
        // if(fr)
         read = in.readLine();
         return read;
     }
     
}
     

     
     
     


