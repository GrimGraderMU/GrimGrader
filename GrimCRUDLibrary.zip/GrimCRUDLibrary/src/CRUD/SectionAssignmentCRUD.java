/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CRUD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ryan
 */
public class SectionAssignmentCRUD {
    
    private final String slash = "\\";//----Used for FilePaths
    /**
     * the next three are for filepaths
     */
       private final String d = "jdbc:postgresql://10.76.17.197/GrimGraderDataBase";
       private final String u = "grimGrader";
       private final String p = "Here Dies Grades";
       /*
       The following four are SQL Statements that are sent to the Database
       the questionmarks are indicies that the methods use to fill in the blanks, they 
       start from 1, and increment by one
       */
       private final String insertSQL = "INSERT INTO public.sectionassignment VALUES (?,?)";
       private final String dropSQL = "Delete FROM public.sectionassignment WHERE " +
               "sectionname = ?, " +
               "assignmentname = ?";
       private final String getSQLpt2 = "from public.sectionassignment WHERE " +
               "sectionname = ?";
       private final String getSQLpt3 = "from public.sectionassignment WHERE " +
               "assignmentname = ?";
       private Connection con;//the connection to the database
       public SectionAssignmentCRUD() throws SQLException{
                   con = DriverManager.getConnection(d, u, p);
       }
    
       /**
        * Creates the initial entry into the table. 
        * returns true if successful
        * @param SectionName
        * @param AssignmentName
        * @return 
        */
    public Boolean Create(String SectionName, String AssignmentName){

        try {
            PreparedStatement ps = con.prepareStatement(insertSQL);
            ps.setString(1, SectionName);
            ps.setString(2, AssignmentName);
            ps.executeUpdate();
            ps.close();
            return true;
        } catch (SQLException ex) {
           
               Logger.getLogger(SectionAssignmentCRUD.class.getName()).log(Level.SEVERE, null, ex);
                return false;
        }
    }

    /**
     * retrieves all assignment names in a specific section
     * * returns ArrayList of assignment names if successful; null if unsuccessful
     * @param SectionName
     * @return 
     */
    public ArrayList<String> retrieveAssignmentsInSection(String SectionName){
        ArrayList<String> r = new ArrayList<>();
        String q = "Select * " + getSQLpt2;
        PreparedStatement ps;
        try {
            ps = con.prepareStatement(q);
            ps.setString(1, SectionName);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                r.add(rs.getString("assignmentname"));
            }
            return  r;
        } catch (SQLException ex) {
            Logger.getLogger(SectionAssignmentCRUD.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }

    
    }

    /**
     * retrieves all section names with a specific assignment
     * * returns ArrayList of assignment names if successful; null if unsuccessful
     * @param AssignmentName
     * @return 
     */
    public ArrayList<String> retrieveSectionsWithAssignment(String AssignmentName){
        ArrayList<String> r = new ArrayList<>();
        String q = "Select * " + getSQLpt3;
        PreparedStatement ps;
        try {
            ps = con.prepareStatement(q);
            ps.setString(1, AssignmentName);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                r.add(rs.getString("sectionname"));
            }
            return  r;
        } catch (SQLException ex) {
            Logger.getLogger(SectionAssignmentCRUD.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }

    
    }
    
    /**
     * deletes an entry from the table
     * * returns true if successful
     * @param SectionName
     * @param AssignmentName
     * @return 
     */
    public Boolean DeleteEntry(String SectionName, String AssignmentName){
        try {
            PreparedStatement ps = con.prepareStatement(dropSQL);
            int sname = 1;
            int aname = 2;
            ps.setString(sname, SectionName);
            ps.setString(aname, AssignmentName);
            ps.execute();
            ps.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(SectionAssignmentCRUD.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
}
