/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CRUD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Anthony
 */
public class RubricGradeCRUD {
    private final String d = "jdbc:postgresql://10.76.17.197/GrimGraderDataBase";
    private final String u = "grimGrader";
    private final String p = "Here Dies Grades";
    private final String insertSQL = "INSERT INTO public.rubricgrade VALUES (?,?,?,?,?,?)";
    private final String updateSQL = "UPDATE public.rubricgrade " + 
            "set" + 
            "grade = ? " + "where " + 
            "studentid = ?, " +
            "assignment = ?, " +
            "sectionname = ?, " + 
            "rubricname = ?, " + 
            "criterianame = ?";
    private final String deleteSQL ="Delete FROM public.rubricgrade WHERE " +
        "studentid = ?, " + 
        "assignmentname = ?, " + 
        "sectionname = ?, " +
        "rubricname = ?, " + 
        "criterianame = ?";
    private final String getSQL = "select grade from public.rubricgrade where " + 
        "studentid = ?, " + 
        "assignmentname = ?, " + 
        "sectionname = ?, " +
        "rubricname = ?, " + 
        "criterianame = ?";
    private Connection con;
    
    public RubricGradeCRUD() throws SQLException{
        con = DriverManager.getConnection(d, u, p);
    }
    
    public Boolean Create(String assignment, String section, Integer StudentId, 
            String Rubric, String Criteria, Float grade){
        int rub = 1;
        int crit = 2;
        int std = 3;
        int sec = 4;
        int asn = 5;
        int gra = 6;
        try {
            PreparedStatement ps = con.prepareStatement(insertSQL);
            ps.setString(rub, Rubric);
            ps.setString(crit, Criteria);
            ps.setInt(std, StudentId);
            ps.setString(sec, section);
            ps.setString(asn, assignment);
            ps.setFloat(gra, grade);
            ps.executeUpdate();
            ps.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(RubricGradeCRUD.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    public Boolean Update(String assignment, String section, Integer StudentId, 
            String Rubric, String Criteria, Float grade){
        int rub = 5;
        int crit = 6;
        int std = 2;
        int sec = 4;
        int asn = 3;
        int gra = 1;
        try {
            PreparedStatement ps = con.prepareStatement(updateSQL);
            ps.setString(rub, Rubric);
            ps.setString(crit, Criteria);
            ps.setInt(std, StudentId);
            ps.setString(sec, section);
            ps.setString(asn, assignment);
            ps.setFloat(gra, grade);
            ps.executeUpdate();
            ps.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(RubricGradeCRUD.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    public float getGrade(String assignment, String section, Integer StudentId, 
            String Rubric, String Criteria){
                int rub = 1;
        int crit = 2;
        int std = 3;
        int sec = 4;
        int asn = 5;
        int gra = 6;
        try {
            PreparedStatement ps = con.prepareStatement(getSQL);
            ps.setString(rub, Rubric);
            ps.setString(crit, Criteria);
            ps.setInt(std, StudentId);
            ps.setString(sec, section);
            ps.setString(asn, assignment);
            ResultSet rs = ps.executeQuery();
            rs.next();
            Float f = rs.getFloat(1);
            ps.close();
            return f;
        } catch (SQLException ex) {
            Logger.getLogger(RubricGradeCRUD.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }
    }
    
    public Boolean Delete(String assignment, String section, Integer StudentId, 
            String Rubric, String Criteria){
        int rub = 1;
        int crit = 2;
        int std = 3;
        int sec = 4;
        int asn = 5;
        try {
            PreparedStatement ps = con.prepareStatement(deleteSQL);
            ps.setString(rub, Rubric);
            ps.setString(crit, Criteria);
            ps.setInt(std, StudentId);
            ps.setString(sec, section);
            ps.setString(asn, assignment);
            ps.executeUpdate();
            return true;

        } catch (SQLException ex) {
            Logger.getLogger(RubricGradeCRUD.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
}
