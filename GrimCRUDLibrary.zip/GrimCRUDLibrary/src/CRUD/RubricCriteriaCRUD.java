/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CRUD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Anthony
 */
public class RubricCriteriaCRUD {
    private final String d = "jdbc:postgresql://10.76.17.197/GrimGraderDataBase";
    private final String u = "grimGrader";
    private final String p = "Here Dies Grades";
    
    private final String insertSQL = "INSERT INTO public.rubriccriteria VALUES (?,?)";
    private final String deleteSQL = "delete from public.rubric where " + 
            "rubricname = ? ";
    private final String getSQL = "select criterianame from public.student where "+
            "rubricname = ? ";
    Connection con;
    
    public RubricCriteriaCRUD() throws SQLException{
        con = DriverManager.getConnection(d, u, p);
    }
    
    public Boolean create(String RubricName, String CriteriaName){
        try {
            PreparedStatement ps = con.prepareStatement(insertSQL);
            int rn = 1;
            int cn = 2;
            ps.setString(rn, RubricName);
            ps.setString(cn, CriteriaName);
            ps.executeUpdate();
            ps.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(RubricCriteriaCRUD.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    public ArrayList<String> getCriteria(String RubricName){
        ArrayList<String> out = new ArrayList<String>();
        try {
            PreparedStatement ps = con.prepareStatement(getSQL);
            int rn = 1;
            ps.setString(rn, RubricName);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                out.add(rs.getString(1));
            }
        } catch (SQLException ex) {
            Logger.getLogger(RubricCriteriaCRUD.class.getName()).log(Level.SEVERE, null, ex);
            out = null;
        }
        return out;
    }
    
    public Boolean delete(String RubricName, String CriteriaName){
        try {
            PreparedStatement ps = con.prepareStatement(deleteSQL);
            int rn = 1;
            int cn = 1;
            ps.setString(rn, RubricName);
            ps.setString(cn, CriteriaName);
            ps.executeUpdate();
            ps.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(RubricCRUD.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
}
