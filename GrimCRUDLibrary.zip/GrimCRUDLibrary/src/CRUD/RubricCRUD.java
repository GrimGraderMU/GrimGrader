/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CRUD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Anthony
 */
public class RubricCRUD {
    private final String d = "jdbc:postgresql://10.76.17.197/GrimGraderDataBase";
    private final String u = "grimGrader";
    private final String p = "Here Dies Grades";
    
    private final String insertSQL = "INSERT INTO public.rubric VALUES (?,?)";
    private final String updateSQL = "UPDATE public.rubric " + 
            "set "+ 
            "rubrictype = ? " + 
            "where " + 
            "rubricname = ? ";
    private final String deleteSQL = "delete from public.rubric where " + 
            "rubricname = ? ";
    private final String getSQL = " from public.student where ";
    Connection con;
    
    public RubricCRUD() throws SQLException{
        con = DriverManager.getConnection(d,u,p);
    }
    
    public Boolean create(String RubricName, String Type){
        try {
            PreparedStatement ps = con.prepareStatement(insertSQL);
            int rn = 1;
            int rt = 2;
            ps.setString(rn, RubricName);
            ps.setString(rt, Type);
            ps.executeUpdate();
            ps.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(RubricCRUD.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    public Boolean update(String RubricName, String Type){
        try {
            PreparedStatement ps = con.prepareStatement(updateSQL);
            int rn = 2;
            int rt = 1;
            ps.setString(rn, RubricName);
            ps.setString(rt, Type);
            ps.executeUpdate();
            ps.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(RubricCRUD.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        } 
    }
    
    public Boolean Delete(String RubricName){
        try {
            PreparedStatement ps = con.prepareStatement(deleteSQL);
            int rn = 1;
            ps.setString(rn, RubricName);
            ps.executeUpdate();
            ps.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(RubricCRUD.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    public String getRubricNames(String Type){
        String query = "Select *" + getSQL + "rubric type = ?";
        try {
            PreparedStatement ps = con.prepareStatement(query);
            int rt = 1;
            ps.setString(rt, Type);
            ResultSet rs = ps.executeQuery();
            rs.next();
            String out = rs.getString(rt);
            rs.close(); 
            ps.close();
            return out;
        } catch (SQLException ex) {
            Logger.getLogger(RubricCRUD.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public String getRubricType(String RubricName){
        String query  = "select rubrictype " + getSQL + "rubric name = ?";
        try {
            PreparedStatement ps = con.prepareStatement(query);
            int rn = 1;
            ps.setString(rn, RubricName );
            ResultSet rs = ps.executeQuery();
            rs.next();
            String out = rs.getString(rn);
            rs.close(); 
            ps.close();
            return out;
        } catch (SQLException ex) {
            Logger.getLogger(RubricCRUD.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
}
