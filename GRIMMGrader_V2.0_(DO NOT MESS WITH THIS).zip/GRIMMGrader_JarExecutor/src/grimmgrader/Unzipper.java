/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grimmgrader;

import CRUD.StudentCRUD;
import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.filechooser.FileSystemView;
import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import org.apache.commons.io.FileDeleteStrategy;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;

/**
 *
 * @author Anthony
 */
public class Unzipper {

    public String FileUnzipper(String zipPath, String outPath) throws IOException {
        String sou = "";
        String destin = zipPath;
        String dest = outPath;
//        File folder = new File(destin);
//        File[] listOfFiles = folder.listFiles();

//        int i = listOfFiles.length;
//        for(int r = 0; r < i; r++){
        try {
            //sou = listOfFiles[r].getPath();
            ZipFile zipFile = new ZipFile(destin);
            zipFile.extractAll(dest);
            String jarDir = getJarLocation(dest);
            return jarDir;
        } catch (ZipException e) {
            return null;
        }
//        }
    }

    public String getJarLocation(String dir) throws IOException {

        File file = new File(dir);

        //System.out.println("Getting all files in " + file.getCanonicalPath() + " including those in subdirectories");
        List<File> files = (List<File>) FileUtils.listFiles(file, TrueFileFilter.INSTANCE, TrueFileFilter.INSTANCE);
        for (File f : files) {
            if (f.getName().endsWith(".jar")) {
                return f.getAbsolutePath();
            }
        }
        return null;
    }

    public boolean verifyPath(String dir) {
        File file = new File(dir);

        return file.exists();
    }

    public List<String> BigZipFileUnzipper(String zipPath, String outPath, String Course, String Assignment) throws IOException {
        String sou = "";
        String destin = zipPath;
        String HomeDir = FileSystemView.getFileSystemView().getDefaultDirectory().getPath() + "\\GrimGrader";
        String DestinPath = HomeDir + "\\" + Course + "\\" + Assignment;
        String BigJarDir = "";
        ZipFile zipFile1;

        try {
            //sou = listOfFiles[r].getPath();
            zipFile1 = new ZipFile(destin);
            zipFile1.extractAll(DestinPath + "\\smallZips");
        } catch (ZipException e) {
            return null;
        }

        
        File BigUnZipppedFolder = new File(DestinPath + "\\smallZips");
        File[] smallZips = BigUnZipppedFolder.listFiles();
        List<String> Submissions = new ArrayList<>();
        System.out.println("small zip absolut path" + Arrays.asList(smallZips));
//        for (File smallZip : smallZips) {
        for (int i = 0; i < smallZips.length; i++) {
            try {
                ZipFile zipFile = new ZipFile(smallZips[i].getAbsolutePath());
                System.out.println("name " + smallZips[i].getName());
                String s =  smallZips[i].getName();
                s = s.substring(0, 5);
                System.out.println("DOMO ORIGATO, MR. ROBOTO: " + s);
                File f = new File(DestinPath + "\\" + s);
                if(f.exists()){f.delete();}
                
                if (smallZips[i].getName().endsWith(".zip")) {
                    System.out.println("jjjjjjjjjjj  " + DestinPath);
                    zipFile.extractAll(DestinPath);

                }

            } catch (ZipException e) {
                    System.out.println("THIS IS WHAT IS HAPPENING TO ME: " +e.toString());
            }
        }
                try {
            File f = new File(DestinPath + "\\smallZips");
            for(File file: f.listFiles()){
                FileDeleteStrategy.FORCE.delete(file);
            }

        } catch (Exception e) {
            
        }
        File file = new File(DestinPath);
        File[] directories = file.listFiles(new FilenameFilter() {
            @Override
            public boolean accept(File current, String name) {
                return new File(current, name).isDirectory();
            }
        });

        for (File directory : directories) {
            System.out.println("bigzip directories" + directory.getAbsoluteFile());
            Submissions.add(directory.getAbsolutePath());
        }

        System.out.println(Submissions.size());
        return Submissions;
    }

    public String getmatchStudentWithSubmission(List<String> ProjectPaths, Integer StudentID) throws SQLException {
        for (String ProjectPath : ProjectPaths) {
            System.out.println("----" + ProjectPath.substring(0, ProjectPath.length()) + "  " + (StudentID.toString()));
            if (ProjectPath.substring(0, ProjectPath.length()).endsWith(StudentID.toString())) {
                return ProjectPath;
            }
        }
        return "";
    }
}
