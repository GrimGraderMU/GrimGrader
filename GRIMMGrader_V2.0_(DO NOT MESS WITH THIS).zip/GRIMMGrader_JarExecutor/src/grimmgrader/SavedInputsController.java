/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grimmgrader;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.filechooser.FileSystemView;

/**
 *
 * @author nsalemu2019
 */
public class SavedInputsController {
    public static List<InputTextinfo> getInputTextInfo(String Section, String Assignment){
        String HomeDir = FileSystemView.getFileSystemView().getDefaultDirectory().getPath() + "\\GrimGrader";
        String DestinPath = HomeDir + "\\" + Section + "\\" + Assignment + "\\Inputs.txt";
         FileWrite fileWrite = new FileWrite(DestinPath);
         System.out.println("***input Path***"+DestinPath);
        List<InputTextinfo> list = new ArrayList<>();
        System.out.println(list.size());
        try {
            list = (List<InputTextinfo>) fileWrite.GetData(DestinPath);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
    public static List<String> getInputs(String Section, String Assignment){
        List<InputTextinfo> list = getInputTextInfo( Section,  Assignment);
        
        List<String> InputName = new ArrayList<>();
        if (list != null) {
            for (InputTextinfo list1 : list) {
                InputName.add(list1.getName());
            }
        }
        return InputName;
    }
}
