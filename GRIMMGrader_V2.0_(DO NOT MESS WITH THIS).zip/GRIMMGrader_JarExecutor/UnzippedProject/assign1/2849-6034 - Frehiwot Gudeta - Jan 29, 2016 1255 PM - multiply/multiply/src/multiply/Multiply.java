/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiply;

/**
 *
 * @author fkgudeta2019
 */
public class Multiply {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
       test one = new test();
       System.out.println(one.multiply(1, 10));
       
       Integer multiplier = 1;
       Integer multiplican = 1;
        
       while( multiplican <= 10 && multiplier <= 10)
       {
          System.out.println(multiplican + "X" + multiplier );
          multiplican++;
          multiplier++;
       }
       
       
     
                
        
        
        
        
    }
    
}
