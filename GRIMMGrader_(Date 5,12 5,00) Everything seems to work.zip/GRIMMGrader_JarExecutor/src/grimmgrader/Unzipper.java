/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grimmgrader;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;

/**
 *
 * @author Anthony
 */
public class Unzipper {

    public String FileUnzipper(String zipPath, String outPath) throws IOException {
        String sou = "";
        String destin = zipPath;
        String dest = outPath;
//        File folder = new File(destin);
//        File[] listOfFiles = folder.listFiles();

//        int i = listOfFiles.length;
//        for(int r = 0; r < i; r++){
        try {
            //sou = listOfFiles[r].getPath();
            ZipFile zipFile = new ZipFile(destin);
            zipFile.extractAll(dest);
            String jarDir = getJarLocation(dest);
            return jarDir;
        } catch (ZipException e) {
            return null;
        }
//        }
    }

    private String getJarLocation(String dir) throws IOException {

        File file = new File(dir);

        System.out.println("Getting all files in " + file.getCanonicalPath() + " including those in subdirectories");
        List<File> files = (List<File>) FileUtils.listFiles(file, TrueFileFilter.INSTANCE, TrueFileFilter.INSTANCE);
        for (File f : files) {
            if (f.getName().endsWith(".jar")) {
                return f.getAbsolutePath();
            }
        }
        return null;
    }

    public boolean verifyPath(String dir) {
        File file = new File(dir);

        return file.exists();
    }

    public List<String> BigZipFileUnzipper(String zipPath, String outPath) throws IOException {
        String sou = "";
        String destin = zipPath;
        String dest = outPath;
        String BigJarDir = "";
        ZipFile zipFile1;

        try {
            //sou = listOfFiles[r].getPath();
            zipFile1 = new ZipFile(destin);
            zipFile1.extractAll(dest+"\\smallZips");
        } catch (ZipException e) {
            return null;
        }
        File BigUnZipppedFolder = new File(dest+"\\smallZips");
        File[] smallZips = BigUnZipppedFolder.listFiles();
        List<String> JarDirs = new ArrayList<>();

        for (File smallZip : smallZips) {
            try {
                ZipFile zipFile = new ZipFile(smallZip.getAbsolutePath());
                if (smallZip.getName().length() > 3) {
                    System.out.println(dest+"\\projects\\" + smallZip.getName().substring(0, smallZip.getName().length() - 4));
                    zipFile.extractAll(dest+"\\projects\\" + smallZip.getName().substring(0, smallZip.getName().length() - 4));
                }
                String jarDir = getJarLocation(dest+"\\projects\\");
                JarDirs.add(jarDir);
            } catch (ZipException e) {

            }
        }
        return JarDirs;
    }
}
