/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectinformation;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;

/**
 *
 * @author Frehiwot Gudeta
 */
public class ProjectInfo {
    
    private String storeTo = "C:\\Users\\Frehiwot Gudeta\\Desktop\\projectInfo.txt"; 
    //file everything will be stored to
    
    
    public void getProjectInfo(String dir) throws IOException {

        File file = new File(dir);
        System.out.println("Getting all files in " + file.getCanonicalPath() + " including those in subdirectories");
        List<File> files = (List<File>) FileUtils.listFiles(file, TrueFileFilter.INSTANCE, TrueFileFilter.INSTANCE);
        ArrayList<String> list = new ArrayList<>();
        for (File f : files) {
            if (f.getName().endsWith(".java")) {
                String s = this.txttoString(f.getAbsolutePath());
                list.add(this.extract(s));
               this.writeToFile(list.toString());
              
            }
        } 
    }    
    
    public String txttoString(String fileName) throws IOException
    {
        String s = "";
        StringBuilder contentBuilder = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {

            String sCurrentLine;
            while ((sCurrentLine = br.readLine()) != null) {
                contentBuilder.append(sCurrentLine).append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        s = contentBuilder.toString();
    
         return s;
     }
    
    public String extract(String s)
    {
        int count=0;
        boolean isSet=false;
        int start=0;
        int end=0;
        List<String> a = new ArrayList<>();
        
        for (int i = 0; i < s.length(); i++) {
            
            if(s.charAt(i)=='{'){
                count++;
            }
            if(s.charAt(i)=='}'){
                count--;
            }
            if(!isSet && s.charAt(i)=='{' && count==1){
                isSet=true;
                end=i;
            }
            if(isSet && s.charAt(i)=='}' && count==0){
                isSet=false;
                a.add(s.substring(start, end)+"{}");
                start=i+1;
                
            }    
            
        }
        return a.toString();
        
    }
    
    public void writeToFile(String s)
    {
        try {
            File file = new File(storeTo);
            FileWriter fileWriter = new FileWriter(file);
            fileWriter.write(s);
            fileWriter.flush();
            fileWriter.close();
        } catch (IOException e) {
                e.printStackTrace();
        }
    }
    
    
}
