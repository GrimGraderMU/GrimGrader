/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CRUD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ryan
 */
public class CriteriaCRUD {
    
    private final String slash = "\\";//----Used for FilePaths
    /**
     * the next three are for filepaths
     */
       private final String d = "jdbc:postgresql://10.76.17.197/GrimGraderDataBase";
       private final String u = "grimGrader";
       private final String p = "Here Dies Grades";
       /*
       The following four are SQL Statements that are sent to the Database
       the questionmarks are indicies that the methods use to fill in the blanks, they 
       start from 1, and increment by one
       */
       private final String insertSQL = "INSERT INTO public.criteria VALUES (?,?,?,?,?)";
       private final String updateSQL = "UPDATE public.criteria " + 
                "set " + 
                "totalpercentage = ?, " +
                "goodpercentage = ?, " +
                "moderatepercentage = ?, " +
                "badpercentage = ? " +
                "where " + 
                "criterianame = ?";
       private final String dropSQL = "Delete FROM public.criteria WHERE " +
               "crtierianame = ?";
       private final String getSQLpt2 = "from public.criteria " +
               "where " + 
               "criterianame = ?";
       private Connection con;//the connection to the database
       public CriteriaCRUD() throws SQLException{
                   con = DriverManager.getConnection(d, u, p);
       }
    
       /**
        * Creates the initial entry into the table. 
        * returns true if successful
        * @param CriteriaName
        * @param TotalPercentage
        * @param GoodPercentage
        * @param ModeratePercentage
        * @param BadPercentage
        * @return 
        */
    public Boolean Create(String CriteriaName, Double TotalPercentage, Double GoodPercentage,
            Double ModeratePercentage, Double BadPercentage){
            int name = 1;
            int total = 2;
            int good = 3;
            int mod = 4;
            int bad = 5;
        try {
            PreparedStatement ps = con.prepareStatement(insertSQL);
            ps.setString(name, CriteriaName);
            ps.setDouble(total, TotalPercentage);
            ps.setDouble(good, GoodPercentage);
            ps.setDouble(mod, ModeratePercentage);
            ps.setDouble(bad, BadPercentage);
            ps.executeUpdate();
            ps.close();
            return true;
        } catch (SQLException ex) {
           
               Logger.getLogger(CriteriaCRUD.class.getName()).log(Level.SEVERE, null, ex);
                return false;
        }
    }
    
    /**
     * Fills in entries that are not nulled
     * * returns true if successful
     * @param CriteriaName
     * @param TotalPercentage
     * @param GoodPercentage
     * @param ModeratePercentage
     * @param BadPercentage
     * @return 
     */
    public Boolean Update(String CriteriaName, Double TotalPercentage, Double GoodPercentage,
            Double ModeratePercentage, Double BadPercentage){
            int total = 1;
            int good = 2;
            int mod = 3;
            int bad = 4;
            int name = 5;
        try {
            PreparedStatement ps = con.prepareStatement(updateSQL);  
            ps.setDouble(total, TotalPercentage);
            ps.setDouble(good, GoodPercentage);
            ps.setDouble(mod, ModeratePercentage);
            ps.setDouble(bad, BadPercentage);
            ps.setString(name, CriteriaName);
            ps.executeUpdate();
            ps.close();
            return true;
        }catch (SQLException ex) {
            return false;
               //Logger.getLogger(CriteriaCRUD.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }

    /**
     * retrieves a list of percentages from a specific entry if found
     * * returns ArrayList of percentages if successful; null if unsuccessful
     * @param CriteriaName
     * @return 
     */
    public ArrayList<Double> retrieveCriteriaList(String CriteriaName){
        ArrayList<Double> r = new ArrayList<>();
        String q = "Select * " + getSQLpt2;
        PreparedStatement ps;
        try {
            ps = con.prepareStatement(q);
            int name = 1;
            ps.setString(name, CriteriaName);
            ResultSet rs = ps.executeQuery();
            r.add(rs.getDouble("totalpercentage"));
            r.add(rs.getDouble("goodpercentage"));
            r.add(rs.getDouble("moderatepercentage"));
            r.add(rs.getDouble("badpercentage"));
            return r;
        } catch (SQLException ex) {
            return null;
            //Logger.getLogger(StudentCRUD.class.getName()).log(Level.SEVERE, null, ex);
        }   
    }

    /**
     * deletes an entry from the table
     * * returns true if successful
     * @param CriteriaName
     * @return 
     */
    public Boolean DeleteEntry(String CriteriaName, String RubricName){
        try {
            PreparedStatement ps = con.prepareStatement(dropSQL);
            int name = 1;
            ps.setString(name, CriteriaName);
            ps.execute();
            ps.close();
            return true;
        } catch (SQLException ex) {
            return false;
            //Logger.getLogger(CriteriaCRUD.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
