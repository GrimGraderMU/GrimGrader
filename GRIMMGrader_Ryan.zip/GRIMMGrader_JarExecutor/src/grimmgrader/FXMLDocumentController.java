/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grimmgrader;

import CRUD.RubricCRUD;
import CRUD.RubricCriteriaCRUD;
import CRUD.RubricGradeCRUD;
import CRUD.SectionAssignmentCRUD;
import CRUD.SectionCRUD;
import CRUD.SectionStudentCRUD;
import CRUD.StudentCRUD;
import CRUD.SubmissionCRUD;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.function.UnaryOperator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextFormatter;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.util.Duration;
import javax.swing.JOptionPane;

/**
 *
 * @author Frehiwot Gudeta
 */
public class FXMLDocumentController implements Initializable {

    private ArrayList<String> errorsList = new ArrayList<>();
    private ArrayList<String> inputsList = new ArrayList<>();
    private ArrayList<String> outputsList = new ArrayList<>();
    private List<String> TempInputCommand = new ArrayList<>();
    private boolean StartedGrading = false;
    private String ProjectJarLocation = "";
    CommandExecutor cmdExec = null;
    private final Integer numTextFields = 5;
    private Integer count = 0;
    private final String newRubric = "new rubric";
    private ArrayList<ArrayList<String>> criteriaArray;
    private ObservableList<String> rubricNameItems = FXCollections.observableArrayList();
    private ObservableList<String> rubricTypeItems = FXCollections.observableArrayList("Global", "Course", "Assignment");
    private String criterionDeleteButtonName = "delete";
    private Double spacing = 5.0;
    private Double textFieldWidth = 120.0;
    private ObservableList<String> studentItems    = FXCollections.observableArrayList("John", "Stewart", "Greg");//FXCollections.observableArrayList();
    private ObservableList<String> assignmentItems = FXCollections.observableArrayList("Global");//FXCollections.observableArrayList();
    private ObservableList<String> sectionItems    = FXCollections.observableArrayList("Global");//FXCollections.observableArrayList();
    private ObservableList<String> rubricItems     = FXCollections.observableArrayList("100");//FXCollections.observableArrayList();
    private final Double vBoxSpacing                     = 5.0;
    private final Double hBoxSpacing                     = 60.0;
    private final Double textFieldWidthGradingTab                  = 80.0;
    private ArrayList<Double> grades;
    private List<Double> criteriaItems = new ArrayList<>(1);
    private ObservableList<String> courseNames = FXCollections.observableArrayList("New Course");
    private ArrayList<Student> students = new ArrayList<>();
    private int hBoxCount = 0;
    private ArrayList<CheckBox> checkBoxes = new ArrayList<>();
    private int markAllCount = 0;
    private Double[] percentChosenList;
    private Double[] percentTotalList;
    private ObservableList<String> termNames = FXCollections.observableArrayList("FALL", "JANUARY", "SPRING");
    private FileOutputStream fileOutputStream;
    private String fontType = "Cambria";
    private int fontSize = 20;
    private double chosenGrade;
    private String errorMessageTitle = "Error";
    private String errorMessageHeader = "An error has occured while saving the course...";
    private String subjectErrorText = "Subject contains symbolic or numerical input, please enter only letters";
    private String numberErrorText = "Number contains non-numerical input, please enter only numbers";
    private String sectionErrorText = "Section contains symbolic or numerical input, please enter only a letter";
    private String termErrorText = "No term selected, please select a term";
    private String yearErrorText = "Year contains non-numerical input, please enter only numbers";
    private String fileNotFound = "There was no file found for this student";
    private UnaryOperator<TextFormatter.Change> filter = new UnaryOperator<TextFormatter.Change>() {
        @Override
        public TextFormatter.Change apply(TextFormatter.Change t) {
            if (t.isReplaced()) 
                if(t.getText().matches("[^0-9]"))
                    t.setText(t.getControlText().substring(t.getRangeStart(), t.getRangeEnd()));


            if (t.isAdded()) {
                if (t.getControlText().contains(".")) {
                    if (t.getText().matches("[^0-9]")) {
                        t.setText("");
                    }
                } else if (t.getText().matches("[^0-9.]")) {
                    t.setText("");
                }
            }

            return t;
        }
    };
    @FXML
    private Button saveButton;
    @FXML
    private Button deleteButton;
    @FXML
    private Button deleteSelectedButton;
    @FXML
    private Button markAllButton;
    @FXML
    private Button addStudentButton;
    @FXML
    private Button assignStudentsButton;
    @FXML
    private TextField editNameBox;
    @FXML
    private TextField newStudentBox;
    @FXML
    private TextField subjectBox;
    @FXML
    private TextField numberBox;
    @FXML
    private TextField sectionBox;
    @FXML
    private TextField yearBox;
    @FXML
    private VBox studentVBox;
    @FXML
    private Label studentName;
    @FXML
    private ChoiceBox courseDropDown;
    @FXML
    private ChoiceBox termDropDown;
    
    @FXML
    private AnchorPane root;
    @FXML
    private Label percentOfTotal;
    @FXML
    private Label goodPercentage;
    @FXML
    private Label moderatePercentage;
    @FXML
    private Label badPercentage;
    @FXML
    private Button save_button;
    @FXML
    private Button delete_button;
    @FXML
    private Button new_criterion_button;
    @FXML
    private ChoiceBox rubric_name_dropdown;
    @FXML
    private ChoiceBox rubric_type_dropdown;
    @FXML
    private VBox vb;
    @FXML
    private TextArea inputTextArea;
    @FXML
    private Button SaveInputButton;
    @FXML
    private ComboBox SaveInputTextChoiceBox;
    @FXML
    private TextArea outputWindow;
    @FXML
    private TextArea errorWindow;
    @FXML
    private TextField rubricWindow;
    @FXML
    private TextArea inputWindow;
    @FXML
    private Button startGrading;
    @FXML
    private Button enterInputs;
    @FXML
    private TextField InputName;
    @FXML
    private ChoiceBox section_choice_box;

    @FXML
    private ChoiceBox assignment_choice_box;

    @FXML
    private ChoiceBox student_choice_box;

    @FXML
    private ChoiceBox rubric_choice_box;

    @FXML
    private Button prevStudent_button;

    @FXML
    private Button nextStudent_button;

    @FXML
    private Button assign_grade_button;

    @FXML
    private TextArea output_text_area;

    @FXML
    private TextArea errors_text_area;

    @FXML
    private TextArea amd_text_area;

    @FXML
    private TextArea magic_text_area;

    @FXML
    private VBox criteria_vbox;

    @FXML
    private Label totalGradeLabel;
    
    @FXML
    private Button assingmentAccessButton;
    
    @FXML
    private Button assingmentSaveButton;
    
    @FXML
    private Button assingmentDoneButton;
    
    @FXML
    private Button assingmentDeleteButton;
    
    @FXML
    private ChoiceBox assingmentDrop;
    
    @FXML
    private ChoiceBox sectionDrop;
    
    @FXML
    private TextField assingmentTextField;
    
    @FXML
    private Pane assingmentPane;
    
    
    
    

    private Scene welcomeScreenScene;
    private Scene parentScene;
    private StackPane welcomeScreenPane;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initalizeDropDowns();
        initializeCourseTab();
        FadeInTransition(300);

    }

    public void FadeInTransition(double Millis) {
        FadeTransition fadein = new FadeTransition();
        fadein.setDuration(Duration.millis(Millis));
        fadein.setNode(root);
        fadein.setFromValue(0);
        fadein.setToValue(1);
        fadein.play();
    }

    private void initalizeDropDowns() {

        SaveInputTextChoiceBox.getItems().addAll(SavedInputsController.getInputs());
        SaveInputTextChoiceBox.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                TempInputCommand.addAll(SavedInputsController.getInputTextInfo().get(newValue.intValue()).getInputText());
                System.out.println(TempInputCommand.toString());
            }
        });

        vb.setSpacing(spacing);
        rubric_name_dropdown.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                if (newValue != null) {
                    delete_button.disableProperty().set(false);
                    rubric_type_dropdown.setDisable(false);
                    updateVBox();
                }
            }
        });

        RubricCRUD cr2;
        try {
            cr2 = new RubricCRUD();
            ObservableList<String> rubrics = FXCollections.observableArrayList(cr2.getRubricNames());
            rubrics.add(0, newRubric);
            rubric_name_dropdown.setItems(rubrics);
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        rubric_type_dropdown.setItems(rubricTypeItems);
        resetUserInput();
        rubric_type_dropdown.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                new_criterion_button.disableProperty().set(false);
                save_button.disableProperty().set(false);
            }
        });
         criteria_vbox.setSpacing(vBoxSpacing);
        assignment_choice_box.setDisable(true);
        student_choice_box.setDisable(true);
        assign_grade_button.setDisable(true);
        nextStudent_button.setDisable(true);
        prevStudent_button.setDisable(true);
        output_text_area.setDisable(true);
        errors_text_area.setDisable(true);
        amd_text_area.setDisable(true);
        magic_text_area.setDisable(true);
        output_text_area.setEditable(false);
        errors_text_area.setEditable(false);
        amd_text_area.setEditable(false);
        magic_text_area.setEditable(false);
        
        try {
            //Get sectionItems from DB ObservableArrayList
            SectionCRUD cr = new SectionCRUD();
            ObservableList<String> sections = FXCollections.observableArrayList(cr.retrieveSectionName());
            section_choice_box.setItems(sections);
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        //Enable section_choice_box
        section_choice_box.setDisable(false);        
        
        try {
            //Get rubricItems from DB
            RubricCRUD cr = new RubricCRUD();
            ObservableList<String> rubrics = FXCollections.observableArrayList(cr.getRubricNames());
            rubric_choice_box.setItems(rubrics);
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        //Enable rubric_choice_box
        rubric_choice_box.setDisable(false);
        
        
        
        
        section_choice_box.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                //Enable assignment_choice_box
                assignment_choice_box.setDisable(false);
                try {
                    //Get assignmentItems from DB using course selected
                    SectionAssignmentCRUD cr = new SectionAssignmentCRUD();
                    SectionStudentCRUD cr2 = new SectionStudentCRUD();
                    StudentCRUD cr3 = new StudentCRUD();
                    ObservableList<String> assignments = FXCollections.observableArrayList(cr.retrieveAssignmentsInSection(newValue));
                    ObservableList<Integer> studentIds = FXCollections.observableArrayList(cr2.retrieveStudentsInSection(newValue));
                    ObservableList<String> students = FXCollections.observableArrayList();
                    for(Integer i : studentIds)
                    {
                        students.add(cr3.retrieveStudentName(i) + "---" + i);
                    }
                    assignment_choice_box.setItems(assignments);
                    student_choice_box.setItems(students);
                } catch (SQLException ex) {
                    Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            
        });
        
        assignment_choice_box.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                //Enable student_choice_box
                student_choice_box.setDisable(false);
            }
            
        });
        
        student_choice_box.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                //Enable text areas and buttons
                nextStudent_button.setDisable(false);
                prevStudent_button.setDisable(false);
                output_text_area.setDisable(false);
                errors_text_area.setDisable(false);
                amd_text_area.setDisable(false);
                magic_text_area.setDisable(false);
                
                try {
                    //Display output, errors, magic, attributes, methods, and documentation
                    SubmissionCRUD cr = new SubmissionCRUD();
                    String[] f = newValue.split("---");
                    String section = (String) section_choice_box.getSelectionModel().getSelectedItem();
                    String assignment = (String) assignment_choice_box.getSelectionModel().getSelectedItem();
                    Integer studentId = Integer.parseInt(f[f.length-1]);
                    File file = new File("Documents//" + section + "//" + assignment + "//" + studentId);
                    if(!cr.retrieveOutputFile(section, assignment, studentId, "Documents"))
                    {
                        output_text_area.setText(fileNotFound);
                    }
                    else
                    {
                        FileWrite fr = new FileWrite(file.getPath() + "//Output.txt");
                        output_text_area.setText((String) fr.GetData(file.getPath() + "//Output.txt"));
                    }
                    if(!cr.retrieveErrorFile(section, assignment, studentId, "Documents"))
                    {
                        errors_text_area.setText(fileNotFound);
                    }
                    else
                    {
                        FileWrite fr = new FileWrite(file.getPath() + "//Error.txt");
                        errors_text_area.setText((String) fr.GetData(file.getPath() + "//Error.txt"));
                    }
                    if(!cr.retrieveDocumentationFile(section, assignment, studentId, "Documents"))
                    {
                        amd_text_area.setText(fileNotFound);
                    }
                    else
                    {
                        FileWrite fr = new FileWrite(file.getPath() + "//Documentation.txt");
                        amd_text_area.setText((String) fr.GetData(file.getPath() + "//Documentation.txt"));
                    }
                    if(!cr.retrieveMagicNumbersFile(section, assignment, studentId, "Documents"))
                    {
                        magic_text_area.setText(fileNotFound);
                    }
                    else
                    {
                        FileWrite fr = new FileWrite(file.getPath() + "//MagicNumbers.txt");
                        magic_text_area.setText((String) fr.GetData(file.getPath() + "//MagicNumbers.txt"));
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                
            }
            
        });
        
        rubric_choice_box.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                
                double minGrade = 0.0;
                double maxGrade = 100.0;
                criteria_vbox.getChildren().clear();
                try {
                    //Display all criteria
                    //Get Criteria from DB
                    RubricCriteriaCRUD cr = new RubricCriteriaCRUD();
                    ObservableList<String> criteria = FXCollections.observableArrayList(cr.getCriteria(newValue));
                    percentTotalList = new Double[criteria.size()];
                    percentChosenList = new Double[criteria.size()];
                    int criteriaCounter = 0;
                    for(String s : criteria)
                    {
                        
                        ArrayList<Double> criteriaItems = cr.retrieveCriteriaList(newValue, s);
                        
                        HBox hb = new HBox();
                        hb.setId("" + criteriaCounter);

                        Label criteriaName = new Label();
                        Label percentTotal = new Label();

                        RadioButton goodGradeRadio = new RadioButton();
                        RadioButton moderateGradeRadio = new RadioButton();
                        RadioButton badGradeRadio = new RadioButton();

                        TextField customGrade = new TextField();
                        customGrade.setText("");
                        customGrade.setTextFormatter(new TextFormatter<>(filter));
                        customGrade.setMaxWidth(textFieldWidth);

                        //Get values from list of criteria and apply
                        criteriaName.setText(s);
                        percentTotal.setText("" + criteriaItems.get(0));
                        percentTotalList[criteriaCounter] = criteriaItems.get(0);

                        ToggleGroup group = new ToggleGroup();
                        goodGradeRadio.setText("" + criteriaItems.get(1));
                        goodGradeRadio.setToggleGroup(group);
                        moderateGradeRadio.setText("" + criteriaItems.get(2));
                        moderateGradeRadio.setToggleGroup(group);
                        badGradeRadio.setText("" + criteriaItems.get(3));
                        badGradeRadio.setToggleGroup(group);

                        customGrade.setOnMouseClicked(new EventHandler<MouseEvent>() {

                            @Override
                            public void handle(MouseEvent event) {
                                group.selectToggle(null);
                            }
                        });

                        customGrade.textProperty().addListener(new ChangeListener<String>() {

                            @Override
                            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                                if(!newValue.isEmpty() && !newValue.equals("."))
                                {
                                    double grade = Double.parseDouble(customGrade.getText());
                                    if(grade >= minGrade && grade <= maxGrade)
                                    {
                                        percentChosenList[Integer.parseInt(customGrade.getParent().getId())] = grade;
                                    }
                                } 
                            }
                        });

                        group.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
                            @Override
                            public void changed(ObservableValue<? extends Toggle> observable, Toggle oldValue, Toggle newValue) {

                                if(!customGrade.getText().equals(""))
                                {
                                    customGrade.setText("");
                                }
                            }
                        });

                        goodGradeRadio.selectedProperty().addListener(new ChangeListener<Boolean>() {
                            @Override
                            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {

                                if(newValue)
                                {
                                    percentChosenList[Integer.parseInt(goodGradeRadio.getParent().getId())] = Double.parseDouble(goodGradeRadio.getText());
                                }
                            }
                        });

                        moderateGradeRadio.selectedProperty().addListener(new ChangeListener<Boolean>() {

                            @Override
                            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
                                if(newValue)
                                {
                                    percentChosenList[Integer.parseInt(moderateGradeRadio.getParent().getId())] = Double.parseDouble(moderateGradeRadio.getText());
                                }
                            }

                        });

                        badGradeRadio.selectedProperty().addListener(new ChangeListener<Boolean>() {

                            @Override
                            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
                                if(newValue)
                                {
                                    percentChosenList[Integer.parseInt(goodGradeRadio.getParent().getId())] = Double.parseDouble(badGradeRadio.getText());
                                }
                            }
                        });

                        Region r = new Region();
                        HBox.setHgrow(r, Priority.ALWAYS);

                        hb.getChildren().addAll(criteriaName, r, percentTotal, goodGradeRadio,
                                moderateGradeRadio, badGradeRadio, customGrade);
                        hb.setSpacing(hBoxSpacing);

                        criteria_vbox.getChildren().add(hb);
                        //Enable Assign Grade
                        assign_grade_button.setDisable(false);
                        criteriaCounter++;
                        
                    } 
                }catch (SQLException ex) {
                    Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });   
    }
    
    @FXML
    private void goToPreviousStudent(ActionEvent event)
    {
        int studentIndex = student_choice_box.getSelectionModel().getSelectedIndex();
        if(studentIndex>0)
        {
            student_choice_box.getSelectionModel().select(--studentIndex);
        }
    }
    
    @FXML
    private void goToNextStudent(ActionEvent event)
    {
        int studentIndex = student_choice_box.getSelectionModel().getSelectedIndex();
        if(studentIndex<studentItems.size()-1)
        {
            student_choice_box.getSelectionModel().select(++studentIndex);
        }
    }
    
    @FXML
    private void assignGrade(ActionEvent event)
    {
        double divisor = 100.0;
        {
            double sum = 0.0;
            try {
                RubricCriteriaCRUD cr = new RubricCriteriaCRUD();
                RubricGradeCRUD cr2 = new RubricGradeCRUD();
                ObservableList<String> criteria = FXCollections.observableArrayList(cr.getCriteria((String) rubric_choice_box.getSelectionModel().getSelectedItem()));
                int count = 0;
                for(String s : criteria)
                {
                    ArrayList<Double> criteriaItems = cr.retrieveCriteriaList((String) rubric_choice_box.getSelectionModel().getSelectedItem(), s);
                    double total = criteriaItems.get(0);
                    double grade = total * percentChosenList[count];
                    sum += grade;
                    count++;
                    sum = sum/divisor;
                    grade = grade/divisor;
                    totalGradeLabel.setText("Total Grade: " + sum);
                    String sectionName = (String) section_choice_box.getSelectionModel().getSelectedItem();
                    String[] f = sectionName.split("---");
                    Integer studentId = Integer.parseInt(f[f.length-1]);
                    cr2.Create((String) assignment_choice_box.getSelectionModel().getSelectedItem(),
                            sectionName, studentId, (String) rubric_choice_box.getSelectionModel().getSelectedItem(),
                            s, grade);
                }
            } catch (SQLException ex) {
                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    
    /**
     * Saves the inputs to a text file. Also updates the Saved Inputs dropdown.
     * TODO: Modify for database
     *
     * @param event
     */
    @FXML
    private void SaveButtonOnAction(ActionEvent event) {
        FileWrite FW = new FileWrite("Input.txt");
        try {
            FileWrite FW1 = new FileWrite("Hello.txt");
            InputTextinfo inputTextinfo = new InputTextinfo(InputName.getText(), Calendar.getInstance().getTime());
            inputTextinfo.setInputText(inputsList);
            FW1.UpdateData(inputTextinfo, "Hello.txt");
        } catch (IOException ex) {
            Logger.getLogger(CommandExecutor.class.getName()).log(Level.SEVERE, null, ex);
        }
        SaveInputTextChoiceBox.getItems().add(SavedInputsController.getInputs().get(SavedInputsController.getInputs().size() - 1));
    }

    /**
     * Start Grading/End Grading onAction Handler
     *
     * @param event
     * @throws IOException
     */
    @FXML
    private void StartEndGradingOnAction(ActionEvent event) throws IOException {
        if (startGrading.getText().equals("End Grading")) {
            projectRunEndSequence();
        } else {
            projectRunStartSequence();
        }
    }

    /**
     * Sequence of operations for starting the project to be graded
     */
    private void projectRunStartSequence() {
        cmdExec = new CommandExecutor(this);
        ArrayList<String> commands = new ArrayList<>();
        String runCommand = "java -jar ";
        String runParam = ProjectJarLocation;
        commands.add(runCommand);
        commands.add(runParam);
        cmdExec.execute(commands);
        startGrading.setText("End Grading");
    }

    /**
     * Sequence of Operations to terminate and reset values
     *
     * @throws IOException
     */
    public void projectRunEndSequence() throws IOException {
        cmdExec.setPipeOpen(false);
        startGrading.setText("Start Grading");
        inputWindow.setText("");
        outputWindow.setText("");
        errorWindow.setText("");
        errorsList.clear();
        inputsList.clear();
        outputsList.clear();
    }

    /**
     * OnAction Hander whenever an input is sent to the project being graded
     * (run)
     *
     * @param event
     */
    @FXML
    private void enterInputs(ActionEvent event) {
        TempInputCommand.add(inputTextArea.getText());
        inputTextArea.setText("");
    }

    /**
     * Unzips a project zip file and looks for the .jar filepath file which it
     * stores.
     *
     * @param event
     * @throws IOException
     */
    @FXML
    private void unzipFile(ActionEvent event) throws IOException {
        Unzipper unzipper = new Unzipper();
        FilePathPickerDialog getZipFile = new FilePathPickerDialog();
        String destinationFilePath = "UnzippedProject";
        String ZipFilePath = getZipFile.obtainFilePath(destinationFilePath, "zip");

        ProjectJarLocation = unzipper.FileUnzipper(ZipFilePath, destinationFilePath);
        if (ProjectJarLocation == null) {
            //TODO: Change System.out.println to dialog box
            JOptionPane.showMessageDialog(null, "Project jar not found", "Unzipped Project", 0);
        } else {
            //TODO: Change System.out.println to dialog box
            JOptionPane.showMessageDialog(null, " Project jar found", "Unzipped Project", 1);
        }
    }

    /**
     * used to update text areas whenever an input, output or error occurs on
     * the project
     */
    public void UpdateTextAreas() {
        String ErrorText = "";
        for (String errors : errorsList) {
            ErrorText = ErrorText.concat("\n").concat(errors);
        }

        String OutputText = "";
        for (String Outputs : outputsList) {
            OutputText = OutputText.concat("\n").concat(Outputs);

        }

        String InputText = "";
        for (String Inputs : inputsList) {
            InputText = InputText.concat("\n").concat(Inputs);
        }
        outputWindow.setText(OutputText);
        inputWindow.setText(InputText);
        errorWindow.setText(ErrorText);

    }

    /**
     * used by the jar executor to get and set error, input, output, InputName,
     * TempInputCommand values
     *
     * @param errorsList
     */
    public void setErrorsList(ArrayList<String> errorsList) {
        this.errorsList = errorsList;
    }

    public void setInputsList(ArrayList<String> inputsList) {
        this.inputsList = inputsList;
    }

    public void setOutputsList(ArrayList<String> outputsList) {
        this.outputsList = outputsList;
    }

    public ArrayList<String> getErrorsList() {
        return errorsList;
    }

    public ArrayList<String> getInputsList() {
        return inputsList;
    }

    public ArrayList<String> getOutputsList() {
        return outputsList;
    }

    public String getInputNameText() {
        return InputName.getText();
    }

    /**
     *
     * @return the last value inputed into the input text window. This will be
     * sent to project to be processed.
     */
    public String getTempInputCommand() {
        return TempInputCommand.remove(0);
    }

    public boolean TempInputCommandIsEmpty() {
        return TempInputCommand.isEmpty();
    }

    /**
     * Creates a new Rubric if new Rubric is selected in rubric_name_dropdown.
     * InputBox appears asking for the Rubric name. Updates an existing Rubric
     * if a Rubric is chosen in rubric_name_dropdown.
     *
     * @param event Button Click
     */
    @FXML
    private void saveRubric(ActionEvent event) {
        String rubricNameSelection = (String) rubric_name_dropdown.getSelectionModel().getSelectedItem();
        String rubricTypeSelection = (String) rubric_type_dropdown.getSelectionModel().getSelectedItem();

        //This for loop retrieves the text from each text field and assigns it
        //to a variable in order to create a criteria.
        if (rubricNameSelection != null && rubricTypeSelection != null) {
            //If new rubric
            if (rubricNameSelection.equals(newRubric)) {
                createRubric(rubricNameSelection, rubricTypeSelection);
            } else {
                //If rubric is updated
                updateRubric(rubricNameSelection, rubricTypeSelection);
            }

        }

    }

    /**
     * Creates a new HBox with TextFields and a Button. There is a standardized
     * naming method for these creations.
     *
     * @param event Button Click
     */
    @FXML
    private void createNewCriterion(ActionEvent event) {
        makeNewCriterion("", "", "", "", "");
    }

    /**
     * Adds new criterion to the GUI
     *
     * @param criterionName
     * @param percentTotal
     * @param goodPercentage
     * @param moderatePercentage
     * @param badPercentage
     */
    private void makeNewCriterion(String criterionName, String percentTotal, String goodPercentage, String moderatePercentage, String badPercentage) {
        HBox hb = new HBox();
        hb.setSpacing(spacing);
        hb.setId("h" + count);
        ArrayList<TextField> textFieldList = new ArrayList<>(numTextFields);
        for (int i = 0; i < numTextFields; i++) {
            TextField txt = new TextField();
            txt.setPrefWidth(textFieldWidth);
            textFieldList.add(txt);
            switch (i) {
                case 0:
                    textFieldList.get(i).setId("c" + count);
                    textFieldList.get(i).setText(criterionName);
                    break;

                case 1:
                    txt.setTextFormatter(new TextFormatter<>(filter));
                    textFieldList.get(i).setId("p" + count);
                    textFieldList.get(i).setText(percentTotal);
                    break;

                case 2:
                    txt.setTextFormatter(new TextFormatter<>(filter));
                    textFieldList.get(i).setId("g" + count);
                    textFieldList.get(i).setText(goodPercentage);
                    break;

                case 3:
                    txt.setTextFormatter(new TextFormatter<>(filter));
                    textFieldList.get(i).setId("m" + count);
                    textFieldList.get(i).setText(moderatePercentage);
                    break;

                case 4:
                    txt.setTextFormatter(new TextFormatter<>(filter));
                    textFieldList.get(i).setId("b" + count);
                    textFieldList.get(i).setText(badPercentage);
                    break;
            }
            hb.getChildren().add(textFieldList.get(i));
        }
        Button deleteCriterion = new Button();
        deleteCriterion.setId("d" + count);
        deleteCriterion.setText(criterionDeleteButtonName);
        deleteCriterion.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Button pressed = (Button) event.getSource();
                Integer findCount = Integer.parseInt(pressed.getId().substring(pressed.getId().length() - 1));
                HBox hbToBeDeleted = (HBox) vb.getChildren().get(findCount);
                vb.getChildren().remove(hbToBeDeleted);
                updateButtonId();
            }
        });
        hb.getChildren().add(deleteCriterion);
        count++;
        System.out.println("Adding hb to vb");
        vb.getChildren().add(hb);
        System.out.println("vb size after add: " + vb.getChildren().size());
    }

    private void createRubric(String rubricNameSelection, String rubricTypeSelection) {
        if (!validateTextFields()) {
            return;
        }
        do {
            rubricNameSelection = JOptionPane.showInputDialog("Enter Rubric Name: ");
        } while (validateRubricName(rubricNameSelection));

        try {
            RubricCRUD cr2 = new RubricCRUD();
            cr2.create(rubricNameSelection, rubricTypeSelection);
            
            ObservableList<String> rubrics = FXCollections.observableArrayList(cr2.getRubricNames());
            rubrics.add(0 ,newRubric);
            rubric_name_dropdown.setItems(rubrics);
            addAllCriteria(rubricNameSelection);
            resetUserInput();
            
            
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }


    private void updateRubric(String rubricNameSelection, String rubricTypeSelection) {
        if (!validateTextFields()) {
            return;
        }
        try {
            RubricCRUD cr = new RubricCRUD();
            RubricGradeCRUD cr2 = new RubricGradeCRUD();
                cr.update(rubricNameSelection, rubricTypeSelection);
                addAllCriteria(rubricNameSelection);
                /*ArrayList<ArrayList<String>> pks = cr2.getRubrics(rubricNameSelection);
                for(ArrayList<String> a : pks)
                {
                    if(!cr2.Update(a.get(3), a.get(0), Integer.parseInt(a.get(2)), 
                            rubricNameSelection, a.get(1), 0.0))
                    {
                        cr2.Create(a.get(3), a.get(0), Integer.parseInt(a.get(2)), 
                            rubricNameSelection, a.get(1), 0.0);
                    }
                }*/
                resetUserInput();
            
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private boolean validateTextFields() {
        for (int i = 0; i < vb.getChildren().size(); i++) {
            HBox hBox = (HBox) vb.getChildren().get(i);
            for (int k = 0; k < hBox.getChildren().size() - 1; k++) {
                TextField tField = (TextField) hBox.getChildren().get(k);
                if (tField.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "A Field is Empty");
                    criteriaArray = null;
                    return false;
                }
            }
        }
        return true;
    }

    private boolean validateRubricName(String name) {
        try {
            RubricCRUD cr = new RubricCRUD();
            ObservableList<String> rubrics = FXCollections.observableArrayList(cr.getRubricNames());
            for(String s : rubrics)
            {
                if(name.equals(s)) {
                    return true; 
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    /**
     * Deletes a the existing selected Rubric in rubric_name_dropdown.
     *
     * @param event Button Click
     */
    @FXML
    private void deleteRubric(ActionEvent event) {

        
        String rubricName = (String) rubric_name_dropdown.getSelectionModel().getSelectedItem();
        if(!rubricName.equals(newRubric))
        {
            try {
                RubricCRUD cr = new RubricCRUD();
                RubricCriteriaCRUD cr2 = new RubricCriteriaCRUD();
                RubricGradeCRUD cr3 = new RubricGradeCRUD();
                ObservableList<String> criteria = FXCollections.observableArrayList(cr2.getCriteria(rubricName));
                for(String s : criteria)
                {
                    cr2.delete(rubricName, s);
                }
                ArrayList<ArrayList<String>> pks = cr3.getRubrics(rubricName);
                for(ArrayList<String> a : pks)
                {
                    cr3.Delete(a.get(3), a.get(0), Integer.parseInt(a.get(2)), rubricName, a.get(1));
                }
                cr.Delete(rubricName);
                ObservableList<String> rubrics = FXCollections.observableArrayList(cr.getRubricNames());
                rubrics.add(0 , newRubric);
                rubric_name_dropdown.setItems(rubrics);
            } catch (SQLException ex) {
                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            }
            resetUserInput();
        }
        
    }

    private void updateButtonId() {
        count = 0;
        for (Node node1 : vb.getChildren()) {
            HBox hbox = (HBox) node1;
            for (Node node2 : hbox.getChildren().subList(hbox.getChildren().size() - 1, hbox.getChildren().size())) {
                Button b = (Button) node2;
                b.setId("d" + count);
                b.setText(criterionDeleteButtonName);
                count++;
            }
        }
    }

    private void addAllCriteria(String rubricNameSelection) {
        boolean contained = false;
        try {
            RubricCRUD cr = new RubricCRUD();
            ObservableList<String> rubrics = FXCollections.observableArrayList(cr.getRubricNames());
            if(rubrics.contains(rubricNameSelection))
            {
                contained = true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        ArrayList<ArrayList<String>> criteria = new ArrayList<>();
        String name = "";
        double percentTotal = 0;
        double goodPercent = 0;
        double moderatePercent = 0;
        double badPercent = 0;
        double totalPercentSum = 0.0;
        double minimum = 0.0;
        double maximum = 100.0;
        System.out.println("vb size before loop: " + vb.getChildren().size());
        for (int i = 0; i < vb.getChildren().size(); i++) {
            ArrayList<String> a = new ArrayList<>();
            criteria.add(a);
            HBox hBox = (HBox) vb.getChildren().get(i);

            for (int j = 0; j < hBox.getChildren().size()-1; j++) {
                TextField tField = (TextField) hBox.getChildren().get(j);
                switch (j) {
                    case 0:
                        name = tField.getText();
                        int count = 0;
                        for (int k = i+1; k < vb.getChildren().size(); k++) {
                            HBox testBox = (HBox) vb.getChildren().get(k);
                            TextField testfield = (TextField) testBox.getChildren().get(j);
                            if (name.equals(testfield.getText())) {
                                name = JOptionPane.showInputDialog(name + " already exists. Enter a different name:");
                                tField.setText(name);
                                count++;
                                j--;
                                break;
                            }
                        }
                        if (count == 0) {
                            System.out.println(name);
                            criteria.get(i).add(name);
                        }
                        break;
                    case 1:
                        percentTotal = Double.parseDouble(tField.getText());
                        System.out.println("total: " + percentTotal);
                        if (percentTotal >= minimum && percentTotal <= maximum) {
                            criteria.get(i).add("" + percentTotal);
                        } else {
                            percentTotal = Double.parseDouble(JOptionPane.showInputDialog(percentTotal + " must be greater than or equal to " + minimum
                                    + "and less than or equal to " + maximum + ". Enter a different percentage:"));
                            tField.setText(Double.toString(percentTotal));
                            j--;
                        }
                        break;
                    case 2:
                        goodPercent = Double.parseDouble(tField.getText());
                        System.out.println("good: " + goodPercent);
                        if (goodPercent >= minimum && goodPercent <= maximum) {
                            criteria.get(i).add("" + goodPercent);
                        } else {
                            goodPercent = Double.parseDouble(JOptionPane.showInputDialog(goodPercent + " must be greater than or equal to " + minimum
                                    + "and less than or equal to " + maximum + ". Enter a different percentage:"));
                            tField.setText(Double.toString(goodPercent));
                            j--;
                        }
                        break;
                    case 3:
                        moderatePercent = Double.parseDouble(tField.getText());
                        System.out.println("mod: " + moderatePercent);
                        if (moderatePercent >= minimum && moderatePercent <= maximum) {
                            criteria.get(i).add("" + moderatePercent);
                        } else {
                            moderatePercent = Double.parseDouble(JOptionPane.showInputDialog(moderatePercent + " must be greater than or equal to " + minimum
                                    + "and less than or equal to " + maximum + ". Enter a different percentage:"));
                            tField.setText(Double.toString(moderatePercent));
                            j--;
                        }
                        break;
                    case 4:
                        badPercent = Double.parseDouble(tField.getText());
                        System.out.println("bad: " + badPercent);
                        if (badPercent >= minimum && badPercent <= maximum) {
                            criteria.get(i).add("" + badPercent);
                        } else {
                            badPercent = Double.parseDouble(JOptionPane.showInputDialog(badPercent + " must be greater than or equal to " + minimum
                                    + "and less than or equal to " + maximum + ". Enter a different percentage:"));
                            tField.setText(Double.toString(badPercent));
                            j--;
                        }
                        break;
                    default:
                        System.out.println("sorry try again");
                }
            }
        }
        System.out.println("criteria size before sum: " + criteria.size());
        for (int j = 0; j < criteria.size(); j++) {
            System.out.println("criteria totalP: " + criteria.get(j).get(1));
            totalPercentSum += Double.parseDouble(criteria.get(j).get(1));
        }
        if (totalPercentSum != maximum) {
            criteria = null;
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Check Input");
            alert.setHeaderText(null);
            alert.setContentText("The total percent sum is: " + totalPercentSum + ". Fix then click save to save this rubric.");
            alert.showAndWait();
        }
        try {
            RubricCriteriaCRUD cr = new RubricCriteriaCRUD();
            if(criteria != null)
            {
                for(ArrayList<String> a : criteria)
                {
                    if(contained)
                    {
                        boolean updated = !cr.Update(rubricNameSelection, a.get(0), Double.parseDouble(a.get(1)), Double.parseDouble(a.get(2)),
                        Double.parseDouble(a.get(3)), Double.parseDouble(a.get(4)));
                        if(updated)
                        {
                            cr.delete(rubricNameSelection, a.get(0));
                            cr.create(rubricNameSelection, a.get(0), Double.parseDouble(a.get(1)), Double.parseDouble(a.get(2)),
                            Double.parseDouble(a.get(3)), Double.parseDouble(a.get(4)));
                        }
                    }
                    else
                    {
                        cr.create(rubricNameSelection, a.get(0), Double.parseDouble(a.get(1)),
                        Double.parseDouble(a.get(2)), Double.parseDouble(a.get(3)), 
                        Double.parseDouble(a.get(4)));
                    }
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void clearVBox() {
        vb.getChildren().clear();
        updateButtonId();

    }

    private void updateVBox() {
            clearVBox();
            try {
                RubricCriteriaCRUD cr = new RubricCriteriaCRUD();
                String rubricName = (String) rubric_name_dropdown.getSelectionModel().getSelectedItem();
                if(rubricName != newRubric)
                {   
                    ObservableList<String> criteria = FXCollections.observableArrayList(cr.getCriteria(rubricName));
                    for(String s : criteria)
                    {
                        ArrayList<Double> criteriaList = cr.retrieveCriteriaList(rubricName, s);
                        for(int i = 0; i < criteriaList.size(); i++)
                        {
                            System.out.println(criteriaList.get(i));
                        }
                        makeNewCriterion(s, "" + criteriaList.get(0), "" + criteriaList.get(1), "" + criteriaList.get(2), "" + criteriaList.get(3));
                    }
                }
            } catch (SQLException ex) {
                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    private void resetUserInput() {
        clearVBox();
        rubric_name_dropdown.setValue(null);
        rubric_type_dropdown.setValue(null);
        rubric_type_dropdown.setDisable(true);
        new_criterion_button.disableProperty().set(true);
        save_button.disableProperty().set(true);
        delete_button.disableProperty().set(true);
    }

    /**
     * This button controls saving the course information, and handles all error
     * handling that might occur in the saving process.
     * @param event
     * @throws IOException 
     */
    @FXML
    private void handleSaveButton(ActionEvent event) throws IOException {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(errorMessageTitle);
        alert.setHeaderText(errorMessageHeader);
        String subject = "";
        String number = "";
        String section = "";
        String term = "";
        String year = "";
        if(textContainsInts(subjectBox.getText())){
            alert.setContentText(subjectErrorText);
            alert.showAndWait();
        } else if(!textIsOnlyInts(numberBox.getText())){
            alert.setContentText(numberErrorText);
            alert.showAndWait();
        } else if(textContainsInts(sectionBox.getText())){
            alert.setContentText(sectionErrorText);
            alert.showAndWait();
        } else if(!textIsOnlyInts(yearBox.getText())){
            alert.setContentText(yearErrorText);
            alert.showAndWait();
        } else if(termDropDown.getSelectionModel().getSelectedItem() == null ){
            alert.setContentText(termErrorText);
            alert.showAndWait();
        } else{
            //Assigns the inputs to variables for use in creating a file, later to 
            //be used to updated the database
            subject = subjectBox.getText().toUpperCase();
            number = numberBox.getText();
            section = sectionBox.getText().toUpperCase();
            year = yearBox.getText();
            term = termDropDown.getSelectionModel().getSelectedItem().toString();
            File course = new File(subject+number+section+term+year);
            System.out.println(course.getName());
            course.createNewFile();
            if(!courseNames.contains(course.getName())){
                courseNames.add(course.getName());
            }
        }
        
    }
    
    /**
     * This method checks to see if a text input contains any numbers.
     * @param testText
     * @return 
     */
    private boolean textContainsInts(String testText){
        for(int i = 0; i < testText.length(); i++){
            if(Character.isDigit(testText.charAt(i))){
                return true;
            }
        }
        return false;
    }

    /**
     * This method verifies that a text input only contains numbers.
     * @param testText
     * @return 
     */
    private boolean textIsOnlyInts(String testText){
        for(int i = 0; i < testText.length(); i++){
            if(Character.isLetter(testText.charAt(i))){
                return false;
            }
        }
        return true;
    }
    
    @FXML
    private void handleDeleteButton(ActionEvent event) {
        
    }
    
    /**
     * This button will delete whatever names are selected by referencing the
     * checked boxes.
     * @param event 
     */
    @FXML
    private void handleDeleteSelectedButton(ActionEvent event) {
        for(CheckBox c : checkBoxes)
        {
            int hBoxNum = Integer.parseInt(c.getId());
            HBox hbox = (HBox) studentVBox.getChildren().get(hBoxNum);
            studentVBox.getChildren().remove(hbox);
            updateBoxID();
        }
        checkBoxes.clear();
    }
    
    /**
     * This method is used for updating the IDs of the boxes, for ease of tracking.
     */
    private void updateBoxID() {
        hBoxCount = 0;
        int numBoxes = studentVBox.getChildren().size();
        for(int i = 0; i < numBoxes; i++)
        {
            HBox hBox = (HBox) studentVBox.getChildren().get(i);
            hBox.setId("" + hBoxCount);
            hBox.getChildren().get(hBox.getChildren().size()-1).setId("" + hBoxCount);
            hBoxCount++;
        }      
    }
    
    /**
     * This button marks all check boxes on first click, and unmarks them all
     * on the second click.
     * @param event 
     */
    @FXML
    private void handleMarkAllButton(ActionEvent event) {
        switch(markAllCount%2){
            case 0: for(int i = 0; i<hBoxCount; i++){
                            HBox hBox = (HBox) studentVBox.getChildren().get(i);
                            CheckBox checkBox = (CheckBox) hBox.getChildren().get(2);
                            checkBox.setSelected(true);
                            checkBoxes.add(checkBox);
                        }; markAllButton.setText("Clear All"); break;
            case 1: for(int i = 0; i<hBoxCount; i++){
                            HBox hBox = (HBox) studentVBox.getChildren().get(i);
                            CheckBox checkBox = (CheckBox) hBox.getChildren().get(2);
                            checkBox.setSelected(false);
                        }; checkBoxes.clear(); markAllButton.setText("Mark All"); break;
        }
        markAllCount++;
    }
    
    /**
     * This button will add student names only if they have not been entered before
     * @param event 
     */
    @FXML
    private void handleAddStudentButton(ActionEvent event) {
        Student student = new Student(newStudentBox.getText(), 100);
        if(!newStudentBox.getText().equals(null)){
            if (!checkForStudent(student) && !newStudentBox.getText().equals(null)) {
                makeNewStudent(newStudentBox.getText());
                newStudentBox.setPromptText("Enter New Student Name Here");
                newStudentBox.clear();
            } else {
                if(!newStudentBox.getText().equals("")){
                    newStudentBox.setPromptText("Name Already Exists");
                    newStudentBox.clear();
                } else{
                    newStudentBox.setPromptText("Please Enter A Name");
                }
            }
        }
    }
    
    /**
     * This button will add students to the course that is selected
     * @param event 
     */
    @FXML
    private void handleAssignStudentsButton(ActionEvent event) {
        String courseName = courseDropDown.getSelectionModel().getSelectedItem().toString();
        if(new File(courseName).isFile()){
            File course = new File(courseName);
            try {
                fileOutputStream = new FileOutputStream(course);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            //This loop gets the student name associated to the row that contains the checked boxes
            for(CheckBox checkBox : checkBoxes){
                try {
                    HBox hbox = (HBox) studentVBox.getChildren().get(Integer.parseInt(checkBox.getId()));
                    Label nameLbl = (Label) hbox.getChildren().get(0);
                    String studentName = nameLbl.getText();
                    byte[] bytes = studentName.getBytes();
                    fileOutputStream.write(bytes);
                    fileOutputStream.write("\n".getBytes());
                } catch (IOException ex) {
                    Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            }
        }
    }
    
    /**
     * Same as initialize method... did it to keep our main one less clunky.
     */
    private void initializeCourseTab() {
        disableCourseCreatorOptions();
        assingmentPane.setVisible(false);
        assingmentPane.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, new CornerRadii(10), new BorderWidths(3))));
        courseDropDown.setItems(courseNames);
        courseDropDown.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                if(newValue != null){
                    enableCourseCreatorOptions();
                }
                if(newValue.compareTo("New Course") == 0){
                    emptyCourseCreatorOptions();
                }
            }
        });
        termDropDown.setItems(termNames);
    }
    
    /**
     * Disables the section title input areas.
     */
    private void disableCourseCreatorOptions(){
        subjectBox.setDisable(true);
        numberBox.setDisable(true);
        sectionBox.setDisable(true);
        termDropDown.setDisable(true);
        yearBox.setDisable(true);
        saveButton.setDisable(true);
        deleteButton.setDisable(true);
    }
    
    /**
     * Enables the section title input areas.
     */
    private void enableCourseCreatorOptions(){
        subjectBox.setDisable(false);
        numberBox.setDisable(false);
        sectionBox.setDisable(false);
        termDropDown.setDisable(false);
        yearBox.setDisable(false);
        saveButton.setDisable(false);
        deleteButton.setDisable(false);
    }
    
    /**
     * Clears the previously entered data from each field in the title input areas.
     */
    private void emptyCourseCreatorOptions(){
        subjectBox.clear();
        numberBox.clear();
        sectionBox.clear();
        termDropDown.setValue(null);
        yearBox.clear();
    }
    
    /**
     * This method creates a new student instance and adds a row to the scroll pane.
     * This row also contains a checkbox, of whose event handler attributes are
     * set here.
     * @param name 
     */
    private void makeNewStudent(String name){
        HBox hbox = new HBox();
        Region r = new Region(); //Blank region used for spacing
        HBox.setHgrow(r, Priority.ALWAYS); //This is used for good spacing
        hbox.setId("" + hBoxCount);
        Label nameLbl = new Label();
        CheckBox checkBox = new CheckBox();
        nameLbl.setText(name);
        Student student = new Student(name, 100);
        students.add(student);
        nameLbl.setFont(Font.font(fontType, fontSize));
        checkBox.setId("" + hBoxCount);
        checkBox.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                if(checkBox.isSelected()){
                    checkBoxes.add(checkBox);
                }
                else{
                    checkBoxes.remove(checkBox);
                }
            }
        });
        hbox.getChildren().addAll(nameLbl, r, checkBox);
        hBoxCount++;
        studentVBox.getChildren().add(hbox);
    }
    
    /**
     * This checks to see if the entered student name already exists.
     * @param student
     * @return 
     */
    private boolean checkForStudent(Student student){
        return students.contains(student);
    }
    
    /**
     * @FXML
    private Button assingmentAccessButton;
    @FXML
    private Button assingmentSaveButton;
    @FXML
    private Button assingmentDoneButton;
    @FXML
    private Button assingmentDeleteButton;
    @FXML
    private ChoiceBox assingmentDrop;
    @FXML
    private ChoiceBox sectionDrop;
    @FXML
    private TextField assingmentTextField;
    @FXML
    private Pane assingmentPane;
     * 
     * 
     */
    
    @FXML
    private void handleassingmentAccessButton(ActionEvent event){
        
        assingmentPane.setVisible(true);
        sectionDrop.setValue("Insert call to database");
        
    }
    @FXML
    private void handleassingmentDoneButton(ActionEvent event){
        
        assingmentPane.setVisible(false);
        
        
    }
    @FXML
    private void handleassingmentSaveButton(ActionEvent event){
     /*   
            
     for(int i=0;i<courses.size();i++){
         
         if(courseDrop.getValue().equals(courses.get(i))){
             
             assingmentDrop.setItems(courses.get(i).getAssingment());
             
         }
         
     }
     
     
       
      if(!assingments.contains(assingmentField.getText())&&!assingmentField.getText().equals("")){ 
      
        if(assingmentDrop.getValue().toString().equals("Create New Assingment")){
            
            assingments.add(assingmentField.getText());
            assingmentDrop.setItems( assingments);
          
        }
        else if(!assingmentDrop.getValue().equals("Create New Assingment")){
            
            assingments.remove(assingmentDrop.getValue().toString());
            assingments.add(assingmentField.getText());
            assingmentDrop.setItems(assingments);
        }
      
      }
       */
      
        
        
    }
    @FXML
    private void handleassingmentDeleteButton(ActionEvent event){
        /*
         if(assingments.contains(assingmentDrop.getValue())&&!assingmentDrop.getValue().equals("Create New Assingment")){
          
          assingments.remove(assingmentDrop.getValue());
          assingmentDrop.setItems(assingments);
      }
        */
    }
    
    
}
