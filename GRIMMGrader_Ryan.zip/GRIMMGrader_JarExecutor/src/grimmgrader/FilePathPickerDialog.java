/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grimmgrader;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;
import net.lingala.zip4j.exception.ZipException;

/**
 *
 * @author Anthony
 */
public class FilePathPickerDialog {

    public String obtainFilePath(String destinationFilePath, String FileType) throws IOException {
        Unzipper u = new Unzipper();
        String ou = destinationFilePath;
        String absolutePath = "";

        JFileChooser jfc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
        jfc.setDialogTitle("Select a "+FileType+" File");
        jfc.setAcceptAllFileFilterUsed(false);
        FileNameExtensionFilter filter = new FileNameExtensionFilter(FileType+" Files", FileType);
        jfc.addChoosableFileFilter(filter);
        int returnValue = jfc.showOpenDialog(null);
        if (returnValue == JFileChooser.APPROVE_OPTION) {

            File selectedFile = jfc.getSelectedFile();
            u.FileUnzipper(selectedFile.getAbsolutePath(), ou);
            absolutePath = selectedFile.getAbsolutePath();
        }
        System.out.println("");
        return absolutePath;
    }
}
