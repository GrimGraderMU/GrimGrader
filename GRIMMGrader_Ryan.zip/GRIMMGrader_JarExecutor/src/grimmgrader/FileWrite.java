/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grimmgrader;

/**
 *
 * @author Anthony
 */
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 *
 * @author Anthony
 */
public class FileWrite {

    private String FileName = "inputTextSerialized.txt";
    private List<String> output = new ArrayList<>();

    public FileWrite(String FilePath) {
        FileName = FilePath;
    }

    public void printToFile(List<String> out) throws IOException {
        output = out;
        Path filePath = Paths.get(FileName);
        Files.write(filePath, output, Charset.forName("UTF-8"));
    }

    public Object GetData(String filePath) throws IOException {
        Object object = null;
        ObjectInputStream in=null;
        try {
            FileInputStream fis = new FileInputStream(filePath);
            if(fis.getChannel().size() != 0){
            in = new ObjectInputStream(fis);
            object = in.readObject();
            in.close();
            }
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return object;
    }

    public void UpdateData(Object Obj, String filePath) throws IOException {
        FileOutputStream fos = null;
        ObjectOutputStream out = null;
        
        List<Object> list= new ArrayList<>();
        List<Object> frofile= (List<Object>)GetData(filePath);
        if (frofile!=null) {
            list.addAll(frofile);
        }
         
        list.add(Obj);
        try {
            fos = new FileOutputStream(FileName);
            out = new ObjectOutputStream(fos);
            out.writeObject(list);

            out.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
  
    }

}
