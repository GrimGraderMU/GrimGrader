/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grimmgrader;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.util.Duration;
import javax.swing.JOptionPane;

/**
 *
 * @author Frehiwot Gudeta
 */
public class FXMLDocumentController implements Initializable {

    private ArrayList<String> errorsList = new ArrayList<>();
    private ArrayList<String> inputsList = new ArrayList<>();
    private ArrayList<String> outputsList = new ArrayList<>();
    private List<String> TempInputCommand = new ArrayList<>();
    private boolean StartedGrading = false;
    private String ProjectJarLocation = "";
    CommandExecutor cmdExec = null;
    private final Integer numTextFields = 5;
    private Integer count = 0;
    private final String newRubric = "new rubric";
    private ArrayList<ArrayList<String>> criteriaArray;
    private Rubric rubric;
    private ArrayList<Rubric> rubricList = new ArrayList<>();
    private ObservableList<String> rubricNameItems = FXCollections.observableArrayList();
    private ObservableList<String> rubricTypeItems = FXCollections.observableArrayList("Global", "Course", "Assignment");
    private String criterionDeleteButtonName = "delete";
    private Double spacing = 5.0;
    private Double textFieldWidth = 120.0;

    @FXML
    private AnchorPane root;
    @FXML
    private Label percentOfTotal;
    @FXML
    private Label goodPercentage;
    @FXML
    private Label moderatePercentage;
    @FXML
    private Label badPercentage;
    @FXML
    private Button save_button;
    @FXML
    private Button delete_button;
    @FXML
    private Button new_criterion_button;
    @FXML
    private ChoiceBox rubric_name_dropdown;
    @FXML
    private ChoiceBox rubric_type_dropdown;
    @FXML
    private VBox vb;
    @FXML
    private TextArea inputTextArea;
    @FXML
    private Button SaveInputButton;
    @FXML
    private ComboBox SaveInputTextChoiceBox;
    @FXML
    private TextArea outputWindow;
    @FXML
    private TextArea errorWindow;
    @FXML
    private TextField rubricWindow;
    @FXML
    private TextArea inputWindow;
    @FXML
    private Button startGrading;
    @FXML
    private Button enterInputs;
    @FXML
    private TextField InputName;

    private Scene welcomeScreenScene;
    private Scene parentScene;
    private StackPane welcomeScreenPane;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initalizeDropDowns();
        FadeInTransition(300);

    }

    public void FadeInTransition(double Millis) {
        FadeTransition fadein = new FadeTransition();
        fadein.setDuration(Duration.millis(Millis));
        fadein.setNode(root);
        fadein.setFromValue(0);
        fadein.setToValue(1);
        fadein.play();
    }

    private void initalizeDropDowns() {

        SaveInputTextChoiceBox.getItems().addAll(SavedInputsController.getInputs());
        SaveInputTextChoiceBox.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                TempInputCommand.addAll(SavedInputsController.getInputTextInfo().get(newValue.intValue()).getInputText());
                System.out.println(TempInputCommand.toString());
            }
        });

        vb.setSpacing(spacing);
        rubricNameItems.add(newRubric);
        rubric_name_dropdown.setItems(rubricNameItems);
        rubric_name_dropdown.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                if (newValue != null) {
                    delete_button.disableProperty().set(false);
                    rubric_type_dropdown.setDisable(false);
                    for (int i = 0; i < rubricList.size(); i++) {
                        if (rubricList.get(i).getRubricName().equalsIgnoreCase(newValue)) {
                            rubric = rubricList.get(i);
                        }
                    }
                    if (newValue.equalsIgnoreCase(newRubric)) {
                        clearVBox();
                        rubric = null;
                    }
                    updateVBox();
                }
            }
        });

        rubric_type_dropdown.setItems(rubricTypeItems);
        resetUserInput();
        rubric_type_dropdown.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                new_criterion_button.disableProperty().set(false);
                save_button.disableProperty().set(false);
            }
        });
    }

    /**
     * Saves the inputs to a text file. Also updates the Saved Inputs dropdown.
     * TODO: Modify for database
     *
     * @param event
     */
    @FXML
    private void SaveButtonOnAction(ActionEvent event) {
        FileWrite FW = new FileWrite("Input.txt");
        try {
            FileWrite FW1 = new FileWrite("Hello.txt");
            InputTextinfo inputTextinfo = new InputTextinfo(InputName.getText(), Calendar.getInstance().getTime());
            inputTextinfo.setInputText(inputsList);
            FW1.UpdateData(inputTextinfo, "Hello.txt");
        } catch (IOException ex) {
            Logger.getLogger(CommandExecutor.class.getName()).log(Level.SEVERE, null, ex);
        }
        SaveInputTextChoiceBox.getItems().add(SavedInputsController.getInputs().get(SavedInputsController.getInputs().size() - 1));
    }

    /**
     * Start Grading/End Grading onAction Handler
     *
     * @param event
     * @throws IOException
     */
    @FXML
    private void StartEndGradingOnAction(ActionEvent event) throws IOException {
        if (startGrading.getText().equals("End Grading")) {
            projectRunEndSequence();
        } else {
            projectRunStartSequence();
        }
    }

    /**
     * Sequence of operations for starting the project to be graded
     */
    private void projectRunStartSequence() {
        cmdExec = new CommandExecutor(this);
        ArrayList<String> commands = new ArrayList<>();
        String runCommand = "java -jar ";
        String runParam = ProjectJarLocation;
        commands.add(runCommand);
        commands.add(runParam);
        cmdExec.execute(commands);
        startGrading.setText("End Grading");
    }

    /**
     * Sequence of Operations to terminate and reset values
     *
     * @throws IOException
     */
    public void projectRunEndSequence() throws IOException {
        cmdExec.setPipeOpen(false);
        startGrading.setText("Start Grading");
        inputWindow.setText("");
        outputWindow.setText("");
        errorWindow.setText("");
        errorsList.clear();
        inputsList.clear();
        outputsList.clear();
    }

    /**
     * OnAction Hander whenever an input is sent to the project being graded
     * (run)
     *
     * @param event
     */
    @FXML
    private void enterInputs(ActionEvent event) {
        TempInputCommand.add(inputTextArea.getText());
        inputTextArea.setText("");
    }

    /**
     * Unzips a project zip file and looks for the .jar filepath file which it
     * stores.
     *
     * @param event
     * @throws IOException
     */
    @FXML
    private void unzipFile(ActionEvent event) throws IOException {
        Unzipper unzipper = new Unzipper();
        FilePathPickerDialog getZipFile = new FilePathPickerDialog();
        String destinationFilePath = "UnzippedProject";
        ProjectJarLocation = unzipper.FileUnzipper(getZipFile.obtainFilePath(destinationFilePath, "zip"), destinationFilePath);
        if (ProjectJarLocation == null) {
            //TODO: Change System.out.println to dialog box
            System.out.println("no jar found");
        } else {
            //TODO: Change System.out.println to dialog box
            System.out.println("Project found");
        }
    }

    /**
     * used to update text areas whenever an input, output or error occurs on
     * the project
     */
    public void UpdateTextAreas() {
        String ErrorText = "";
        for (String errors : errorsList) {
            ErrorText = ErrorText.concat("\n").concat(errors);
        }

        String OutputText = "";
        for (String Outputs : outputsList) {
            OutputText = OutputText.concat("\n").concat(Outputs);

        }

        String InputText = "";
        for (String Inputs : inputsList) {
            InputText = InputText.concat("\n").concat(Inputs);
        }
        outputWindow.setText(OutputText);
        inputWindow.setText(InputText);
        errorWindow.setText(ErrorText);

    }

    /**
     * used by the jar executor to get and set error, input, output, InputName, TempInputCommand values
     *
     * @param errorsList
     */
    public void setErrorsList(ArrayList<String> errorsList) {
        this.errorsList = errorsList;
    }

    public void setInputsList(ArrayList<String> inputsList) {
        this.inputsList = inputsList;
    }

    public void setOutputsList(ArrayList<String> outputsList) {
        this.outputsList = outputsList;
    }

    public ArrayList<String> getErrorsList() {
        return errorsList;
    }

    public ArrayList<String> getInputsList() {
        return inputsList;
    }

    public ArrayList<String> getOutputsList() {
        return outputsList;
    }

    public String getInputNameText() {
        return InputName.getText();
    }

    /**
     *
     * @return the last value inputed into the input text window. This will be
     * sent to project to be processed.
     */
    public String getTempInputCommand() {
        return TempInputCommand.remove(0);
    }

    public boolean TempInputCommandIsEmpty() {
        return TempInputCommand.isEmpty();
    }

    /**
     * Creates a new Rubric if new Rubric is selected in rubric_name_dropdown.
     * InputBox appears asking for the Rubric name. Updates an existing Rubric
     * if a Rubric is chosen in rubric_name_dropdown.
     *
     * @param event Button Click
     */
    @FXML
    private void saveRubric(ActionEvent event) {
        String rubricNameSelection = (String) rubric_name_dropdown.getSelectionModel().getSelectedItem();
        String rubricTypeSelection = (String) rubric_type_dropdown.getSelectionModel().getSelectedItem();

        //This for loop retrieves the text from each text field and assigns it
        //to a variable in order to create a criteria.
        getCriteriaData();

        if (rubricNameSelection != null && rubricTypeSelection != null) {
            //If new rubric
            if (rubricNameSelection.equalsIgnoreCase(newRubric)) {
                createRubric(rubricNameSelection, rubricTypeSelection);
            } else {
                //If rubric is updated
                updateRubric(rubricNameSelection, rubricTypeSelection);
            }

        }

    }

    /**
     * Creates a new HBox with TextFields and a Button. There is a standardized
     * naming method for these creations.
     *
     * @param event Button Click
     */
    @FXML
    private void createNewCriterion(ActionEvent event) {
        makeNewCriterion("", "", "", "", "");
    }

    /**
     * Adds new criterion to the GUI
     * @param criterionName
     * @param percentTotal
     * @param goodPercentage
     * @param moderatePercentage
     * @param badPercentage 
     */
    private void makeNewCriterion(String criterionName, String percentTotal, String goodPercentage, String moderatePercentage, String badPercentage) {
        HBox hb = new HBox();
        hb.setSpacing(spacing);
        hb.setId("h" + count);
        ArrayList<TextField> textFieldList = new ArrayList<>(numTextFields);
        for (int i = 0; i < numTextFields; i++) {
            TextField txt = new TextField();
            txt.setPrefWidth(textFieldWidth);
            textFieldList.add(txt);
            switch (i) {
                case 0:
                    textFieldList.get(i).setId("c" + count);
                    textFieldList.get(i).setText(criterionName);
                    break;

                case 1:
                    textFieldList.get(i).setId("p" + count);
                    textFieldList.get(i).setText(percentTotal);
                    break;

                case 2:
                    textFieldList.get(i).setId("g" + count);
                    textFieldList.get(i).setText(goodPercentage);
                    break;

                case 3:
                    textFieldList.get(i).setId("m" + count);
                    textFieldList.get(i).setText(moderatePercentage);
                    break;

                case 4:
                    textFieldList.get(i).setId("b" + count);
                    textFieldList.get(i).setText(badPercentage);
                    break;
            }
            hb.getChildren().add(textFieldList.get(i));
        }
        Button deleteCriterion = new Button();
        deleteCriterion.setId("d" + count);
        deleteCriterion.setText(criterionDeleteButtonName);
        deleteCriterion.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Button pressed = (Button) event.getSource();
                Integer findCount = Integer.parseInt(pressed.getId().substring(pressed.getId().length() - 1));
                HBox hbToBeDeleted = (HBox) vb.getChildren().get(findCount);
                vb.getChildren().remove(hbToBeDeleted);
                updateButtonId();
            }
        });
        hb.getChildren().add(deleteCriterion);
        count++;
        vb.getChildren().add(hb);
    }

    /**
     * Gets the data of each criteria from the GUI 
     */
    private void getCriteriaData() {
        String name = "";
        double percentTotal = 0;
        double goodPercent = 0;
        double moderatePercent = 0;
        double badPercent = 0;
        for (int i = 0; i < vb.getChildren().size(); i++) {
            HBox hBox = (HBox) vb.getChildren().get(i);
            for (int j = 0; j < hBox.getChildren().size() - 1; j++) {
                TextField tField = (TextField) hBox.getChildren().get(j);
                switch (j) {
                    case 0:
                        name = tField.getText();
                        break;
                    case 1:
                        percentTotal = Double.parseDouble(tField.getText());
                        break;
                    case 2:
                        goodPercent = Double.parseDouble(tField.getText());
                        break;
                    case 3:
                        moderatePercent = Double.parseDouble(tField.getText());
                        break;
                    case 4:
                        badPercent = Double.parseDouble(tField.getText());
                        break;
                    default:
                        System.out.println("sorry try again");
                }
            }
            System.out.println(name + ": " + percentTotal + ": " + goodPercent + ": " + moderatePercent + ": " + badPercent);
        }
    }

    private void createRubric(String rubricNameSelection, String rubricTypeSelection) {
        rubricNameSelection = JOptionPane.showInputDialog("Enter Rubric Name: ");
        while (validateRubricName(rubricNameSelection)) {
            rubricNameSelection = JOptionPane.showInputDialog("Enter Rubric Name: ");
        }

        addAllCriteria();
        if (criteriaArray != null) {
            rubricNameItems.add(rubricNameSelection);
            rubric_name_dropdown.setItems(rubricNameItems);
            rubricList.add(new Rubric(rubricNameSelection, rubricTypeSelection, criteriaArray));
            resetUserInput();
        }
    }

    private void updateRubric(String rubricNameSelection, String rubricTypeSelection) {
        addAllCriteria();
        if (criteriaArray != null) {
            for (int i = 0; i < rubricList.size(); i++) {
                if (rubricList.get(i).getRubricName().equalsIgnoreCase(rubricNameSelection)) {
                    rubric = rubricList.get(i);
                }
            }
            rubricList.remove(rubric);
            rubricList.add(new Rubric(rubricNameSelection, rubricTypeSelection, criteriaArray));
            resetUserInput();
        }
    }

    private boolean validateRubricName(String name) {
        for (int i = 0; i < rubricList.size(); i++) {
            if (name.equalsIgnoreCase(rubricList.get(i).getRubricName())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Deletes a the existing selected Rubric in rubric_name_dropdown.
     *
     * @param event Button Click
     */
    @FXML
    private void deleteRubric(ActionEvent event) {

        String rubricName = (String) rubric_name_dropdown.getSelectionModel().getSelectedItem();
        String rubricType = (String) rubric_type_dropdown.getSelectionModel().getSelectedItem();
        for (int i = 0; i < rubricList.size(); i++) {
            if (rubricList.get(i).getRubricName().equals(rubricName)) {
                rubric = rubricList.get(i);
            }
        }
        rubricNameItems.remove(rubric.getRubricName());
        rubricList.remove(rubric);
        resetUserInput();
    }

    private void updateButtonId() {
        count = 0;
        for (Node node1 : vb.getChildren()) {
            HBox hbox = (HBox) node1;
            for (Node node2 : hbox.getChildren().subList(hbox.getChildren().size() - 1, hbox.getChildren().size())) {
                Button b = (Button) node2;
                b.setId("d" + count);
                b.setText(criterionDeleteButtonName);
                count++;
            }
        }
    }

    private void addAllCriteria() {
        criteriaArray = new ArrayList<>();
        String name = "";
        double percentTotal = 0;
        double goodPercent = 0;
        double moderatePercent = 0;
        double badPercent = 0;
        double totalPercentSum = 0.0;
        double minimum = 0.0;
        double maximum = 100.0;
        for (int i = 0; i < vb.getChildren().size(); i++) {
            ArrayList<String> criteria = new ArrayList<>();
            HBox hBox = (HBox) vb.getChildren().get(i);
            for (int j = 0; j < hBox.getChildren().size() - 1; j++) {
                TextField tField = (TextField) hBox.getChildren().get(j);
                switch (j) {
                    case 0:
                        name = tField.getText();
                        int count = 0;
                        for (int k = 0; k < criteriaArray.size(); k++) {
                            if (name.equalsIgnoreCase(criteriaArray.get(k).get(j))) {
                                name = JOptionPane.showInputDialog(name + " already exists. Enter a different name:");
                                tField.setText(name);
                                count++;
                                j--;
                                break;
                            }
                        }
                        if (count == 0) {
                            criteria.add(name);
                        }
                        break;
                    case 1:
                        percentTotal = Double.parseDouble(tField.getText());
                        if (percentTotal >= minimum && percentTotal <= maximum) {
                            criteria.add("" + percentTotal);
                        } else {
                            percentTotal = Double.parseDouble(JOptionPane.showInputDialog(percentTotal + " must be greater than or equal to " + minimum
                                    + "and less than or equal to " + maximum + ". Enter a different percentage:"));
                            tField.setText(Double.toString(percentTotal));
                            j--;
                        }
                        break;
                    case 2:
                        goodPercent = Double.parseDouble(tField.getText());
                        if (goodPercent >= minimum && goodPercent <= maximum) {
                            criteria.add("" + goodPercent);
                        } else {
                            goodPercent = Double.parseDouble(JOptionPane.showInputDialog(goodPercent + " must be greater than or equal to " + minimum
                                    + "and less than or equal to " + maximum + ". Enter a different percentage:"));
                            tField.setText(Double.toString(goodPercent));
                            j--;
                        }
                        break;
                    case 3:
                        moderatePercent = Double.parseDouble(tField.getText());
                        if (moderatePercent >= minimum && moderatePercent <= maximum) {
                            criteria.add("" + moderatePercent);
                        } else {
                            moderatePercent = Double.parseDouble(JOptionPane.showInputDialog(moderatePercent + " must be greater than or equal to " + minimum
                                    + "and less than or equal to " + maximum + ". Enter a different percentage:"));
                            tField.setText(Double.toString(moderatePercent));
                            j--;
                        }
                        break;
                    case 4:
                        badPercent = Double.parseDouble(tField.getText());
                        if (badPercent >= minimum && badPercent <= maximum) {
                            criteria.add("" + badPercent);
                        } else {
                            badPercent = Double.parseDouble(JOptionPane.showInputDialog(badPercent + " must be greater than or equal to " + minimum
                                    + "and less than or equal to " + maximum + ". Enter a different percentage:"));
                            tField.setText(Double.toString(badPercent));
                            j--;
                        }
                        break;
                    default:
                        System.out.println("sorry try again");
                }
            }
            criteriaArray.add(criteria);
        }
        for (int j = 0; j < criteriaArray.size(); j++) {
            totalPercentSum += Double.parseDouble(criteriaArray.get(j).get(1));
        }
        if (totalPercentSum != maximum) {
            criteriaArray = null;
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Check Input");
            alert.setHeaderText(null);
            alert.setContentText("The total percent sum is: " + totalPercentSum + ". Fix then click save to save this rubric.");
            alert.showAndWait();
        }
    }

    private void clearVBox() {
        vb.getChildren().clear();
        updateButtonId();

    }

    private void updateVBox() {
        if (rubric != null) {
            clearVBox();
            for (int i = 0; i < rubric.getCriteriaList().size(); i++) {
                makeNewCriterion(rubric.getCriteriaList().get(i).get(0), rubric.getCriteriaList().get(i).get(1),
                        rubric.getCriteriaList().get(i).get(2), rubric.getCriteriaList().get(i).get(3),
                        rubric.getCriteriaList().get(i).get(4));
            }
        }
    }

    private void resetUserInput() {
        clearVBox();
        rubric = null;
        rubric_name_dropdown.setValue(null);
        rubric_type_dropdown.setValue(null);
        rubric_type_dropdown.setDisable(true);
        new_criterion_button.disableProperty().set(true);
        save_button.disableProperty().set(true);
        delete_button.disableProperty().set(true);
    }

}
