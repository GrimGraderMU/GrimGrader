/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grimmgrader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;

/**
 *
 * @author Frehiwot Gudeta
 */
public class ProjectInfo {
    
    
    
    
    
    public void getProjectInfo(String dir, String saveTo) throws IOException {

        File file = new File(dir);
        System.out.println("Getting all files in " + file.getCanonicalPath() + " including those in subdirectories");
        List<File> files = (List<File>) FileUtils.listFiles(file, TrueFileFilter.INSTANCE, TrueFileFilter.INSTANCE);
        ArrayList<String> list = new ArrayList<>();
        String str = "";
        for (File f : files) {
            if (f.getName().endsWith(".java")) {
                String s = this.txttoString(f.getAbsolutePath());
                str=this.extract(s);
                
                int start=0;
                for (int i = 0; i < str.length(); i++) {
                    if (((Character) str.charAt(i)).toString().compareTo("\n") == 0) {
                        list.add(str.substring(start, i));
                        start = i;
                    }

                }
              
            }
        } 
        System.out.println(list.toString());
        this.writeToFile(list, saveTo);
    }    
    
    public String txttoString(String fileName) throws IOException
    {
        String s = "";
        StringBuilder contentBuilder = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {

            String sCurrentLine;
            while ((sCurrentLine = br.readLine()) != null) {
                //contentBuilder.append(sCurrentLine).append("\n");
                if(sCurrentLine.contains("class"))
                {
                  contentBuilder.append(sCurrentLine).append("\n"+"*******************************************************************************************");  
                }
                else{
                   contentBuilder.append(sCurrentLine).append("\n"); 
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        s = contentBuilder.toString();
    
         return s;
     }
    
    public String extract(String s)
    {
        int count=0;
        boolean isSet=false;
        int start=0;
        int end=0;
        //List<String> b = new ArrayList<>();
        String a="";
        
        for (int i = 0; i < s.length(); i++) {
            
            if(s.charAt(i)=='{'){
                count++;
            }
            if(s.charAt(i)=='}'){
                a.concat("\n");
                count--;
            }
            if(!isSet && s.charAt(i)=='{' && count==2){
                isSet=true;
                end=i;
            }
            if(isSet && s.charAt(i)=='}' && count==1){
                isSet=false;
                a+=(s.substring(start, end)+"{}");
                start=i+1;
                
            }    
            
        }
        return a;
        
    }
    
    public void writeToFile(List<String> str, String saveTo)
    {
        try {
            File file = new File(saveTo);
            PrintWriter fileWriter = new PrintWriter(file);
            for (String string : str) {
                fileWriter.println(string);
            }
            
            fileWriter.flush();
            fileWriter.close();
        } catch (IOException e) {
                e.printStackTrace();
        }
    }
    
    
}
