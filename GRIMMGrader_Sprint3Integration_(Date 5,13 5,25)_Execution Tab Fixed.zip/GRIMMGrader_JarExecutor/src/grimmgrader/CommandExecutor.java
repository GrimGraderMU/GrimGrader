/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grimmgrader;

import CRUD.SubmissionCRUD;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.stage.Stage;
import javafx.application.Platform;

/**
 *
 * This class encapsulates an executor that will run any executable program. It
 * uses the Java Process class to create and execute a program as a process.
 * This allows the CommandExecutor to create streams to communicate to the
 * process. This class assumes that the process communicates using: System.in
 * System.out System.err
 *
 *
 * @author luddi
 */
public class CommandExecutor extends AsyncTask {

    private FXMLDocumentController FDC;
    private Process commandProcess;
    Stage primaryStage;
    String inputText = "";
    private boolean pipeOpen = true;
    private final List<String> OutputStrings = new ArrayList<>();// List used to store the outputs.
    private final List<String> InputStrings = new ArrayList<>();// List used to store the Inputs.
    private final List<String> ErrorStrings = new ArrayList<>();//List used to store the errors.
    private Thread T1;
    private String Section;
    private int Student;
    private String Assignment;
    private String Destin;
    private String zipFilePath = Destin + "\\JavaApplication1 - Copy (2).zip";
    private String outputFilePath = Destin + "\\New folder\\Output.txt";
    private String inputFilePath = Destin + "\\New folder\\Input.txt";
    private String errorFilePath = Destin + "\\New folder\\Error.txt";
    private String documentationFilePath = Destin + "\\New folder\\projectInfo.txt";
    private String magicFilePath = Destin + "\\New folder\\Magics.txt";

    /**
     *
     * /**
     * This method receives a list of strings that represent the process to run
     * and any configuration commands that must be passed into the process.
     *
     * @param commands
     * @throws IOException
     * @throws InterruptedException
     */
    public CommandExecutor(FXMLDocumentController FDC, String Section, int Student, String Assignment, String Destin) {
        this.FDC = FDC;
        this.Section = Section;
        this.Student = Student;
        this.Assignment = Assignment;
        this.Destin = Destin;
    }

    public void setPipeOpen(boolean pipeOpen) throws IOException {
        if (!pipeOpen) {
            commandProcess.destroy();
            T1.interrupt();
        }
        this.pipeOpen = pipeOpen;
    }

    private void execCommands(List<String> commands, String Section, int Student, String Assignment, String FolderPath) throws IOException, InterruptedException, SQLException {
        primaryStage = GRIMMGrader.stage;
        String strCommand = "";
        for (String c : commands) {
            strCommand += c;
        }

        // Create the process be run
        commandProcess = Runtime.getRuntime().exec(strCommand);

        // Create and start the threads that will manage the input/output of the process
        SyncErrorOutputPipe errorRunnable = new SyncErrorOutputPipe(commandProcess.getErrorStream(), System.err);
        SyncInputPipe inputRunnable = new SyncInputPipe(System.in, commandProcess.getOutputStream());
        SyncOutputPipe outputRunnable = new SyncOutputPipe(commandProcess.getInputStream(), System.out);

        T1 = new Thread(errorRunnable);
        Thread T2 = new Thread(outputRunnable);
        Thread T3 = new Thread(inputRunnable);

        T1.start();
        T2.start();
        T3.start();

        T1.join();
        T2.join();
        T3.join();

        // wait for the process to complete and then shutdown the Executor.
        commandProcess.waitFor();
        FDC.projectRunEndSequence();
        //saveDocumentation();
//        SubmissionCRUD submissionCRUD = new SubmissionCRUD();
//        submissionCRUD.Create(zipFilePath, Section, Assignment, Student);
//        submissionCRUD.Update(zipFilePath, Section, Assignment, Student, outputFilePath, inputFilePath, errorFilePath, documentationFilePath, magicFilePath);

        System.out.println("Shutting down \n*****************");

    }

    @Override
    public void onPreExecute() {
    }

    @Override
    public Object doInBackground(Object... params) {
        try {
            execCommands((List<String>) params[0], (String) params[1], (int) params[2], (String) params[3], (String) params[4]);
        } catch (IOException ex) {
            Logger.getLogger(CommandExecutor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InterruptedException ex) {
            Logger.getLogger(CommandExecutor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(CommandExecutor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public void onPostExecute(Object params) {
    }

    @Override
    public void progressCallback(Object... params) {
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
    }

    private void saveDocumentation() throws IOException {
        ProjectInfo p = new ProjectInfo();
        p.getProjectInfo(Destin, Destin + "\\Documentation.txt");

    }

    /**
     * This class receives error output from the process and pipes it to the
     * Executer defined error output.
     */
    private class SyncErrorOutputPipe implements Runnable {

        private final OutputStream outToError;
        private final InputStream inFromProcess;
        private final Scanner scan;
        private final PrintStream writer;
        private boolean done = false;

        private SyncErrorOutputPipe(InputStream errIn, OutputStream errOut) {
            inFromProcess = errIn;
            outToError = errOut;
            scan = new Scanner(inFromProcess);
            writer = new PrintStream(outToError);
        }

        @Override
        public void run() {
            while (pipeOpen) {     // This loop ends when the process shuts down its
                try {           // InputStream. The exception breaks out of the loop
                    String s = scan.nextLine();

                    ArrayList<String> st = FDC.getErrorsList();
                    st.add(0, s);
                    FDC.setErrorsList(st);
                    FDC.UpdateTextAreas();

                    writer.println(s);
                    ErrorStrings.add(s);
                } catch (Exception e) {
                    pipeOpen = false;
                    System.out.println(e);
                    break;
                }
            }
            FileWrite FW = new FileWrite("Error.txt");
            try {
                FW.printToFile(ErrorStrings);
            } catch (IOException ex) {
                Logger.getLogger(CommandExecutor.class.getName()).log(Level.SEVERE, null, ex);
            }

            System.out.println("Error pipe shutting down");
        }
    }

    /**
     * This class receives output from the process and "pipes" it to the
     * Executor defined output.
     */
    private class SyncOutputPipe implements Runnable {

        final OutputStream outToExecutor;
        private final InputStream inFromProcess;
        private final Scanner scan;
        private final PrintStream writer;

        private SyncOutputPipe(InputStream stdIn, OutputStream stdOut) {
            inFromProcess = stdIn;
            outToExecutor = stdOut;
            scan = new Scanner(inFromProcess);
            writer = new PrintStream(outToExecutor);
        }

        @Override
        public void run() {
            while (pipeOpen) {    // This loop ends when the process shuts down its
                try {        // InputStream. The exception breaks out of the loop
                    String s = scan.nextLine();

                    ArrayList<String> st = FDC.getOutputsList();
                    st.add(s);
                    FDC.setOutputsList(st);
                    FDC.UpdateTextAreas();
                    OutputStrings.add(s);

                    writer.println(s);

                } catch (Exception ex) {
                    pipeOpen = false;
                    System.out.println(ex);
                    break;
                }
            }
            FileWrite FW = new FileWrite("Output.txt");
            try {
                FW.printToFile(OutputStrings);
            } catch (IOException ex) {
                Logger.getLogger(CommandExecutor.class.getName()).log(Level.SEVERE, null, ex);
            }

            System.out.println("Ouput pipe shutting down");
        }
    }

    /**
     * This class receives input from the Executor defined input and pipes it to
     * the Process input.
     */
    private class SyncInputPipe implements Runnable {

        private final OutputStream outToProcess;
        private final InputStream inFromExecutor;
        private final Scanner scan;
        private final PrintStream writer;

        private SyncInputPipe(InputStream stdIn, OutputStream stdOut) {
            inFromExecutor = stdIn;
            outToProcess = stdOut;
            scan = new Scanner(inFromExecutor);
            writer = new PrintStream(outToProcess);
        }

        @Override
        public void run() {

            String s = "";

            while (pipeOpen) { // This loop ends when the Process defined termination occurs
                // Or if the InputStream backing the scanner closes

                try {
//                   
                    while (s.equals("")) {
                        Thread.sleep(500);
                        if (!FDC.TempInputCommandIsEmpty()) {
                            s = FDC.getTempInputCommand();
                        }
                        if (!pipeOpen) {
                            break;
                        }
                        if (!s.equals("")) {
                            ArrayList<String> st = FDC.getInputsList();
                            st.add(s);
                            FDC.setInputsList(st);
                            FDC.UpdateTextAreas();
                        }

                    }

                    writer.println(s);
                    writer.flush();
                    InputStrings.add(s);
                    inputText = "";
                    s = "";

                } catch (Exception ex) {
                    pipeOpen = false;
                    System.out.println(ex);
                    break;
                }

            }

            System.out.println("Input to process shutting down");
        }

    }

}
