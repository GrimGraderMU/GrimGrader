/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oddnumbers;

/**
 *
 * @author eaibrahim2019
 */
public class CheckOdd {
    int numbers;
    int i;
    int max = 100;
    public  CheckOdd(){
    }
    
 public Integer CheckOdd(int i,int j){
     do
         for (int j= max){
     for(i=numbers;i,=j;i%2!=0;i++){
         return i;
         }
 
 


 
    
       
             
 
 
