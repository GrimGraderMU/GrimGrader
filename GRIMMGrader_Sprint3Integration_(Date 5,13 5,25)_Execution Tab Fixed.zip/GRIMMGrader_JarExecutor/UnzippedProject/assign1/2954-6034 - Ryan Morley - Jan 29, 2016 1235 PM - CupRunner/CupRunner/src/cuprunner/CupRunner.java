/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cuprunner;

/**
 *
 * @author rwmorley2019
 */
public class CupRunner {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Cup coffeeCup = new Cup();
        int test = 1;
        coffeeCup.fill();
        if(coffeeCup.isFull())
        {
            System.out.println("The cup is full.");
        }
        while(!(coffeeCup.isEmpty()))
        {
            coffeeCup.sip();
            
            System.out.println(test + " sip(s)");
            test++;
        }
        if ( coffeeCup.isEmpty() )
        {
            System.out.println("Cup is empty");
        }
        else
        {
            System.out.println("Cup is not empty");
        }
        
    }
    
}
