/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oddnumbers;

/**
 *
 * @author fkgudeta2019
 */
public class Oddnumbers {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Integer i = 0;
        while( i < 100)
        {
            if(i % 2 != 0)
            {
                i++;
            }
            else
            {
                i++;
                System.out.println(i);
            }
        }
        
        for( Integer i = 0; i < 100; i++)
        {
            if(i % 2 != 0)
            {
                i++;
            }
            else
            {
                i++;
                System.out.println(i);
            }
        }
    }
    
}
