/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drinkcoffee;

/**
 *
 * @author Nebiyou
 */
public class Cup {
   int amount=0;
    
    
    //This method makes the cup full
public void fill(){
    amount = 100;
}
//This method makes the cup empty
public void empty(){
    amount = 0;
}
//This method returns true when the cup is full
public boolean isFull(){
    return amount==100;
}
//This method returns true when the cup is empty
public boolean isEmpty(){
    return amount == 0;
}
//This method reduces the volume of the cup by 10% (1/10th) of the total amount
//So, how many sips from full to empty?
public void sip(){
    amount= amount - 10;
}
 public Integer getAmount(){
     return amount;
 }
}
