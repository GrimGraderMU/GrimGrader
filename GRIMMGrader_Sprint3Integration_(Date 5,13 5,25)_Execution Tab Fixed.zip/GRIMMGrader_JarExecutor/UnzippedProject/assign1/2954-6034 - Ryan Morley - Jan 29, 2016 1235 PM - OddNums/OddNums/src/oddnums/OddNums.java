/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oddnums;

/**
 *
 * @author rwmorley2019
 */
public class OddNums {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int oddTest = 0;
        
        while(oddTest < 99)
        {
            if(oddTest%2 == 0)
            {
                oddTest--;
            }
            oddTest += 2;
            System.out.println(oddTest);

        }
        
        for(int i = 0; i < 100; i++)
        {
            if(i%2 == 1)
            {
                System.out.println(i);
            }
            
        }
        
        
        
        
    }
    
}
