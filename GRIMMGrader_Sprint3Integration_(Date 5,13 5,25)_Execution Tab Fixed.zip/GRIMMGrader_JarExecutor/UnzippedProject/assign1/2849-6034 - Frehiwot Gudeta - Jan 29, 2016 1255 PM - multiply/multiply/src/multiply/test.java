/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiply;

/**
 *
 * @author fkgudeta2019
 */
public class test {
    
     
    public test()
    {
        
    }
    public Integer multiply(Integer multiplier, Integer multiplican)
     {
         Integer product = 0;
         while (multiplier > 0)
         {
             product = product + multiplican;
             multiplier--;
         }
         return product;
     }
    
}
