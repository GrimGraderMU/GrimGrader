/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multipliermethod;

/**
 *
 * @author rwmorley2019
 */
public class MultiplierMethod {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int squareNum = 1;
        
        while(squareNum <= 10)
        {
            int newSum = multiply(squareNum, squareNum);
            System.out.println(squareNum + " * " + squareNum + " = " + newSum);
            squareNum++;
        }
        
        
    }
    
    private static int multiply (int multiplier, int multiplicand)
    {
        int sum = 0;
        int test = 0;
        while(test < multiplier)
        {
            sum += multiplicand;
            test++;
        }
        
        return sum;
    }
    
}
