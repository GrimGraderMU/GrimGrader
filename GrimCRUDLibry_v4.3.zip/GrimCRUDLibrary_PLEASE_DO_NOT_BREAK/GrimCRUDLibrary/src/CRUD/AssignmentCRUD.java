/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CRUD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ryan
 */
public class AssignmentCRUD {
    private final String slash = "\\";//----Used for FilePaths
    /**
     * the next three are for filepaths
     */
       private final String d = "jdbc:postgresql://10.76.17.197/GrimGraderDataBase";
       private final String u = "grimGrader";
       private final String p = "Here Dies Grades";
       /*
       The following four are SQL Statements that are sent to the Database
       the questionmarks are indicies that the methods use to fill in the blanks, they 
       start from 1, and increment by one
       */
       private final String insertSQL = "INSERT INTO public.assignment VALUES (?)";
       private final String dropSQL = "Delete FROM public.assignment WHERE " +
               "assignmentname = ?";
       private final String getSQLpt2 = "from public.assignment";
       private Connection con;//the connection to the database
       public AssignmentCRUD() throws SQLException{
                   con = DriverManager.getConnection(d, u, p);
       }
    
       /**
        * Creates the initial entry into the table. 
        * returns true if successful
        * @param AssignmentName
        * @return 
        */
    public Boolean Create(String AssignmentName){

        try {
            PreparedStatement ps = con.prepareStatement(insertSQL);
            ps.setString(1, AssignmentName);
            ps.executeUpdate();
            ps.close();
            return true;
        } catch (SQLException ex) {
           
               Logger.getLogger(AssignmentCRUD.class.getName()).log(Level.SEVERE, null, ex);
                return false;
        }
    }

    /**
     * retrieves all assignment names
     * * returns ArrayList of assignment names if successful; null if unsuccessful
     * @return 
     */
    public ArrayList<String> retrieveAssignmentNames(){
        ArrayList<String> r = new ArrayList<>();
        String q = "Select * " + getSQLpt2;
        PreparedStatement ps;
        try {
            ps = con.prepareStatement(q);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                r.add(rs.getString("assignmentname"));
            }
            return  r;
        } catch (SQLException ex) {
            
            Logger.getLogger(AssignmentCRUD.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }

    
    }

    /**
     * deletes an entry from the table
     * * returns true if successful
     * @param AssignmentName
     * @return 
     */
    public Boolean DeleteEntry(String AssignmentName){
        try {
            PreparedStatement ps = con.prepareStatement(dropSQL);
            int name = 1;
            ps.setString(name, AssignmentName);
            ps.execute();
            ps.close();
            return true;
        } catch (SQLException ex) {
            
            Logger.getLogger(AssignmentCRUD.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
}
