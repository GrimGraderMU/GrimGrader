/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CRUD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ryan
 */
public class StudentCRUD {
    
    private final String slash = "\\";//----Used for FilePaths
    /**
     * the next three are for filepaths
     */
       private final String d = "jdbc:postgresql://10.76.17.197/GrimGraderDataBase";
       private final String u = "grimGrader";
       private final String p = "Here Dies Grades";
       /*
       The following four are SQL Statements that are sent to the Database
       the questionmarks are indicies that the methods use to fill in the blanks, they 
       start from 1, and increment by one
       */
       private final String insertSQL = "INSERT INTO public.student VALUES (?,?)";
       private final String updateSQL = "UPDATE public.student " + 
                "set " + 
                "studentname = ? " + 
                "where " + 
                "studentid = ?";
       private final String dropSQL = "Delete FROM public.student WHERE " +
               "studentid = ?";
       private final String getSQLpt2 = "from public.student " +
               "where " + 
               "studentid = ?";
       private Connection con;//the connection to the database
       public StudentCRUD() throws SQLException{
                   con = DriverManager.getConnection(d, u, p);
       }
    
       /**
        * Creates the initial entry into the table. 
        * returns true if successful
        * @param StudentID
        * @param StudentName
        * @return 
        */
    public Boolean Create(Integer StudentID, String StudentName){

        try {
            PreparedStatement ps = con.prepareStatement(insertSQL);
            ps.setInt(1, StudentID);
            ps.setString(2, StudentName);
            ps.executeUpdate();
            ps.close();
            return true;
        } catch (SQLException ex) {
           
               //Logger.getLogger(StudentCRUD.class.getName()).log(Level.SEVERE, null, ex);
                return false;
        }
    }
    
    /**
     * Fills in entries that are not nulled
     * * returns true if successful
     * @param StudentID
     * @param StudentName
     * @return 
     */
    public Boolean Update(Integer StudentID, String StudentName){
            int name = 1;
            int id = 2;
        try {
            PreparedStatement ps = con.prepareStatement(updateSQL);  
            ps.setString(name, StudentName);
            ps.setInt(id, StudentID);
            ps.executeUpdate();
            ps.close();
            return true;
        }catch (SQLException ex) {
            return false;
               //Logger.getLogger(StudentCRUD.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }

    /**
     * retrieves a student name from a specific entry if found
     * * returns student name if successful; null if unsuccessful
     * @param StudentID
     * @return 
     */
    public String retrieveStudentName(Integer StudentID){
        String q = "Select studentname " + getSQLpt2;
        PreparedStatement ps;
        try {
            ps = con.prepareStatement(q);
            int id = 1;
            ps.setInt(id, StudentID);
            ResultSet rs = ps.executeQuery();
            rs.next();
            return rs.getString("studentname");
        } catch (SQLException ex) {
            
            Logger.getLogger(StudentCRUD.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }

    
    }

    /**
     * deletes an entry from the table
     * * returns true if successful
     * @param StudentID
     * @param StudentName
     * @return 
     */
    public Boolean DeleteEntry(Integer StudentID){
        try {
            PreparedStatement ps = con.prepareStatement(dropSQL);
            int id = 1;
            ps.setInt(id, StudentID);
            ps.execute();
            ps.close();
            return true;
        } catch (SQLException ex) {
            return false;
            //Logger.getLogger(StudentCRUD.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
}
