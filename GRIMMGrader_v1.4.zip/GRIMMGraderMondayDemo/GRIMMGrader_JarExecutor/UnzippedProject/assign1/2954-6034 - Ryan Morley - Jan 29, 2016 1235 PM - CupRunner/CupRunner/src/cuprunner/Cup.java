/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cuprunner;

/**
 *
 * @author rwmorley2019
 */
public class Cup {
    
    int max = 10;
    int amount;
    Boolean tOrF;
    
    public void fill()
    {
        amount = max;
    }
    
    public void empty()
    {
        amount = 0;
    }
    
    public Boolean isFull()
    {
        if(amount == max)
        {
            tOrF = true;
        }
        else
        {
            tOrF = false;
        }
        return tOrF;
    }
    
    public Boolean isEmpty()
    {
        if(amount == 0)
        {
            tOrF = true;
        }
        else
        {
            tOrF = false;
        }
        
        return tOrF;
    }
    
    public void sip()
    {
        amount--; //10 sips until empty.
    }
    
}
