/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drinkcoffee;

/**
 *
 * @author Nebiyou
 */
public class DrinkCoffee {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Cup coffeeCup =new Cup();
        coffeeCup.fill();
        System.out.println("The cup is full");
        while (coffeeCup.getAmount()>0){
            coffeeCup.sip();
        }
        if ( coffeeCup.isEmpty() )
        {
            
         System.out.println("Cup is empty");
        }
        else
        {
        System.out.println("Cup is not empty");
        }
    }
    
}
