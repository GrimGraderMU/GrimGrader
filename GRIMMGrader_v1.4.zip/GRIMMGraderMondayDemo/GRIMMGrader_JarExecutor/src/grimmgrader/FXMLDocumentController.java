/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grimmgrader;

import CRUD.AssignmentCRUD;
import CRUD.RubricCRUD;
import CRUD.RubricCriteriaCRUD;
import CRUD.RubricGradeCRUD;
import CRUD.SectionAssignmentCRUD;
import CRUD.SectionCRUD;
import CRUD.SectionStudentCRUD;
import CRUD.StudentCRUD;
import CRUD.SubmissionCRUD;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.function.UnaryOperator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextFormatter;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.util.Duration;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileSystemView;

/**
 *
 * @author Frehiwot Gudeta
 */
public class FXMLDocumentController implements Initializable {

    private ArrayList<String> errorsList = new ArrayList<>();
    private ArrayList<String> inputsList = new ArrayList<>();
    private ArrayList<String> outputsList = new ArrayList<>();
    private List<String> TempInputCommand = new ArrayList<>();
    private boolean StartedGrading = false;
    private String ProjectJarLocation = "";
    private ArrayList<String> ProjectLocations = new ArrayList<>();
    private CommandExecutor cmdExec = null;
    private final Integer numTextFields = 5;
    private Integer count = 0;
    private final String newRubric = "New Rubric";
    private ArrayList<ArrayList<String>> criteriaArray;
    private Rubric rubric;
    private ArrayList<Rubric> rubricList = new ArrayList<>();
    private ObservableList<String> rubricTypeItems = FXCollections.observableArrayList("Global", "Course", "Assignment");
    private String criterionDeleteButtonName = "delete";
    private Double spacing = 5.0;
    private Double textFieldWidth = 120.0;
    private ObservableList<String> studentItems = FXCollections.observableArrayList("John", "Stewart", "Greg");//FXCollections.observableArrayList();
    private ObservableList<String> studentItemsExecution = FXCollections.observableArrayList("John", "Stewart", "Greg");//FXCollections.observableArrayList();
    private ObservableList<String> assignmentItems = FXCollections.observableArrayList("Global");//FXCollections.observableArrayList();
    private ObservableList<String> sectionItems = FXCollections.observableArrayList("Global");//FXCollections.observableArrayList();
    private final Double vBoxSpacing = 5.0;
    private final Double hBoxSpacing = 60.0;
    private final Double textFieldWidthGradingTab = 80.0;
    private ArrayList<Double> grades;
    private Double[] studentsInSection;
    private Double[] percentChosenList;
    private Double[] percentTotalList;
    private List<Double> criteriaList = new ArrayList<>(1);
    private ObservableList<String> courseNames = FXCollections.observableArrayList("New Course");
    private ArrayList<Student> students = new ArrayList<>();
    private int hBoxCount = 0;
    private ArrayList<CheckBox> checkBoxes = new ArrayList<>();
    private int markAllCount = 0;
    private ObservableList<String> termNames = FXCollections.observableArrayList("FALL", "JANUARY", "SPRING");
    private FileOutputStream fileOutputStream;
    private String fontType = "Cambria";
    private int fontSize = 20;
    private String errorMessageTitle = "Error";
    private String errorMessageHeader = "An error has occured while saving the course...";
    private String subjectErrorText = "Subject contains symbolic or numerical input, please enter only letters";
    private String numberErrorText = "Number contains non-numerical input, please enter only numbers";
    private String sectionErrorText = "Section contains symbolic or numerical input, please enter only a letter";
    private String termErrorText = "No term selected, please select a term";
    private String yearErrorText = "Year contains non-numerical input, please enter only numbers";
    private String fileNotFound = "There was no file found for this student";
    private String projectInfoFile = "";
    private String projectLocation = "";
    private String MagicFile = "";
    private ProjectInfo pInfo = new ProjectInfo();
    private MagicTest findmagic = new MagicTest();
    private List<String> MagicList = new ArrayList<>();
    String destinationFilePath = "UnzippedProject";

    UnaryOperator<TextFormatter.Change> filter = new UnaryOperator<TextFormatter.Change>() {
        @Override
        public TextFormatter.Change apply(TextFormatter.Change t) {
            if (t.isReplaced()) {
                if (t.getText().matches("[^0-9]")) {
                    t.setText(t.getControlText().substring(t.getRangeStart(), t.getRangeEnd()));
                }
            }

            if (t.isAdded()) {
                if (t.getControlText().contains(".")) {
                    if (t.getText().matches("[^0-9]")) {
                        t.setText("");
                    }
                } else if (t.getText().matches("[^0-9.]")) {
                    t.setText("");
                }
            }

            return t;
        }
    };

    @FXML
    private Button saveButton;
    @FXML
    private Button deleteButton;
    @FXML
    private Button deleteSelectedButton;
    @FXML
    private Button markAllButton;
    @FXML
    private Button addStudentButton;
    @FXML
    private Button assignStudentsButton;
    @FXML
    private TextField editNameBox;
    @FXML
    private TextField newStudentBox;
    @FXML
    private TextField newStudentIdBox;
    @FXML
    private TextField subjectBox;
    @FXML
    private TextField numberBox;
    @FXML
    private TextField sectionBox;
    @FXML
    private TextField yearBox;
    @FXML
    private VBox studentVBox;
    @FXML
    private Label studentName;
    @FXML
    private ChoiceBox courseDropDown;
    @FXML
    private ChoiceBox termDropDown;
    @FXML
    private ChoiceBox ExecutionSectionDropDown;
    @FXML
    private ChoiceBox ExecutionAssignmentDropDown;
    @FXML
    private ChoiceBox ExecutionStudentDropdown;
    @FXML
    private Button ChooseZipButton;
    @FXML
    private AnchorPane root;
    @FXML
    private Label percentOfTotal;
    @FXML
    private Label goodPercentage;
    @FXML
    private Label moderatePercentage;
    @FXML
    private Label badPercentage;
    @FXML
    private Button save_button;
    @FXML
    private Button delete_button;
    @FXML
    private Button new_criterion_button;
    @FXML
    private ChoiceBox rubric_name_dropdown;
    @FXML
    private ChoiceBox rubric_type_dropdown;
    @FXML
    private VBox vb;
    @FXML
    private TextArea inputTextArea;
    @FXML
    private Button SaveInputButton;
    @FXML
    private ComboBox SaveInputTextChoiceBox;
    @FXML
    private TextArea outputWindow;
    @FXML
    private TextArea errorWindow;
    @FXML
    private TextField rubricWindow;
    @FXML
    private TextArea inputWindow;
    @FXML
    private Button startGrading;
    @FXML
    private Button enterInputs;
    @FXML
    private TextField InputName;
    @FXML
    private Label RemainingProjectsLabel;
    @FXML
    private ChoiceBox section_choice_box;

    @FXML
    private ChoiceBox assignment_choice_box;

    @FXML
    private ChoiceBox student_choice_box;

    @FXML
    private ChoiceBox rubric_choice_box;

    @FXML
    private Button prevStudent_button;

    @FXML
    private Button nextStudent_button;

    @FXML
    private Button assign_grade_button;

    @FXML
    private TextArea output_text_area;

    @FXML
    private TextArea errors_text_area;

    @FXML
    private TextArea amd_text_area;

    @FXML
    private TextArea magic_text_area;

    @FXML
    private VBox criteria_vbox;

    @FXML
    private Label totalGradeLabel;

    @FXML
    private Button assingmentAccessButton;

    @FXML
    private Button assingmentSaveButton;

    @FXML
    private Button assingmentDoneButton;

    @FXML
    private Button assingmentDeleteButton;

    @FXML
    private ChoiceBox sectionDrop;

    @FXML
    private TextField assingmentTextField;

    @FXML
    private Pane assingmentPane;
    @FXML
    private Button GetStudentFromSubmission;

    private Scene welcomeScreenScene;
    private Scene parentScene;
    private StackPane welcomeScreenPane;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            initalizeDropDowns();
            initializeCourseTab();
            FadeInTransition(300);
            initializeAssingment();
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }



    public void FadeInTransition(double Millis) {
        FadeTransition fadein = new FadeTransition();
        fadein.setDuration(Duration.millis(Millis));
        fadein.setNode(root);
        fadein.setFromValue(0);
        fadein.setToValue(1);
        fadein.play();
    }

    private void initalizeDropDowns() throws SQLException {

        SaveInputTextChoiceBox.getItems().addAll(SavedInputsController.getInputs());
        SaveInputTextChoiceBox.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                TempInputCommand.addAll(SavedInputsController.getInputTextInfo().get(newValue.intValue()).getInputText());
                System.out.println(TempInputCommand.toString());
            }
        });

        vb.setSpacing(spacing);

        RubricCRUD rubricCRUD = new RubricCRUD();
        List<String> rubricsList = new ArrayList<>();
        rubricsList.add(newRubric);
        rubricsList.addAll(rubricCRUD.getAllRubricNames());
        rubric_name_dropdown.getItems().addAll(rubricsList);
        rubric_name_dropdown.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                if (newValue != null) {
                    delete_button.disableProperty().set(false);
                    rubric_type_dropdown.setDisable(false);
                    updateVBox();
                }
            }
        });

        rubric_type_dropdown.setItems(rubricTypeItems);
        resetUserInput();
        rubric_type_dropdown.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                new_criterion_button.disableProperty().set(false);
                save_button.disableProperty().set(false);
            }
        });
        criteria_vbox.setSpacing(vBoxSpacing);
        assignment_choice_box.setDisable(true);
        student_choice_box.setDisable(true);
        assign_grade_button.setDisable(true);
                                    //        output_text_area.setDisable(true);
                                    //        errors_text_area.setDisable(true);
                                    //        amd_text_area.setDisable(true);
                                    //        magic_text_area.setDisable(true);
                                    //        output_text_area.setEditable(false);
                                    //        errors_text_area.setEditable(false);
                                    //        amd_text_area.setEditable(false);
                                    //        magic_text_area.setEditable(false);
        //Get sectionItems from DB ObservableArrayList
        //Enable section_choice_box
        section_choice_box.setDisable(false);
        //Populate section_choice_box with sections

        //Get rubricItems from DB 
        //Enable rubric_choice_box
        rubric_choice_box.setDisable(false);

        SectionCRUD sectionCRUD = new SectionCRUD();
        SectionAssignmentCRUD sectionAssignmentCRUD = new SectionAssignmentCRUD();
        SectionStudentCRUD sectionStudentCRUD = new SectionStudentCRUD();
        StudentCRUD studentCRUD = new StudentCRUD();
        rubric_choice_box.getItems().addAll(rubricCRUD.getAllRubricNames());
        section_choice_box.getItems().addAll(sectionCRUD.retrieveSectionName());
        section_choice_box.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                //Enable assignment_choice_box
                assignment_choice_box.setDisable(false);
                //Get assignmentItems from DB using course selected
                //Populate with assignments
                assignment_choice_box.getItems().clear();
                assignment_choice_box.getItems().addAll(sectionAssignmentCRUD.retrieveAssignmentsInSection(newValue));
                ArrayList<Integer> studentIds = sectionStudentCRUD.retrieveStudentsInSection(newValue);
                ObservableList<String> students = FXCollections.observableArrayList();
                for (Integer i : studentIds) {
                    students.add(studentCRUD.retrieveStudentName(i) + "---" + i);
                }
                student_choice_box.setItems(students);
            }
        });
        assignment_choice_box.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                //Enable student_choice_box
                student_choice_box.setDisable(false);
            }

        });

        student_choice_box.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                //Enable text areas and buttons
                output_text_area.setDisable(false);
                errors_text_area.setDisable(false);
                amd_text_area.setDisable(false);
                magic_text_area.setDisable(false);

                //Display output, errors, magic, attributes, methods, and documentation
                try {
                    //Display output, errors, magic, attributes, methods, and documentation

                    String[] f = newValue.split("---");
                    String section = (String) section_choice_box.getSelectionModel().getSelectedItem();
                    String assignment = (String) assignment_choice_box.getSelectionModel().getSelectedItem();
                    Integer studentId = Integer.parseInt(f[f.length - 1]);
                    String HomeDir = FileSystemView.getFileSystemView().getDefaultDirectory().getPath() + "\\GrimGrader";
                    String DestinPath = HomeDir ;
                    String docs = HomeDir+"\\"+section+"\\"+assignment+"\\"+studentId;
                    ProjectInfo projectInfo = new ProjectInfo();
                    SubmissionCRUD submissionCRUD = new SubmissionCRUD();
                    File file = new File(docs);
                    if (!submissionCRUD.retrieveOutputFile(section, assignment, studentId, DestinPath)) {

                        output_text_area.setText(fileNotFound);
                    } else {
                        
                        output_text_area.setText(projectInfo.txttoString(file.getPath() + "\\"+studentId+"Output.txt"));
                    }
                    if (!submissionCRUD.retrieveErrorFile(section, assignment, studentId, DestinPath)) {
                        errors_text_area.setText(fileNotFound);
                    } else {
                         errors_text_area.setText(projectInfo.txttoString(file.getPath() + "\\"+studentId+"Error.txt"));
                         System.out.println("kill me please");
                    }
                    if (!submissionCRUD.retrieveDocumentationFile(section, assignment, studentId, DestinPath)) {
                        amd_text_area.setText(fileNotFound);
                    } else {
                         amd_text_area.setText(projectInfo.txttoString(file.getPath() + "\\"+studentId+"Documentation.txt"));
                    }
                    if (!submissionCRUD.retrieveMagicNumbersFile(section, assignment, studentId, DestinPath)) {
                        magic_text_area.setText(fileNotFound);
                    } else {
                         magic_text_area.setText(projectInfo.txttoString(file.getPath() + "\\"+studentId+"MagicNumbers.txt"));
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                }

            }

        });
        ExecutionSectionDropDown.getItems().addAll(sectionCRUD.retrieveSectionName());
        ExecutionSectionDropDown.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                //Enable assignment_choice_box
                ExecutionAssignmentDropDown.setDisable(false);
                //Get assignmentItems from DB using course selected
                //Populate with assignments
                ExecutionAssignmentDropDown.getItems().clear();
                ExecutionAssignmentDropDown.getItems().addAll(sectionAssignmentCRUD.retrieveAssignmentsInSection(newValue));
                ArrayList<Integer> studentIds = sectionStudentCRUD.retrieveStudentsInSection(newValue);
                ObservableList<String> students = FXCollections.observableArrayList();
                for (Integer i : studentIds) {
                    students.add(studentCRUD.retrieveStudentName(i) + "---" + i);
                }
                ExecutionStudentDropdown.setItems(students);
            }
        });
        ExecutionAssignmentDropDown.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                //Enable student_choice_box
                ExecutionStudentDropdown.setDisable(false);
            }

        });
        ExecutionStudentDropdown.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                //Enable assignment_choice_box
                ExecutionAssignmentDropDown.setDisable(false);
                ChooseZipButton.setDisable(false);
                startGrading.setDisable(false);
            }
        });

        rubric_choice_box.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {

                double minGrade = 0.0;
                double maxGrade = 100.0;
                criteria_vbox.getChildren().clear();
                try {
                    //Display all criteria
                    //Get Criteria from DB
                    RubricCriteriaCRUD cr = new RubricCriteriaCRUD();
                    ObservableList<String> criteria = FXCollections.observableArrayList(cr.getCriteria(newValue));
                    percentTotalList = new Double[criteria.size()];
                    percentChosenList = new Double[criteria.size()];
                    int criteriaCounter = 0;
                    for (String s : criteria) {

                        ArrayList<Double> criteriaItems = cr.retrieveCriteriaList(newValue, s);

                        HBox hb = new HBox();
                        hb.setId("" + criteriaCounter);

                        Label criteriaName = new Label();
                        Label percentTotal = new Label();

                        RadioButton goodGradeRadio = new RadioButton();
                        RadioButton moderateGradeRadio = new RadioButton();
                        RadioButton badGradeRadio = new RadioButton();

                        TextField customGrade = new TextField();
                        customGrade.setText("");
                        customGrade.setTextFormatter(new TextFormatter<>(filter));
                        customGrade.setMaxWidth(textFieldWidth);

                        //Get values from list of criteria and apply
                        criteriaName.setText(s);
                        percentTotal.setText("" + criteriaItems.get(0));
                        percentTotalList[criteriaCounter] = criteriaItems.get(0);

                        ToggleGroup group = new ToggleGroup();
                        goodGradeRadio.setText("" + criteriaItems.get(1));
                        goodGradeRadio.setToggleGroup(group);
                        moderateGradeRadio.setText("" + criteriaItems.get(2));
                        moderateGradeRadio.setToggleGroup(group);
                        badGradeRadio.setText("" + criteriaItems.get(3));
                        badGradeRadio.setToggleGroup(group);

                        customGrade.setOnMouseClicked(new EventHandler<MouseEvent>() {

                            @Override
                            public void handle(MouseEvent event) {
                                group.selectToggle(null);
                            }
                        });

                        customGrade.textProperty().addListener(new ChangeListener<String>() {

                            @Override
                            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                                if (!newValue.isEmpty() && !newValue.equals(".")) {
                                    double grade = Double.parseDouble(customGrade.getText());
                                    if (grade >= minGrade && grade <= maxGrade) {
                                        percentChosenList[Integer.parseInt(customGrade.getParent().getId())] = grade;
                                    }
                                }
                            }
                        });

                        group.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
                            @Override
                            public void changed(ObservableValue<? extends Toggle> observable, Toggle oldValue, Toggle newValue) {

                                if (!customGrade.getText().equals("")) {
                                    customGrade.setText("");
                                }
                            }
                        });

                        goodGradeRadio.selectedProperty().addListener(new ChangeListener<Boolean>() {
                            @Override
                            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {

                                if (newValue) {
                                    percentChosenList[Integer.parseInt(goodGradeRadio.getParent().getId())] = Double.parseDouble(goodGradeRadio.getText());
                                }
                            }
                        });

                        moderateGradeRadio.selectedProperty().addListener(new ChangeListener<Boolean>() {

                            @Override
                            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
                                if (newValue) {
                                    percentChosenList[Integer.parseInt(moderateGradeRadio.getParent().getId())] = Double.parseDouble(moderateGradeRadio.getText());
                                }
                            }

                        });

                        badGradeRadio.selectedProperty().addListener(new ChangeListener<Boolean>() {

                            @Override
                            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
                                if (newValue) {
                                    percentChosenList[Integer.parseInt(goodGradeRadio.getParent().getId())] = Double.parseDouble(badGradeRadio.getText());
                                }
                            }
                        });

                        Region r = new Region();
                        HBox.setHgrow(r, Priority.ALWAYS);

                        hb.getChildren().addAll(criteriaName, r, percentTotal, goodGradeRadio,
                                moderateGradeRadio, badGradeRadio, customGrade);
                        hb.setSpacing(hBoxSpacing);

                        criteria_vbox.getChildren().add(hb);
                        //Enable Assign Grade
                        assign_grade_button.setDisable(false);
                        criteriaCounter++;

                    }
                } catch (SQLException ex) {
                    Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    @FXML
    private void goToPreviousStudent(ActionEvent event) {
        int studentIndex = student_choice_box.getSelectionModel().getSelectedIndex();
        if (studentIndex > 0) {
            student_choice_box.getSelectionModel().select(--studentIndex);
        }
    }

    @FXML
    private void goToNextStudent(ActionEvent event) {
        int studentIndex = student_choice_box.getSelectionModel().getSelectedIndex();
        if (studentIndex < studentItems.size() - 1) {
            student_choice_box.getSelectionModel().select(++studentIndex);
        }
    }

    @FXML
    private void goToNextStudentExecution(ActionEvent event) {

        int studentIndex = ExecutionStudentDropdown.getSelectionModel().getSelectedIndex();

        if (studentIndex < ExecutionStudentDropdown.getItems().size() - 1) {
            ExecutionStudentDropdown.getSelectionModel().select(++studentIndex);
        }
    }

    @FXML
    private void goToPreviousStudentExecution(ActionEvent event) {

        int studentIndex = ExecutionStudentDropdown.getSelectionModel().getSelectedIndex();

        if (studentIndex > 0) {
            ExecutionStudentDropdown.getSelectionModel().select(--studentIndex);
        }
    }

    @FXML
    private void assignGrade(ActionEvent event) {
        double divisor = 100.0;
        double sum = 0.0;
        try {
            RubricCriteriaCRUD cr = new RubricCriteriaCRUD();
            RubricGradeCRUD cr2 = new RubricGradeCRUD();
            ObservableList<String> criteria = FXCollections.observableArrayList(cr.getCriteria(rubric_choice_box.getSelectionModel().getSelectedItem().toString()));
            int count = 0;
            for (String s : criteria) {
                ArrayList<Double> criteriaItems = cr.retrieveCriteriaList((String) rubric_choice_box.getSelectionModel().getSelectedItem(), s);
                double total = criteriaItems.get(0);
                double grade = total * percentChosenList[count];
                sum += grade;
                count++;
                grade = grade / divisor;
                String studentName = student_choice_box.getSelectionModel().getSelectedItem().toString();
                String[] f = studentName.split("---");
                Integer studentId = Integer.parseInt(f[f.length - 1]);
                cr2.Create(assignment_choice_box.getSelectionModel().getSelectedItem().toString(),
                        section_choice_box.getSelectionModel().getSelectedItem().toString(),
                        studentId, rubric_choice_box.getSelectionModel().getSelectedItem().toString(),
                        s, grade);
            }
            sum = sum / divisor;
            totalGradeLabel.setText("Total Grade: " + sum);
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Saves the inputs to a text file. Also updates the Saved Inputs dropdown.
     * TODO: Modify for database
     *
     * @param event
     */
    @FXML
    private void SaveButtonOnAction(ActionEvent event) {
        FileWrite FW = new FileWrite("Input.txt");
        try {
            FileWrite FW1 = new FileWrite("Hello.txt");
            InputTextinfo inputTextinfo = new InputTextinfo(InputName.getText(), Calendar.getInstance().getTime());
            inputTextinfo.setInputText(inputsList);
            FW1.UpdateData(inputTextinfo, "Hello.txt");
        } catch (IOException ex) {
            Logger.getLogger(CommandExecutor.class.getName()).log(Level.SEVERE, null, ex);
        }
        SaveInputTextChoiceBox.getItems().add(SavedInputsController.getInputs().get(SavedInputsController.getInputs().size() - 1));
    }

    /**
     * Start Grading/End Grading onAction Handler
     *
     * @param event
     * @throws IOException
     */
    @FXML
    private void StartEndGradingOnAction(ActionEvent event) throws IOException, SQLException {
        if (startGrading.getText().equals("End Grading")) {
            projectRunEndSequence();
            RemainingProjectsLabel.setText("Projects In Queue: " + ProjectLocations.size());
        } else {
            projectRunStartSequence();
            RemainingProjectsLabel.setText("Projects In Queue: " + ProjectLocations.size());
        }
    }

    /**
     * Sequence of operations for starting the project to be graded
     */
    private void projectRunStartSequence() throws SQLException, IOException {
        String studentName = ExecutionStudentDropdown.getSelectionModel().getSelectedItem().toString();
        String[] f = studentName.split("---");
        Integer studentId = Integer.parseInt(f[f.length - 1]);
        String Assignmentname = ExecutionAssignmentDropDown.getSelectionModel().getSelectedItem().toString();
        String CourseName = ExecutionSectionDropDown.getSelectionModel().getSelectedItem().toString();
        Unzipper unzipper = new Unzipper();
        System.out.println("**********" + ProjectLocations);
        String ProjLocation = unzipper.getmatchStudentWithSubmission(ProjectLocations, studentId);
        String JarLoc = "";
        System.out.println(ProjectLocations);
        try {
            JarLoc = unzipper.getJarLocation(ProjLocation);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "could Not Match Student", "Error in Grading", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String runParam = JarLoc;
        cmdExec = new CommandExecutor(this, CourseName, studentId, Assignmentname, destinationFilePath);
        ArrayList<String> commands = new ArrayList<>();
        String runCommand = "java -jar ";
        commands.add(runCommand);
        commands.add(runParam);
        cmdExec.execute(commands, CourseName, studentId, Assignmentname, runParam, ProjLocation);
        startGrading.setText("End Grading");

    }

    /**
     * Sequence of Operations to terminate and reset values
     *
     * @throws IOException
     * @throws java.sql.SQLException
     */
    public void projectRunEndSequence() throws IOException, SQLException {
        
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                try {
                    cmdExec.setPipeOpen(false);
                } catch (IOException ex) {
                    Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                }
                startGrading.setText("Start Grading");
                inputWindow.setText("");
                outputWindow.setText("");
                errorWindow.setText("");
                errorsList.clear();
                inputsList.clear();
                outputsList.clear();
                RemainingProjectsLabel.setText("Projects In Queue: " + ProjectLocations.size());
            }
        });
    }

    /**
     * OnAction Hander whenever an input is sent to the project being graded
     * (run)
     *
     * @param event
     */
    @FXML
    private void enterInputs(ActionEvent event) {
        TempInputCommand.add(inputTextArea.getText());
        inputTextArea.setText("");
    }

    /**
     * Unzips a project zip file and looks for the .jar filepath file which it
     * stores.
     *
     * @param event
     * @throws IOException
     */
    @FXML
    private void unzipFile(ActionEvent event) throws IOException {
        Unzipper unzipper = new Unzipper();
        FilePathPickerDialog getZipFile = new FilePathPickerDialog();

        String SourcePath = getZipFile.obtainFilePath(destinationFilePath, "zip");
        String Course = ExecutionSectionDropDown.getSelectionModel().getSelectedItem().toString();
        String Assignment = ExecutionAssignmentDropDown.getSelectionModel().getSelectedItem().toString();
        String Student = ExecutionStudentDropdown.getSelectionModel().getSelectedItem().toString();
        List<String> projLocation = unzipper.BigZipFileUnzipper(SourcePath, destinationFilePath, Course, Assignment);
        
        for (String loac : projLocation) {
            ProjectLocations.add(loac);
        }
        System.out.println(ProjectLocations);
        if (ProjectLocations.isEmpty()) {
            //TODO: Change System.out.println to dialog box
            System.out.println("no jar found");
        } else {
            //TODO: Change System.out.println to dialog box
            System.out.println("Project found");
        }
    }

    /**
     * used to update text areas whenever an input, output or error occurs on
     * the project
     */
    public void UpdateTextAreas() {
        String ErrorText = "";
        for (String errors : errorsList) {
            ErrorText += errors + "\n";
        }

        String OutputText = "";
        for (String Outputs : outputsList) {
            OutputText += Outputs + "\n";

        }

        String InputText = "";
        for (String Inputs : inputsList) {
            InputText += Inputs + "\n";
        }
        outputWindow.setText(OutputText);
        inputWindow.setText(InputText);
        errorWindow.setText(ErrorText);

    }

    /**
     * used by the jar executor to get and set error, input, output, InputName,
     * TempInputCommand values
     *
     * @param errorsList
     */
    public void setErrorsList(ArrayList<String> errorsList) {
        this.errorsList = errorsList;
    }

    public void setInputsList(ArrayList<String> inputsList) {
        this.inputsList = inputsList;
    }

    public void setOutputsList(ArrayList<String> outputsList) {
        this.outputsList = outputsList;
    }

    public ArrayList<String> getErrorsList() {
        return errorsList;
    }

    public ArrayList<String> getInputsList() {
        return inputsList;
    }

    public ArrayList<String> getOutputsList() {
        return outputsList;
    }

    public String getInputNameText() {
        return InputName.getText();
    }

    /**
     *
     * @return the last value inputed into the input text window. This will be
     * sent to project to be processed.
     */
    public String getTempInputCommand() {
        return TempInputCommand.remove(0);
    }

    public boolean TempInputCommandIsEmpty() {
        return TempInputCommand.isEmpty();
    }

    /**
     * Creates a new Rubric if new Rubric is selected in rubric_name_dropdown.
     * InputBox appears asking for the Rubric name. Updates an existing Rubric
     * if a Rubric is chosen in rubric_name_dropdown.
     *
     * @param event Button Click
     */
    @FXML
    private void saveRubric(ActionEvent event) {
        String rubricNameSelection = rubric_name_dropdown.getSelectionModel().getSelectedItem().toString();
        String rubricTypeSelection = rubric_type_dropdown.getSelectionModel().getSelectedItem().toString();

        //This for loop retrieves the text from each text field and assigns it
        //to a variable in order to create a criteria.
        if (rubricNameSelection != null && rubricTypeSelection != null) {
            //If new rubric
            if (rubricNameSelection.equals(newRubric)) {
                createRubric(rubricNameSelection, rubricTypeSelection);
            } else {
                //If rubric is updated
                updateRubric(rubricNameSelection, rubricTypeSelection);
            }

        }

    }

    /**
     * Creates a new HBox with TextFields and a Button. There is a standardized
     * naming method for these creations.
     *
     * @param event Button Click
     */
    @FXML
    private void createNewCriterion(ActionEvent event) {
        makeNewCriterion("", "", "", "", "");
    }

    /**
     * Adds new criterion to the GUI
     *
     * @param criterionName
     * @param percentTotal
     * @param goodPercentage
     * @param moderatePercentage
     * @param badPercentage
     */
    private void makeNewCriterion(String criterionName, String percentTotal, String goodPercentage, String moderatePercentage, String badPercentage) {
        HBox hb = new HBox();
        hb.setSpacing(spacing);
        hb.setId("h" + count);
        ArrayList<TextField> textFieldList = new ArrayList<>(numTextFields);
        for (int i = 0; i < numTextFields; i++) {
            TextField txt = new TextField();
            txt.setPrefWidth(textFieldWidth);
            textFieldList.add(txt);
            switch (i) {
                case 0:
                    textFieldList.get(i).setId("c" + count);
                    textFieldList.get(i).setText(criterionName);
                    break;

                case 1:
                    textFieldList.get(i).setId("p" + count);
                    textFieldList.get(i).setText(percentTotal);
                    textFieldList.get(i).setTextFormatter(new TextFormatter<>(filter));
                    break;

                case 2:
                    textFieldList.get(i).setId("g" + count);
                    textFieldList.get(i).setText(goodPercentage);
                    textFieldList.get(i).setTextFormatter(new TextFormatter<>(filter));
                    break;

                case 3:
                    textFieldList.get(i).setId("m" + count);
                    textFieldList.get(i).setText(moderatePercentage);
                    textFieldList.get(i).setTextFormatter(new TextFormatter<>(filter));
                    break;

                case 4:
                    textFieldList.get(i).setId("b" + count);
                    textFieldList.get(i).setText(badPercentage);
                    textFieldList.get(i).setTextFormatter(new TextFormatter<>(filter));
                    break;
            }
            hb.getChildren().add(textFieldList.get(i));
        }
        Button deleteCriterion = new Button();
        deleteCriterion.setId("d" + count);
        deleteCriterion.setText(criterionDeleteButtonName);
        deleteCriterion.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Button pressed = (Button) event.getSource();
                Integer findCount = Integer.parseInt(pressed.getId().substring(pressed.getId().length() - 1));
                HBox hbToBeDeleted = (HBox) vb.getChildren().get(findCount);
                vb.getChildren().remove(hbToBeDeleted);
                updateButtonId();
            }
        });
        hb.getChildren().add(deleteCriterion);
        count++;
        vb.getChildren().add(hb);
    }

    private void createRubric(String rubricNameSelection, String rubricTypeSelection) {
        if (!validateTextFields()) {
            return;
        }
        do {
            rubricNameSelection = JOptionPane.showInputDialog("Enter Rubric Name: ");
        } while (validateRubricName(rubricNameSelection));

        try {
            RubricCRUD cr2 = new RubricCRUD();
            cr2.create(rubricNameSelection, rubricTypeSelection);
            addAllCriteria(rubricNameSelection);
            ObservableList<String> rubrics = FXCollections.observableArrayList(cr2.getAllRubricNames());
            rubric_choice_box.setItems(rubrics);
            rubrics.add(0, newRubric);
            rubric_name_dropdown.setItems(rubrics);

            resetUserInput();

        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void updateRubric(String rubricNameSelection, String rubricTypeSelection) {
        if (!validateTextFields()) {
            return;
        }
        try {
            RubricCRUD cr = new RubricCRUD();
            cr.update(rubricNameSelection, rubricTypeSelection);
            if (addAllCriteria(rubricNameSelection)) {
                resetUserInput();
            }

        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private boolean validateTextFields() {
        for (int i = 0; i < vb.getChildren().size(); i++) {
            HBox hBox = (HBox) vb.getChildren().get(i);
            for (int k = 0; k < hBox.getChildren().size() - 1; k++) {
                TextField tField = (TextField) hBox.getChildren().get(k);
                if (tField.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "A Field is Empty");
                    criteriaArray = null;
                    return false;
                }
            }
        }
        return true;
    }

    private boolean validateRubricName(String name) {
        try {
            RubricCRUD cr = new RubricCRUD();
            ObservableList<String> rubrics = FXCollections.observableArrayList(cr.getAllRubricNames());
            for (String s : rubrics) {
                if (name.equals(s)) {
                    return true;
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    /**
     * Deletes a the existing selected Rubric in rubric_name_dropdown.
     *
     * @param event Button Click
     */
    @FXML
    private void deleteRubric(ActionEvent event) {

        String rubricName = rubric_name_dropdown.getSelectionModel().getSelectedItem().toString();
        if (!rubricName.equals(newRubric)) {
            try {
                RubricCRUD cr = new RubricCRUD();
                RubricCriteriaCRUD cr2 = new RubricCriteriaCRUD();
                RubricGradeCRUD cr3 = new RubricGradeCRUD();
                ObservableList<String> criteria = FXCollections.observableArrayList(cr2.getCriteria(rubricName));
                cr3.DeleteRubricGrade(rubricName);
                for (String s : criteria) {
                    cr2.delete(rubricName, s);
                }
                cr.Delete(rubricName);
                ObservableList<String> rubrics = FXCollections.observableArrayList(cr.getAllRubricNames());
                rubrics.add(0, newRubric);
                rubric_name_dropdown.setItems(rubrics);
            } catch (SQLException ex) {
                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            }
            resetUserInput();
        }
    }

    private void updateButtonId() {
        count = 0;
        for (Node node1 : vb.getChildren()) {
            HBox hbox = (HBox) node1;
            for (Node node2 : hbox.getChildren().subList(hbox.getChildren().size() - 1, hbox.getChildren().size())) {
                Button b = (Button) node2;
                b.setId("d" + count);
                b.setText(criterionDeleteButtonName);
                count++;
            }
        }
    }

    private Boolean addAllCriteria(String rubricNameSelection) {
        ArrayList<ArrayList<String>> criteria = new ArrayList<>();
        String name = "";
        double percentTotal = 0;
        double goodPercent = 0;
        double moderatePercent = 0;
        double badPercent = 0;
        double totalPercentSum = 0.0;
        double minimum = 0.0;
        double maximum = 100.0;
        for (int i = 0; i < vb.getChildren().size(); i++) {
            ArrayList<String> a = new ArrayList<>();
            criteria.add(a);
            HBox hBox = (HBox) vb.getChildren().get(i);

            for (int j = 0; j < hBox.getChildren().size() - 1; j++) {
                TextField tField = (TextField) hBox.getChildren().get(j);
                switch (j) {
                    case 0:
                        name = tField.getText();
                        int count = 0;
                        for (int k = i + 1; k < vb.getChildren().size(); k++) {
                            HBox testBox = (HBox) vb.getChildren().get(k);
                            TextField testfield = (TextField) testBox.getChildren().get(j);
                            if (name.equals(testfield.getText())) {
                                name = JOptionPane.showInputDialog(name + " already exists. Enter a different name:");
                                tField.setText(name);
                                count++;
                                j--;
                                break;
                            }
                        }
                        if (count == 0) {
                            System.out.println(name);
                            criteria.get(i).add(name);
                        }
                        break;
                    case 1:
                        percentTotal = Double.parseDouble(tField.getText());
                        if (percentTotal >= minimum && percentTotal <= maximum) {
                            criteria.get(i).add("" + percentTotal);
                        } else {
                            percentTotal = Double.parseDouble(JOptionPane.showInputDialog(percentTotal + " must be greater than or equal to " + minimum
                                    + "and less than or equal to " + maximum + ". Enter a different percentage:"));
                            tField.setText(Double.toString(percentTotal));
                            j--;
                        }
                        break;
                    case 2:
                        goodPercent = Double.parseDouble(tField.getText());
                        if (goodPercent >= minimum && goodPercent <= maximum) {
                            criteria.get(i).add("" + goodPercent);
                        } else {
                            goodPercent = Double.parseDouble(JOptionPane.showInputDialog(goodPercent + " must be greater than or equal to " + minimum
                                    + "and less than or equal to " + maximum + ". Enter a different percentage:"));
                            tField.setText(Double.toString(goodPercent));
                            j--;
                        }
                        break;
                    case 3:
                        moderatePercent = Double.parseDouble(tField.getText());
                        if (moderatePercent >= minimum && moderatePercent <= maximum) {
                            criteria.get(i).add("" + moderatePercent);
                        } else {
                            moderatePercent = Double.parseDouble(JOptionPane.showInputDialog(moderatePercent + " must be greater than or equal to " + minimum
                                    + "and less than or equal to " + maximum + ". Enter a different percentage:"));
                            tField.setText(Double.toString(moderatePercent));
                            j--;
                        }
                        break;
                    case 4:
                        badPercent = Double.parseDouble(tField.getText());
                        if (badPercent >= minimum && badPercent <= maximum) {
                            criteria.get(i).add("" + badPercent);
                        } else {
                            badPercent = Double.parseDouble(JOptionPane.showInputDialog(badPercent + " must be greater than or equal to " + minimum
                                    + "and less than or equal to " + maximum + ". Enter a different percentage:"));
                            tField.setText(Double.toString(badPercent));
                            j--;
                        }
                        break;
                    default:
                        System.out.println("sorry try again");
                }
            }
        }
        for (int j = 0; j < criteria.size(); j++) {
            totalPercentSum += Double.parseDouble(criteria.get(j).get(1));
        }
        if (totalPercentSum != maximum) {
            criteria = null;
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Check Input");
            alert.setHeaderText(null);
            alert.setContentText("The total percent sum is: " + totalPercentSum + ". Fix then click save to save this rubric.");
            alert.showAndWait();
            return false;
        }
        try {
            RubricCriteriaCRUD cr = new RubricCriteriaCRUD();
            if (criteria != null) {
                ArrayList<String> existingCriteria = cr.getCriteria(rubricNameSelection);
                for (String a : existingCriteria) {
                    cr.delete(rubricNameSelection, a);
                }
                for (ArrayList<String> a : criteria) {
                    cr.create(rubricNameSelection, a.get(0), Double.parseDouble(a.get(1)), Double.parseDouble(a.get(2)),
                            Double.parseDouble(a.get(3)), Double.parseDouble(a.get(4)));
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    private void clearVBox() {
        vb.getChildren().clear();
        updateButtonId();

    }

    private void updateVBox() {
        clearVBox();
        try {
            RubricCriteriaCRUD cr = new RubricCriteriaCRUD();
            String rubricName = rubric_name_dropdown.getSelectionModel().getSelectedItem().toString();
            if (!rubricName.equals(newRubric)) {
                ArrayList<String> criteria = cr.getCriteria(rubricName);
                for (String s : criteria) {
                    ArrayList<Double> critList = cr.retrieveCriteriaList(rubricName, s);
                    makeNewCriterion(s, "" + critList.get(0), "" + critList.get(1), "" + critList.get(2), "" + critList.get(3));
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void resetUserInput() {
        clearVBox();
        rubric = null;
        rubric_name_dropdown.setValue(null);
        rubric_type_dropdown.setValue(null);
        rubric_type_dropdown.setDisable(true);
        new_criterion_button.disableProperty().set(true);
        save_button.disableProperty().set(true);
        delete_button.disableProperty().set(true);
    }

    /**
     * This button controls saving the course information, and handles all error
     * handling that might occur in the saving process.
     *
     * @param event
     * @throws IOException
     */
    @FXML
    private void handleSaveButton(ActionEvent event) throws IOException, SQLException {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(errorMessageTitle);
        alert.setHeaderText(errorMessageHeader);
        String subject = "";
        String number = "";
        String section = "";
        String term = "";
        String year = "";
        if (textContainsInts(subjectBox.getText())) {
            alert.setContentText(subjectErrorText);
            alert.showAndWait();
        } else if (!textIsOnlyInts(numberBox.getText())) {
            alert.setContentText(numberErrorText);
            alert.showAndWait();
        } else if (textContainsInts(sectionBox.getText())) {
            alert.setContentText(sectionErrorText);
            alert.showAndWait();
        } else if (!textIsOnlyInts(yearBox.getText())) {
            alert.setContentText(yearErrorText);
            alert.showAndWait();
        } else if (termDropDown.getSelectionModel().getSelectedItem() == null) {
            alert.setContentText(termErrorText);
            alert.showAndWait();
        } else {
            //Assigns the inputs to variables for use in creating a file, later to 
            //be used to updated the database
            subject = subjectBox.getText().toUpperCase();
            number = numberBox.getText();
            section = sectionBox.getText().toUpperCase();
            year = yearBox.getText();
            term = termDropDown.getSelectionModel().getSelectedItem().toString();
            String courseName = subject + number + section + term + year;
            SectionCRUD sectionCRUD = new SectionCRUD();
            sectionCRUD.Create(courseName);
            UpdateCourseDropdown();
            studentVBox.getChildren().clear();
        }
    }

    /**
     * This method checks to see if a text input contains any numbers.
     *
     * @param testText
     * @return
     */
    private boolean textContainsInts(String testText) {
        for (int i = 0; i < testText.length(); i++) {
            if (Character.isDigit(testText.charAt(i))) {
                return true;
            }
        }
        return false;
    }

    /**
     * This method verifies that a text input only contains numbers.
     *
     * @param testText
     * @return
     */
    private boolean textIsOnlyInts(String testText) {
        for (int i = 0; i < testText.length(); i++) {
            if (Character.isLetter(testText.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    @FXML
    private void handleDeleteCourseButton(ActionEvent event) throws SQLException {
        String SectionName = courseDropDown.getSelectionModel().getSelectedItem().toString();
        SectionCRUD sectionCRUD = new SectionCRUD();
        SectionStudentCRUD sectionStudentCRUD = new SectionStudentCRUD();
        SectionAssignmentCRUD sectionAssignmentCRUD = new SectionAssignmentCRUD();
        RubricGradeCRUD rubricGradeCRUD = new RubricGradeCRUD();

        rubricGradeCRUD.DeleteSectionGrade(SectionName);
        sectionStudentCRUD.DeleteSectionEntry(SectionName);
        sectionAssignmentCRUD.DeleteAllSectionNameEntry(SectionName);
        sectionCRUD.DeleteEntry(SectionName);
        UpdateCourseDropdown();
        studentVBox.getChildren().clear();
    }

    /**
     * This button will delete whatever names are selected by referencing the
     * checked boxes.
     *
     * @param event
     */
    @FXML
    private void handleDeleteSelectedButton(ActionEvent event) throws SQLException {
        for (CheckBox c : checkBoxes) {
            updateBoxID();
            int hBoxNum = Integer.parseInt(c.getId());
            HBox hbox = (HBox) studentVBox.getChildren().get(hBoxNum);
            Label idLbl = (Label) hbox.getChildren().get(2);
            String courseName = courseDropDown.getSelectionModel().getSelectedItem().toString();
            System.out.println(courseName + Integer.parseInt(idLbl.getText()));
            SectionStudentCRUD ssCRUD = new SectionStudentCRUD();
            ssCRUD.DeleteEntry(courseName, Integer.parseInt(idLbl.getText()));

            studentVBox.getChildren().remove(hbox);
            //updateBoxID();
        }

        checkBoxes.clear();
    }

    /**
     * This method is used for updating the IDs of the boxes, for ease of
     * tracking.
     */
    private void updateBoxID() {
        hBoxCount = 0;
        int numBoxes = studentVBox.getChildren().size();
        for (int i = 0; i < numBoxes; i++) {
            HBox hBox = (HBox) studentVBox.getChildren().get(i);
            hBox.setId("" + hBoxCount);
            hBox.getChildren().get(hBox.getChildren().size() - 1).setId("" + hBoxCount);
            hBoxCount++;
        }
    }

    /**
     * This button marks all check boxes on first click, and unmarks them all on
     * the second click.
     *
     * @param event
     */
    @FXML
    private void handleMarkAllButton(ActionEvent event) {
        switch (markAllCount % 2) {
            case 0:
                for (int i = 0; i < hBoxCount; i++) {
                    HBox hBox = (HBox) studentVBox.getChildren().get(i);
                    CheckBox checkBox = (CheckBox) hBox.getChildren().get(4);
                    checkBox.setSelected(true);
                    checkBoxes.add(checkBox);
                }
                ;
                markAllButton.setText("Clear All");
                break;
            case 1:
                for (int i = 0; i < hBoxCount; i++) {
                    HBox hBox = (HBox) studentVBox.getChildren().get(i);
                    CheckBox checkBox = (CheckBox) hBox.getChildren().get(4);
                    checkBox.setSelected(false);
                }
                ;
                checkBoxes.clear();
                markAllButton.setText("Mark All");
                break;
        }
        markAllCount++;
    }

    /**
     * This button will add student names only if they have not been entered
     * before
     *
     * @param event
     */
    @FXML
    private void handleAddStudentButton(ActionEvent event) throws SQLException {
        String studentName = newStudentBox.getText();
        String studentId = newStudentIdBox.getText();
        if (!studentName.equals(null) && !studentId.equals(null)) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(errorMessageTitle);
            alert.setHeaderText(errorMessageHeader);
            if (!textIsOnlyInts(studentId)) {
                alert.setContentText("Invalid ID, please enter only integers");
                alert.showAndWait();
            } else if (studentName.equals("") || studentId.equals("")) {
                alert.setContentText("Either Student Name or Student ID fields are empty, please enter values");
                alert.showAndWait();
            } else {
                if (checkForStudentName(studentName)) {
                    alert.setContentText("Student name already exists");
                    alert.showAndWait();
                } else if (checkForStudentId(Integer.parseInt(studentId))) {
                    alert.setContentText("Student ID already exists");
                    alert.showAndWait();
                } else {
                    Student student = new Student(studentName, Integer.parseInt(studentId));
                    if (checkForStudent(student)) {
                        alert.setContentText("Student already exists");
                        alert.showAndWait();
                    } else {
                        makeNewStudent(student.getStudentName(), student.getIdNum());
                        newStudentBox.setPromptText("Enter new Student Name Here");
                        newStudentBox.clear();
                        newStudentIdBox.setPromptText("Enter new ID Here");
                        newStudentIdBox.clear();
                    }
                }
            }
        }
    }

    /**
     * This button will add students to the course that is selected
     *
     * @param event
     */
    @FXML
    private void handleAssignStudentsButton(ActionEvent event) throws SQLException {
        String courseName = courseDropDown.getSelectionModel().getSelectedItem().toString();
        StudentCRUD studentCrud = new StudentCRUD();
        SectionStudentCRUD ssCRUD = new SectionStudentCRUD();
        for (CheckBox checkBox : checkBoxes) {
            //System.out.println(students.get(Integer.parseInt(checkBox.getId())).getStudentName());
            Integer studentId = students.get(Integer.parseInt(checkBox.getId())).getIdNum();
            String studentName = students.get(Integer.parseInt(checkBox.getId())).getStudentName();
            if (studentCrud.retrieveStudentName(studentId) == null) {
                studentCrud.Create(studentId, studentName);
            }
            ArrayList<Integer> studentsInSection = ssCRUD.retrieveStudentsInSection(courseName);
            if (!studentsInSection.contains(studentId)) {
                ssCRUD.Create(courseName, studentId);
            }
        }
    }

    /**
     * Same as initialize method... did it to keep our main one less clunky.
     */
    private void initializeCourseTab() throws SQLException {
        disableCourseCreatorOptions();
        SectionCRUD sectionCRUD = new SectionCRUD();
        SectionStudentCRUD ssCrud = new SectionStudentCRUD();
        assignStudentsButton.setDisable(true);
        List<String> courses = new ArrayList<>();
        courses.add("New Course");
        courses.addAll(sectionCRUD.retrieveSectionName());
        courseDropDown.getItems().addAll(courses);

        StudentCRUD studCrud = new StudentCRUD();
        courseDropDown.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                if (newValue != null) {
                    enableCourseCreatorOptions();
                }
                if (courseDropDown.getSelectionModel().getSelectedIndex() == 0) {
                    emptyCourseCreatorOptions();
                }
                if (newValue != null) {
                    ArrayList<String> sections = sectionCRUD.retrieveSectionName();
                    studentVBox.getChildren().clear();
                    for (String section : sections) {
                        if (section.equals(newValue)) {
                            List<Integer> list = ssCrud.retrieveStudentsInSection(section);
                            for (Integer studentID : list) {
                                String studentName = studCrud.retrieveStudentName(studentID);
                                makeNewStudent(studentName, studentID);
                            }
                        }
                    }
                }
            }
        });
        termDropDown.setItems(termNames);

    }

    /**
     * Disables the section title input areas.
     */
    private void disableCourseCreatorOptions() {
        subjectBox.setDisable(true);
        numberBox.setDisable(true);
        sectionBox.setDisable(true);
        termDropDown.setDisable(true);
        yearBox.setDisable(true);
        saveButton.setDisable(true);
        deleteButton.setDisable(true);
    }

    /**
     * Enables the section title input areas.
     */
    private void enableCourseCreatorOptions() {
        subjectBox.setDisable(false);
        numberBox.setDisable(false);
        sectionBox.setDisable(false);
        termDropDown.setDisable(false);
        yearBox.setDisable(false);
        saveButton.setDisable(false);
        deleteButton.setDisable(false);
    }

    private void UpdateCourseDropdown() throws SQLException {
        SectionCRUD sectionCRUD = new SectionCRUD();
        List<String> courses = new ArrayList<>();
        courses.add("New Course");
        courses.addAll(sectionCRUD.retrieveSectionName());
        courseDropDown.getItems().clear();
        courseDropDown.getItems().addAll(courses);
        disableCourseCreatorOptions();
        courseDrop.getItems().clear();
        courseDrop.getItems().addAll(courses);
    }

    /**
     * Clears the previously entered data from each field in the title input
     * areas.
     */
    private void emptyCourseCreatorOptions() {
        subjectBox.clear();
        numberBox.clear();
        sectionBox.clear();
        termDropDown.setValue(null);
        yearBox.clear();
    }

    @FXML
    private void HandleGetStudentFromSubmission(ActionEvent event) throws IOException {
        String Path = FilePathPickerDialog.obtainFolderPath();
        List<String> StudentNames = FileWrite.getStudentNameFromPath(Path);
        List<Integer> StudentID = FileWrite.getIdFromPath(Path);
        for (Integer i : StudentID) {
            System.out.println(i);
        }
        for (int i = 0; i < StudentNames.size(); i++) {
            //System.out.println(StudentNames);
            //Student student = new Student(names, "100");
            if (!StudentNames.get(i).equals(null)) {
//                if (!students.contains(StudentNames.get(i)) && !names.equals(null)) {
                makeNewStudent(StudentNames.get(i), StudentID.get(i));
                newStudentBox.setPromptText("Enter New Student Name Here");
                newStudentBox.clear();
//                } else {
//                    if (!names.equals("")) {
//                        newStudentBox.setPromptText("Name Already Exists");
//                        newStudentBox.clear();
//                    } else {
//                        newStudentBox.setPromptText("Please Enter A Name");
//                    }
                //}
            }
        }
    }

    /**
     * This method creates a new student instance and adds a row to the scroll
     * pane. This row also contains a checkbox, of whose event handler
     * attributes are set here.
     *
     * @param name
     */
    private void makeNewStudent(String name, int id) {
        HBox hbox = new HBox();
        Region r1 = new Region(); //Blank region used for spacing
        Region r2 = new Region();
        HBox.setHgrow(r1, Priority.ALWAYS); //This is used for good spacing
        HBox.setHgrow(r2, Priority.ALWAYS); //This is used for good spacing
        hbox.setId("" + hBoxCount);
        Label nameLbl = new Label();
        Label idLbl = new Label();
        CheckBox checkBox = new CheckBox();
        nameLbl.setText(name);
        idLbl.setText("" + id);
        Student student = new Student(name, id);
        students.add(student);
        nameLbl.setFont(Font.font(fontType, fontSize));
        idLbl.setFont(Font.font(fontType, fontSize));
        checkBox.setId("" + hBoxCount);
        checkBox.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (checkBox.isSelected()) {
                    checkBoxes.add(checkBox);
                } else {
                    checkBoxes.remove(checkBox);
                }
            }
        });
        hbox.getChildren().addAll(nameLbl, r1, idLbl, r2, checkBox);
        hBoxCount++;
        studentVBox.getChildren().add(hbox);
        assignStudentsButton.setDisable(false);
    }

    /**
     * This checks to see if the entered student name already exists.
     *
     * @param student
     * @return
     */
    private boolean checkForStudent(Student student) {
        return students.contains(student);
    }

    private boolean checkForStudentName(String student) {
        for (int i = 0; i < students.size(); i++) {
            if (student.equals(students.get(i).getStudentName())) {
                return true;
            }
        }
        return false;
    }

    private boolean checkForStudentId(int studentId) {
        for (int i = 0; i < students.size(); i++) {
            System.out.println(students.get(i).getIdNum());
            if (studentId == students.get(i).getIdNum()) {
                return true;
            }
        }
        return false;
    }

    @FXML
    private Label errorLabel;
    @FXML
    private Button deleteassingmentButton;
    @FXML
    private Button saveassingmentButton;
    @FXML
    private Button doneButton;
    @FXML
    private Button testButton;
    @FXML
    private Pane assingmentpagePane;
    @FXML
    private ChoiceBox assingmentDrop;
    @FXML
    private ChoiceBox courseDrop;
    @FXML
    private TextField assingmentField;

    //  private ObservableList<String> coursenametracker     = FXCollections.observableArrayList();
    // private ObservableList<String> assingments     = FXCollections.observableArrayList();
    //private ObservableList<Course> courses     = FXCollections.observableArrayList();
    public ObservableList<String> sections = FXCollections.observableArrayList();
    public ObservableList<String> assingments = FXCollections.observableArrayList();

    @FXML
    private void handleSaveButtonAction(ActionEvent event) throws SQLException {

        Integer assingmentNameLimit = 32;
        SectionCRUD section = new SectionCRUD();

        if (!assingments.contains(assingmentField.getText()) && !"".equals(assingmentField.getText()) && assingmentField.getText() != null) {
            if (assingmentField.getText().length() < assingmentNameLimit && courseDrop.getItems().contains(courseDrop.getValue())) {

                SectionAssignmentCRUD sa = new SectionAssignmentCRUD();
                AssignmentCRUD ad = new AssignmentCRUD();
                if (!"Create New Assingment".equals(assingmentDrop.getValue().toString())) {
                    assingments.remove(assingmentDrop.getValue().toString());
                    ad.DeleteEntry(assingmentDrop.getValue().toString());
                    sa.DeleteEntry(courseDrop.getValue().toString(), assingmentDrop.getValue().toString());

                    if (!ad.retrieveAssignmentNames().contains(assingmentField.getText())) {
                        ad.Create(assingmentField.getText());

                    }
                    // assingments.add(assingmentField.getText());
                    sa.Create(courseDrop.getValue().toString(), assingmentField.getText());

                } else if ("Create New Assingment".equals(assingmentDrop.getValue().toString())) {
                    if (!ad.retrieveAssignmentNames().contains(assingmentField.getText())) {
                        ad.Create(assingmentField.getText());

                    }
                    //   assingments.add(assingmentField.getText());

                    sa.Create(courseDrop.getValue().toString(), assingmentField.getText());
                }
            }
            //createHelp();
            assingmentField.clear();
            SectionAssignmentCRUD sa = new SectionAssignmentCRUD();
            handleassingmentDrop();

        }

    }

    @FXML
    private void handleDeleteButtonAction(ActionEvent event) throws SQLException {

        if (courseDrop.getItems().contains(courseDrop.getValue())) {
            //SectionCRUD section = new SectionCRUD();
            SectionAssignmentCRUD sa = new SectionAssignmentCRUD();
            AssignmentCRUD ad = new AssignmentCRUD();
            String notNull = (String) assingmentDrop.getValue().toString();
            String assingmentValue = (String) assingmentDrop.getValue().toString();
            System.out.println("what was that?");
            System.out.println(assingmentDrop.getValue().toString());
            if (!notNull.equals(null) && !assingmentValue.equals("Create New Assingment")) {
                System.out.println("fuck that came from inside the house");

                //ad.DeleteEntry(assingmentDrop.getValue().toString());
                sa.DeleteEntry(courseDrop.getValue().toString(), assingmentDrop.getValue().toString());
                assingments.remove(assingmentDrop.getValue().toString());
                assingmentField.clear();
            }

        } else {

        }

    }

    @FXML
    private void handleDoneButton(ActionEvent event) {

        assingmentpagePane.setVisible(false);

    }

    @FXML
    private void handleassingmentButton(ActionEvent event) {

        assingmentpagePane.setVisible(true);

    }

    public void handleassingmentDrop() {

        SectionAssignmentCRUD sa;
        try {
            sa = new SectionAssignmentCRUD();
            assingments.clear();
            assingments.addAll(sa.retrieveAssignmentsInSection(courseDrop.getValue().toString()));
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        assingmentDrop.setItems(assingments);
        assingments.add(0, "Create New Assingment");
        assingmentDrop.setValue("Create New Assingment");

    }

    public void initializeAssingment() {
        assingmentpagePane.setStyle("-fx-background-color: silver");
        assingmentpagePane.setVisible(false);

        assingmentpagePane.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, new CornerRadii(10), new BorderWidths(3))));

        try {
            SectionCRUD section = new SectionCRUD();
            sections.addAll(section.retrieveSectionName());

        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }

        courseDrop.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                SectionAssignmentCRUD sa;
                try {
                    sa = new SectionAssignmentCRUD();
                    assingments.setAll(sa.retrieveAssignmentsInSection(courseDrop.getSelectionModel().getSelectedItem().toString()));
                } catch (SQLException ex) {
                    Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                }
                handleassingmentDrop();

            }

        });

        courseDrop.setItems(sections);

    }

}
