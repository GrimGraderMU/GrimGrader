package CRUD;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Anthony
 */
public class SubmissionCRUD {
    private final String slash = "\\";//----Used for FilePaths
    /**
     * the next three are for filepaths
     */
       private final String d = "jdbc:postgresql://10.76.17.197/GrimGraderDataBase";
       private final String u = "grimGrader";
       private final String p = "Here Dies Grades";
       /*
       The following four are SQL Statements that are sent to the Database
       the questionmarks are indicies that the methods use to fill in the blanks, they 
       start from 1, and increment by one
       */
       private final String insertSQL = "INSERT INTO public.submission VALUES (?,?,?,?)";
       private final String updateSQL = "UPDATE public.submission " + 
                "set "+
                "zipfile = ?, " + 
                "outputfile = ?, " + 
                "inputfile = ?, " + 
                "errorfile = ?, " + 
                "docsfile = ?, " + 
                "magicfile = ? " +
                "where (" + 
                "studentid = ? and " +
                "assignmentname = ? and " +
                "sectionname = ?)";
       
       private final String dropSQL = "Delete FROM public.submission WHERE( " +
               "studentid = ? and " + 
               "assignmentname = ? and " + 
               "sectionname = ? )";
       private final String getSQLpt2 = "from public.submission " +
                "where( " + 
                "studentid = ? and " +
                "assignmentname = ? and " +
                "sectionname = ?)";
       private Connection con;//the connection to the database
       private FileInputStream fis;//what is used to read the file to the machine
       public SubmissionCRUD() throws SQLException{
                   con = DriverManager.getConnection(d, u, p);
       }
    
       /**
        * Creates the initial entry into the table. 
        * returns true if successful
        * @param zipFilePath the file uploaded
        * @param Section what section
        * @param Assignment what assignment
        * @param Student which student
        * @return 
        */
    public Boolean Create(String zipFilePath, String Section, String Assignment, Integer Student){
        File file = new File(zipFilePath);

        try {
            fis = new FileInputStream(file);
            PreparedStatement ps = con.prepareStatement(insertSQL);
            ps.setInt(1, Student);
            ps.setString(2, Section);
            ps.setString(3, Assignment);
            ps.setBinaryStream(4, fis, (int)file.length());
            ps.executeUpdate();
            ps.close();
            fis.close();
            return true;
        } catch (FileNotFoundException ex) {

            Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);
                        return false;
        } catch (SQLException ex) {
           
               Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);
                return false;
        } catch (IOException ex) {

            Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);
                        return false;
        }
    }
    
    /**
     * Fills in entries that are not nulled
     * * returns true if successful
     * @param zipFilePath required
     * @param Section required
     * @param Assignment required
     * @param Student required
     * @param outputFilePath nullable
     * @param inputFilePath nullable
     * @param errorFilePath nullable
     * @param documentationFilePath nullable
     * @param magicFilePath nullable
     * @return 
     */
    public Boolean Update(String zipFilePath, String Section, String Assignment, Integer Student, 
            String outputFilePath, String inputFilePath, String errorFilePath, String documentationFilePath, String magicFilePath){
            File zipFile = new File(zipFilePath);
            int zi = 1;
            int ou = 2;
            int in = 3;
            int er = 4;
            int doc = 5;
            int mag = 6;
            int stn = 7;
            int asn = 8;
            int sec = 9;
        try {
            fis = new FileInputStream(zipFile);
            PreparedStatement ps = con.prepareStatement(updateSQL);
            ps.setString(sec, Section);
            ps.setString(asn, Assignment);
            ps.setInt(stn, Student);
            ps.setBinaryStream(zi, fis, (int)zipFile.length());
            if(inputFilePath!=null){//---------------------------------------------INPUT FILE
                File inF = new File(inputFilePath);
                fis = new FileInputStream(inF);
                ps.setBinaryStream(in, fis, (int) inF.length());
            }
            else{
                System.out.println("null input");
                Blob b = null;
                ps.setBlob(in, b);
            }
            if(outputFilePath!=null){//--------------------------------------------OUTPUT FILE
                File F = new File(outputFilePath);
                fis = new FileInputStream(F);
                ps.setBinaryStream(ou, fis, (int) F.length());
            }
            else{
                System.out.println("null output");
                Blob b = null;
                ps.setBlob(ou, b);
            }            
            if(errorFilePath!=null){//---------------------------------------------ERROR FILE
                File F = new File(outputFilePath);
                fis = new FileInputStream(F);
                ps.setBinaryStream(er, fis, (int) F.length());
            }
            else{
                
                System.out.println("null error");
                Blob b = null;
                ps.setBlob(er, b);
            }            
            if(documentationFilePath!=null){//-------------------------------------DOCUMENTATION FILE
                File F = new File(documentationFilePath);
                fis = new FileInputStream(F);
                ps.setBinaryStream(doc, fis, (int) F.length());
            }
            else{
                
                System.out.println("null docs");
                Blob b = null;
                ps.setBlob(doc, b);
            }            
            if(magicFilePath!=null){//---------------------------------------------MAGIC FILE
                File F = new File(inputFilePath);
                fis = new FileInputStream(F);
                ps.setBinaryStream(mag, fis, (int) F.length());
            }
            else{
                
                System.out.println("null magic");
                Blob b = null;
                ps.setBlob(mag, b);
            }            
            ps.executeUpdate();
            ps.close();
            fis.close();
            return true;
        } catch (FileNotFoundException ex) {
            
            Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        } catch (SQLException ex) {
            
               Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);
               return false;
        } catch (IOException ex) {
            
            Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
        
    }

    /**
     * retrieves a zip from a specific entry if found
     * * returns true if successful
     * @param Section
     * @param Assignment
     * @param Student
     * @param initFilePath //the initial section where the filepath begins (set by user)
     * @return 
     */
    public Boolean retrieveZip(String Section, String Assignment, Integer Student, String initFilePath){
        String q = "Select zipfile " + getSQLpt2;
        PreparedStatement ps;
        try {
            ps = con.prepareStatement(q);
            int stu = 1;
            int asn = 2;
            int sec = 3;
            ps.setInt(stu, Student);
            ps.setString(asn, Assignment);
            ps.setString(sec, Section);
            ResultSet rs = ps.executeQuery();
            int i = 0;
            File f = new File(initFilePath + slash + Section + slash + Assignment + slash + Student);
            if(!f.exists()){f.mkdirs();}
            while (rs.next()) {
                byte[] imgBytes = rs.getBytes(1);

                System.out.println(f.getAbsolutePath());
                FileOutputStream fo = new FileOutputStream(initFilePath + slash + Section + slash + Assignment + slash + Student +slash + "Sub.zip");

                
                fo.write(imgBytes);
                i++;
            }
            return true;
        } catch (SQLException ex) {
           
            Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex); return false;
        } catch (IOException ex) {
            
            Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);return false;
        }

    
    }
    
    public Boolean retrieveOutputFile(String Section, String Assignment, Integer Student, String initFilePath){
        String q = "Select outputfile " + getSQLpt2;
        PreparedStatement ps;
        try {
            ps = con.prepareStatement(q);
            int stu = 1;
            int asn = 2;
            int sec = 3;
            ps.setInt(stu, Student);
            ps.setString(asn, Assignment);
            ps.setString(sec, Section);
            ResultSet rs = ps.executeQuery();
            int i = 0;
            File f = new File(initFilePath + slash + Section + slash + Assignment + slash + Student);
            if(!f.exists()){f.mkdirs();}
            while (rs.next()) {
                byte[] imgBytes = rs.getBytes(1);
                
                FileOutputStream fo = new FileOutputStream(initFilePath + slash + Section + slash + Assignment + slash + Student + slash + Student +  "Output.txt");
                fo.write(imgBytes);
                i++;
            }
            return true;
        } catch (SQLException ex) {
            return false;
            //Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            return false;
            //Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);
        }

    
    }
    
    public Boolean retrieveInputFile(String Section, String Assignment, Integer Student, String initFilePath){
        String q = "Select inputfile " + getSQLpt2;
        PreparedStatement ps;
        try { 
            ps = con.prepareStatement(q);
            int stu = 1;
            int asn = 2;
            int sec = 3;
            ps.setInt(stu, Student);
            ps.setString(asn, Assignment);
            ps.setString(sec, Section);
            ResultSet rs = ps.executeQuery();
            int i = 0;
            File f = new File(initFilePath + slash + Section + slash + Assignment + slash + Student);
            if(!f.exists()){f.mkdirs();}
            while (rs.next()) {
                byte[] imgBytes = rs.getBytes(1);
                FileOutputStream fo = new FileOutputStream(initFilePath + slash + Section + slash + Assignment + slash + Student + slash + Student + "Input.txt");
                fo.write(imgBytes);
                i++;
            }
            return true;
        } catch (SQLException ex) {
            return false;
            //Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            return false;
            //Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);
        }

    
    }  
    
    public Boolean retrieveErrorFile(String Section, String Assignment, Integer Student, String initFilePath){
        String q = "Select errorfile " + getSQLpt2;
        PreparedStatement ps;
        try {
            ps = con.prepareStatement(q);
            int stu = 1;
            int asn = 2;
            int sec = 3;
            ps.setInt(stu, Student);
            ps.setString(asn, Assignment);
            ps.setString(sec, Section);
            ResultSet rs = ps.executeQuery();
            int i = 0;
            File f = new File(initFilePath + slash + Section + slash + Assignment + slash + Student);
            if(!f.exists()){f.mkdirs();}
            while (rs.next()) {
                byte[] imgBytes = rs.getBytes(1);
                FileOutputStream fo = new FileOutputStream(initFilePath + slash + Section + slash + Assignment + slash + Student + slash + Student + "Error.txt");
                fo.write(imgBytes);
                i++;
            }
            return true;
        } catch (SQLException ex) {
            return false;
            //Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            return false;
            //Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);
        }

    
    }  
    
    public Boolean retrieveDocumentationFile(String Section, String Assignment, Integer Student, String initFilePath){
        String q = "Select docsfile " + getSQLpt2;
        PreparedStatement ps;
        try {
            ps = con.prepareStatement(q);
            int stu = 1;
            int asn = 2;
            int sec = 3;
            ps.setInt(stu, Student);
            ps.setString(asn, Assignment);
            ps.setString(sec, Section);
            ResultSet rs = ps.executeQuery();
            int i = 0;
            File f = new File(initFilePath + slash + Section + slash + Assignment + slash + Student);
            if(!f.exists()){f.mkdirs();}
            while (rs.next()) {
                byte[] imgBytes = rs.getBytes(1);
                FileOutputStream fo = new FileOutputStream(initFilePath + slash + Section + slash + Assignment + slash + Student + slash + Student + "Documentation.txt");
                fo.write(imgBytes);
                i++;
            }
            return true;
        } catch (SQLException ex) {
            return false;
            //Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            return false;
            //Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);
        }

    
    }  
    
    public Boolean retrieveMagicNumbersFile(String Section, String Assignment, Integer Student, String initFilePath){
        String q = "Select magicfile " + getSQLpt2;
        PreparedStatement ps;
        try {
            ps = con.prepareStatement(q);
            int stu = 1;
            int asn = 2;
            int sec = 3;
            ps.setInt(stu, Student);
            ps.setString(asn, Assignment);
            ps.setString(sec, Section);
            ResultSet rs = ps.executeQuery();
            int i = 0;
            File f = new File(initFilePath + slash + Section + slash + Assignment + slash + Student);
            if(!f.exists()){f.mkdirs();}
            while (rs.next()) {
                byte[] imgBytes = rs.getBytes(1);
                FileOutputStream fo = new FileOutputStream(initFilePath + slash + Section + slash + Assignment + slash + Student + slash + Student + "MagicNumbers.txt");
                fo.write(imgBytes);
                i++;
            }
            return true;
        } catch (SQLException ex) {
            return false;
            //Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            return false;
            //Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);
        }

    
    }  

    /**
     * deletes an entry from the table
     * * returns true if successful
     * @param Section
     * @param Assignment
     * @param Student
     * @return 
     */
    public Boolean DeleteEntry(String Section, String Assignment, Integer Student){
        try {
            PreparedStatement ps = con.prepareStatement(dropSQL);
            int stu = 1;
            int asn = 2;
            int sec = 3;
            ps.setInt(stu, Student);
            ps.setString(asn, Assignment);
            ps.setString(sec, Section);
            ps.execute();
            ps.close();
            return true;
        } catch (SQLException ex) {
            return false;
            //Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

