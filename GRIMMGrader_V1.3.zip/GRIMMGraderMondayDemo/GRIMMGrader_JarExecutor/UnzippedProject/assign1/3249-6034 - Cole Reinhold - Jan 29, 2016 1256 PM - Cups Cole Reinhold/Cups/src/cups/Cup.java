/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cups;

/**
 *
 * @author CSReinhold2019
 */
public class Cup {
    
   int gulp =10;
    
    public void fill()
    {
       gulp=gulp+10;
           
    }
    
    public void empty()
    {
       gulp = gulp-10;
    }
    
    public Boolean isfull()
    {
       if(gulp = 10)
       {
           return true;
           
       }
       if (gulp = 0)
       {
           return false;
       }
    }
    
    public boolean isempty()
    {
       if(gulp = 0)
       {
           return true;
       }
       else
       {
           return false;
       }
    }
    
    public void sip()
    {
        gulp = gulp -1;
    }
}
