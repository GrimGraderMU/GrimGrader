package grimmgrader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Anthony
 */
public class SubmissionCRUD {

    private final String slash = "//";
    private final String d = "jdbc:postgresql://10.76.17.197/FileStorageTest";
    private final String u = "grimGrader";
    private final String p = "Here Dies Grades";
    private final String insertSQL = "INSERT INTO public.submission VALUES (?,?,?,?)";
    private final String updateSQL = "UPDATE public.submission "
            + "set"
            + "zipfile = ?, "
            + "outputfile = ?, "
            + "inputfile = ?, "
            + "errorfile = ?, "
            + "docsfile = ?, "
            + "magicfile = ? "
            + "where "
            + "studentname = ?, "
            + "assignment = ?, "
            + "sectionname = ?";
    private final String dropSQL = "Delete FROM public.submission WHERE"
            + "studentname = ?, "
            + "assignmentname = ?, "
            + "sectionname = ? ";
    private final String getSQLpt2 = "from public.submission"
            + "where "
            + "studentname = ?, "
            + "assignment = ?, "
            + "sectionname = ?";
    ;
       private Connection con;
    private FileInputStream fis;

    public SubmissionCRUD() throws SQLException {
        con = DriverManager.getConnection(d, u, p);
    }

    public Boolean Create(String zipFilePath, String Section, String Assignment, String Student) {
        File file = new File(zipFilePath);

        try {
            fis = new FileInputStream(file);
            PreparedStatement ps = con.prepareStatement(insertSQL);
            ps.setString(1, Section);
            ps.setString(2, Assignment);
            ps.setString(3, Student);
            ps.setBinaryStream(4, fis, (int) file.length());
            ps.executeUpdate();
            ps.close();
            fis.close();
            return true;
        } catch (FileNotFoundException ex) {
            return false;
            //Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            return false;
            //Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            return false;
            //Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public Boolean Update(String zipFilePath, String Section, String Assignment, String Student,
            String outputFilePath, String inputFilePath, String errorFilePath, String documentationFilePath, String magicFilePath) {
        File zipFile = new File(zipFilePath);
        int zi = 1;
        int ou = 2;
        int in = 3;
        int er = 4;
        int doc = 5;
        int mag = 6;
        int stn = 7;
        int asn = 8;
        int sec = 9;
        try {
            fis = new FileInputStream(zipFile);
            PreparedStatement ps = con.prepareStatement(updateSQL);
            ps.setString(sec, Section);
            ps.setString(asn, Assignment);
            ps.setString(stn, Student);
            ps.setBinaryStream(zi, fis, (int) zipFile.length());
            if (inputFilePath != null) {//---------------------------------------------INPUT FILE
                File inF = new File(inputFilePath);
                fis = new FileInputStream(inF);
                ps.setBlob(in, fis, (int) inF.length());
            } else {
                Blob b = null;
                ps.setBlob(in, b);
            }
            if (outputFilePath != null) {//--------------------------------------------OUTPUT FILE
                File F = new File(outputFilePath);
                fis = new FileInputStream(F);
                ps.setBlob(ou, fis, (int) F.length());
            } else {
                Blob b = null;
                ps.setBlob(ou, b);
            }
            if (errorFilePath != null) {//---------------------------------------------ERROR FILE
                File F = new File(outputFilePath);
                fis = new FileInputStream(F);
                ps.setBlob(er, fis, (int) F.length());
            } else {
                Blob b = null;
                ps.setBlob(er, b);
            }
            if (documentationFilePath != null) {//-------------------------------------DOCUMENTATION FILE
                File F = new File(documentationFilePath);
                fis = new FileInputStream(F);
                ps.setBlob(doc, fis, (int) F.length());
            } else {
                Blob b = null;
                ps.setBlob(doc, b);
            }
            if (magicFilePath != null) {//---------------------------------------------MAGIC FILE
                File F = new File(inputFilePath);
                fis = new FileInputStream(F);
                ps.setBlob(mag, fis, (int) F.length());
            } else {
                Blob b = null;
                ps.setBlob(mag, b);
            }
            ps.executeUpdate();
            ps.close();
            fis.close();
            return true;
        } catch (FileNotFoundException ex) {
            return false;
            //Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            return false;
            //Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            return false;
            //Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public Boolean retrieveZip(String Section, String Assignment, String Student, String initFilePath) {
        String q = "Select zipfile " + getSQLpt2;
        PreparedStatement ps;
        try {
            ps = con.prepareStatement(q);
            int stu = 1;
            int asn = 2;
            int sec = 3;
            ps.setString(stu, Student);
            ps.setString(asn, Assignment);
            ps.setString(sec, Section);
            ResultSet rs = ps.executeQuery();
            int i = 0;
            while (rs.next()) {
                byte[] imgBytes = rs.getBytes(1);
                FileOutputStream fo = new FileOutputStream(initFilePath + slash + Section + slash + Assignment + slash + Student + slash + Student + "Sub.zip");
                fo.write(imgBytes);
                i++;
            }
            return true;
        } catch (SQLException ex) {
            return false;
            //Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            return false;
            //Logger.getLogger(SubmissionCRUD.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
