/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grimmgrader;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 *
 * @author nsalemu2019
 */
public class InputTextinfo implements Serializable{
    private String name;
    private Date DateSaved;
    private List<String> inputText;

    public InputTextinfo(String name, Date DateSaved) {
        this.name = name;
        this.DateSaved = DateSaved;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getInputText() {
        return inputText;
    }

    public void setInputText(List<String> inputText) {
        this.inputText = inputText;
    }
    
    
}
