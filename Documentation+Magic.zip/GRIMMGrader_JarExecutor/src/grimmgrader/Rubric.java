/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grimmgrader;

import java.util.ArrayList;

/**
 *
 * @author Ryan
 */
public class Rubric {
    
    private String rubricName;
    private String rubricType;
    private ArrayList<ArrayList<String>> criteriaList;
    
    public Rubric(String name, String type, ArrayList<ArrayList<String>> criteria)
    {
        rubricName = name;
        rubricType = type;
        criteriaList = criteria;
    }
    
    public ArrayList<ArrayList<String>> getCriteriaList()
    {
        return criteriaList;
    }
    
    public String getRubricName()
    {
        return rubricName;
    }
    
    public String getRubricType()
    {
        return rubricType;
    }
    
    
}
