'use strict';

// Imports dependencies and set up http server
const
  request = require('request'),
  express = require('express'),
  bodyParser = require('body-parser'),
  app = express().use(bodyParser.json()), // creates express http server
  botOnPass = 'turn bot on',
  botOffPass = 'turn bot off',
  resetBlackListPass = 'reset blacklist',
  adminID = '1663636673713730',
  confidencePercentage = 0.75,
  greetingsResonse = `Hello there, do you have any questions for us?`,
  byeResponse = `Goodbye, please let us know if you have any other questions!`,
  scholarshipResponse = `We offer scholarships to all of our international students. For more information about financial information, please visit the link below. If you still have questions, please email Ms. Kyle Grubbs, klgrubbs@manchester,edu. She works with international students in our admissions department, https://www.manchester.edu/admissions/audiences/international-students-home/international-students/financial-information`,
  crisisResponse = `Just recieved a crisis message, please check MU inbox`,
  tuitionResponse = `If you have questions about financial information, please visit the link below. If you still have questions, please email Ms. Kyle Grubbs, klgrubbs@manchester,edu. She works with international students in our admissions department, https://www.manchester.edu/admissions/audiences/international-students-home/international-students/financial-information`,
  programsResponse = `Find all the programs offered by Manchester University at this link https://www.manchester.edu/admissions/degrees-and-academics/degrees-offered`,
  keywords = ['greetings', 'bye', 'scholarship', 'crisis', 'tuition', 'programs'],
  responses = [greetingsResonse, byeResponse, scholarshipResponse, crisisResponse, tuitionResponse, programsResponse];
var blackList = [];
let botOn = true;



// Sets server port and logs message on success
app.listen(process.env.PORT || 1337, () => console.log('webhook is listening'));
// Creates the endpoint for our webhook
app.post('/webhook', (req, res) => {

  let body = req.body;

  // Checks this is an event from a page subscription
  if (body.object === 'page') {
    // Iterates over each entry - there may be multiple if batched
    body.entry.forEach(function(entry) {

  // Gets the body of the webhook event
  let webhook_event = entry.messaging[0];
  console.log(webhook_event);


  // Get the sender PSID
  let sender_psid = webhook_event.sender.id;
  console.log('Sender PSID: ' + sender_psid);

  // Check if the event is a message or postback and
  // pass the event to the appropriate handler function
  if (webhook_event.message) {
    handleMessage(sender_psid, webhook_event.message);
  }

});

    // Returns a '200 OK' response to all requests
    res.status(200).send('EVENT_RECEIVED');
  } else {
    // Returns a '404 Not Found' if event is not from a page subscription
    res.sendStatus(404);
  }
});

// Adds support for GET requests to our webhook
app.get('/webhook', (req, res) => {

  // Your verify token. Should be a random string.
  let VERIFY_TOKEN = "special-bot"

  // Parse the query params
  let mode = req.query['hub.mode'];
  let token = req.query['hub.verify_token'];
  let challenge = req.query['hub.challenge'];

  // Checks if a token and mode is in the query string of the request
  if (mode && token) {
    // Checks the mode and token sent is correct
    if (mode === 'subscribe' && token === VERIFY_TOKEN) {

      // Responds with the challenge token from the request
      console.log('WEBHOOK_VERIFIED');
      res.status(200).send(challenge);

    } else {
      // Responds with '403 Forbidden' if verify tokens do not match
      res.sendStatus(403);
    }
  }
});



function firstEntity(nlp, name) {
  return nlp && nlp.entities && nlp.entities[name] && nlp.entities[name][0];
}


function entities(entity, received_message)
{
  const entityType = firstEntity(received_message.nlp, entity);
  return (entityType && entityType.confidence > confidencePercentage);
}


// Handles messages events
function handleMessage(sender_psid, received_message) {
  let response;
  let text;

  // Checks if the message contains text
  if (received_message.text) {
    // Create the payload for a basic text message, which
    // will be added to the body of our request to the Send API
    text = received_message.text.toLowerCase();

    if (adminID == sender_psid)
    {
      switch (text)
      {
        case botOnPass:
          botOn = true;
          response = { "text": `I am back online!` };
          break;
        case botOffPass:
          botOn = false;
          break;
        case resetBlackListPass:
          resetBlacklist();
          response = { "text": `The blacklist is reseted` };
          break;
        default:
      }
    }
    else
    {
      for (var i=0; i<keywords.length; i++)
      {
        if(entities(keywords[i],received_message))
        {
          response = { "text": responses[i] }
          if (keywords[i] == 'crisis')
          {
            blackList.push(sender_psid);
            callSendAPI(adminID, response);
          }
        }
      }
    }
  }

  if ((!(blackList.includes(sender_psid))) && botOn)
  {
    callSendAPI(sender_psid, response);
  }
}


// Sends response messages via the Send API
function callSendAPI(sender_psid, response) {
  // Construct the message body
  let request_body = {
    "recipient": {
      "id": sender_psid
    },
    "message": response
  }

  // Send the HTTP request to the Messenger Platform
  request({
    "uri": "https://graph.facebook.com/v2.6/me/messages",
    "qs": { "access_token": "EAAHahZAshnEwBAAfUgztnas0eqF8RavB7cs0fDTG0XjLYgeEyIuEKTwJhA4OZCZCcS4jLZAmgEEOEnoRkXx56f5ZATHqMfZBWFZAUcCpAgj4E1L6t3faqtSDZBle4Bcz7f44M5SOxaR1QEY9FygHGQV2FKohKaOSsYt3Gfra6wBFHQZDZD" },
    "method": "POST",
    "json": request_body
  }, (err, res, body) => {
    if (!err) {
      console.log('message sent!')
    } else {
      console.error("Unable to send message:" + err);
    }
  });
}

function resetBlacklist()
{
  blackList.length = 0;
}
