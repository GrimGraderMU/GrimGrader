/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assembler;

import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author Anthony
 */
public class UserInterface {
    private Scanner s = new Scanner(System.in);
    private FileWrite f = new FileWrite();
    private Boolean stop = false;
    private Translator t = new Translator();
    private String out = "";
    private String HALT = "111111111111111111111111";
    
    
    
    void start() throws IOException{
        String in = "";
        while(!stop){
            if (s.hasNext()){
                in = s.nextLine();
                out = t.Translate(in);
                if(out == HALT){
                    f.addLine(out);
                    f.printToFile();
                    stop = true;
                }
                f.addLine(out);
            }
        }
    }
    
    
}
