/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assembler;


import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.util.ArrayList;

/**
 *
 * @author Anthony
 */
public class FileWrite {
    private final String FileName = "F:\\Command.txt";
    private final ArrayList<String> output = new ArrayList<>();
    public FileWrite() {
       
    }
    
    public void addLine(String o) {
        output.add(o);
    }
    
    
    public void printToFile() throws IOException{
        Path filePath = Paths.get(FileName);
        Files.write(filePath, output, Charset.forName("UTF-8"));
    }
    
}
