/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assembler;

/**
 *
 * @author Anthony
 */
public class CodeAssociation {

    public String generate(String s){
        switch(s.toUpperCase()){
            case "MOVLTOR":
                return"00000000";
            case "MOVRTOM":
                return"00000001";
            case "MOVMTOR":
                return"00000010";
            case "ADD":
                return"00010000";
            case "SUB":
                return"00010001";
            case "MULT":
                return"00010010";
            case "DIV":
                return"00010011";
            case "COMPE":
                return"00100000";
            case "COMPL":
                return"00100001";
            case "COMPLE":
                return"00100010";
            case "COMPG":
                return"00100011";
            case "COMPGE":
                return"00100100";
            case "JUMPE":
                return"00110000";
            case "JUMPL":
                return"00110001";
            case "JUMPLE":
                return"00110010";
            case "JUMPG":
                return"00110011";
            case "JUMPGE":
                return"00110100";
            case "PRGMSTP":
                return"11111111";
            default:
                throw new Error("Command Not Found: " + s);
        }
    }
}
