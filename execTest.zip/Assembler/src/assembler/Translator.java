/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assembler;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Anthony
 */
public class Translator {
    
    private String command = "";
    private String HALT = "11111111";
    private String separator ="/";
    private int comm = 0;
    private int op1 = 1;
    private int op2 = 2;
    private int secLength = 8;
    private CodeAssociation c = new CodeAssociation();

    public String Translate(String ac){
        String[] commandSet = ac.split(separator);
        command=c.generate(commandSet[comm]);
        if(command == HALT){
            command = "111111111111111111111111";
        }else{
            
            command+=StrtoBinStr(commandSet[op1]);
            command+=StrtoBinStr(commandSet[op2]);
            
        }
        System.out.print(" OUTPUT: " + command);
        System.out.println("\n");
        return command;
    }
    
    private String StrtoBinStr(String s){
        Integer i = Integer.parseInt(s);
        String r = Integer.toBinaryString(i);
        if(r.length()<secLength){
            int dif = secLength - r.length();
            String d = "";
            for(int f = 0; f <dif; f++){
                d+="0";
            }
            r = d+r;
        }
        else{
            int di = r.length() - secLength;
            r = r.substring(di-1);
                
        }
        return r;
    }

    
    

        

}
