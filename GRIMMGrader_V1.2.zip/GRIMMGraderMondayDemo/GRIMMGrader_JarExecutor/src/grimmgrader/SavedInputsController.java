/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grimmgrader;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author nsalemu2019
 */
public class SavedInputsController {
    public static List<InputTextinfo> getInputTextInfo(){
         FileWrite fileWrite = new FileWrite("Hello.txt");
        List<InputTextinfo> list = new ArrayList<>();
        try {
            list = (List<InputTextinfo>) fileWrite.GetData("Hello.txt");
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
    public static List<String> getInputs(){
        List<InputTextinfo> list = getInputTextInfo();
        
        List<String> InputName = new ArrayList<>();
        if (list != null) {
            for (InputTextinfo list1 : list) {
                InputName.add(list1.getName());
            }
        }
        return InputName;
    }
}
