/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiplicationtable;

/**
 *
 * @author eaibrahim2019
 */
public class Multiplier {
    int num1;
    int num2;
    int product=0;
        
    public Multiplier(){
    
}
    public Integer Multiplier( int i,int j){
        for( i=num1;i<=10;i++){
         for(j=num2;j<=10;j++ )    
            return i;
         return j;
        }
    
return null;
}
}      
    
