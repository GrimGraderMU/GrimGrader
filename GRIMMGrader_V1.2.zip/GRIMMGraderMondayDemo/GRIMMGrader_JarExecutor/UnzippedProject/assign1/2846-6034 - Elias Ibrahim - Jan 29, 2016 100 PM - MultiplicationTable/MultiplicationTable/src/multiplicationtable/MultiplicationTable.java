/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiplicationtable;

/**
 *
 * @author eaibrahim2019
 */
public class MultiplicationTable {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       // print main table
      for (int i = 1; i <= 10; i++) {
         System.out.print(i + ":");
         for (int j = 1; j <=10; j++) {
            System.out.print(i*j + " ");
         }
         System.out.println();
      }
   } 
}
    
    

