/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grimmgrader;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import java.util.ArrayList;
import javafx.scene.control.TextArea;

/**
 *
 * @author Frehiwot Gudeta
 */
public class FXMLDocumentController implements Initializable {

    private ArrayList<String> errorsList = new ArrayList<>();
    private ArrayList<String> inputsList = new ArrayList<>();
    private ArrayList<String> outputsList = new ArrayList<>();
    private String TempInputCommand="";
    
    @FXML
    private TextArea inputTextArea;
    @FXML
    private TextArea outputWindow;
    @FXML
    private TextArea errorWindow;
    @FXML
    private TextField rubricWindow;
    @FXML
    private TextArea inputWindow;
    @FXML
    private Button startGrading;
    @FXML
    private Button enterInputs;

    //ReadOutputs out = new ReadOutputs();
    //ReadErrors err = new ReadErrors();
    @FXML
    private void startGrading(ActionEvent event) {
        CommandExecutor cmdExec = new CommandExecutor(this);
        ArrayList<String> commands = new ArrayList<>();
        String runCommand = "java -jar ";
        String runParam = "H:\\Downloads\\TestComplexProject\\dist\\TestComplexProject.jar";
        commands.add(runCommand);
        commands.add(runParam);
        cmdExec.execute(commands);
    }

    @FXML
    private void enterInputs(ActionEvent event) {
        TempInputCommand=inputTextArea.getText();
        inputTextArea.setText("");
    }

    @FXML
    private void outputWindow(ActionEvent event) {

    }

    @FXML
    private void inputWindow(ActionEvent event) {

    }

    @FXML
    private void rubricWindow(ActionEvent event) {

    }

    @FXML
    private void errorWindow(ActionEvent event) {

    }

    public void Update() {
        String ErrorText = "";
        for (String errors : errorsList) {
            ErrorText = ErrorText.concat("\n").concat(errors);
        }

        String OutputText = "";
        for (String Outputs : outputsList) {
            OutputText = OutputText.concat("\n").concat(Outputs);
            
        }

        String InputText = "";
        for (String Inputs : inputsList) {
            InputText = InputText.concat("\n").concat(Inputs);
        }
        outputWindow.setText(OutputText);
        inputWindow.setText(InputText);
        errorWindow.setText(ErrorText);

    }

   

    public void setErrorsList(ArrayList<String> errorsList) {
        this.errorsList = errorsList;
    }

    public void setInputsList(ArrayList<String> inputsList) {
        this.inputsList = inputsList;
    }

    public void setOutputsList(ArrayList<String> outputsList) {
        this.outputsList = outputsList;
    }

    public ArrayList<String> getErrorsList() {
        return errorsList;
    }

    public ArrayList<String> getInputsList() {
        return inputsList;
    }

    public ArrayList<String> getOutputsList() {
        return outputsList;
    }

    public String getTempInputCommand() {
        return TempInputCommand;
    }

    public void setTempInputCommand(String TempInputCommand) {
        this.TempInputCommand = TempInputCommand;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        //errorWindow.setText(in.readLine());
    }

}
