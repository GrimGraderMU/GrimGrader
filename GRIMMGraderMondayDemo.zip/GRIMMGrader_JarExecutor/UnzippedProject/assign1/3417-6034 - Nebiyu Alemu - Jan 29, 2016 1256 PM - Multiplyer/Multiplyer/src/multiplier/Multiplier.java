/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiplier;


/**
 *
 * @author Nebiyou
 */
public class Multiplier {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
                Multiply M = new Multiply();
//                int multiplier = 8;
//                int multiplicand=2;
        for(int multiplicand=1; multiplicand<=10; multiplicand++){
            for(int multiplier=1;multiplier<=10;multiplier++){

         System.out.println(M.getMultiplyer(multiplier, multiplicand));
            }
        }
    }    
  
    
    
    
}
